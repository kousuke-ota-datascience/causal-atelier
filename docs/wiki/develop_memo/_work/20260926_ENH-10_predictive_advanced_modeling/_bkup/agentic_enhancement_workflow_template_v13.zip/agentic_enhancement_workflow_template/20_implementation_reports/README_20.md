# Implementation Reports

## 1. Purpose

`20_implementation_reports/` はCoding / Candidate Assemblyが生成するimplementation evidenceを保持する。

workflow cursorを手動管理する領域ではなく、後続dependency / candidate readinessをcanonical evidenceから導出するための領域である。

## 2. Work Package evidence

Work Package modeのcanonical package reportは次のdirectoryに置く。

```text
20_implementation_reports/<GATE_ID>/Trial<TRIAL_NO>/packages/
```

最低限のidentity / state metadata:

```text
Gate: <GATE_ID>
Package: <PACKAGE_ID>
Trial: <TRIAL_NO>
State: PACKAGE_COMPLETE
Checkpoint SHA: <SHA or NONE>
```

本文には最低限次を含める。

- implemented scope summary
- changed files
- focused verification + result
- blocker / remaining work
- checkpoint SHA
- next action

`PACKAGE_READY` はCoding Agentのterminal response labelでありcanonical report stateではない。`State: PACKAGE_COMPLETE` の場合だけpackage dependencyを満たす。

## 3. Checkpoint report consolidation

通常経路ではPackage Execution Status Reportにcheckpoint SHAとverification evidenceを含める。

独立したImplementation Checkpoint ReportはOPTIONAL artifactとし、追加監査・運用要件がある場合だけ生成する。workflow cursor / dependency authorityにはしない。

## 4. Gate-level candidate evidence

Work Package modeでは全required Pxx完了後、Candidate AssemblyがGate-level Implementation Completion Reportを作る。

required package集合のauthorityはGate 06 `Required packages` であり、P00ではない。

Single Execution modeではGate-wide implementation完了後に同等のcandidate identity evidenceを作る。

Candidate readiness authorityはImplementation Completion Reportであり、期待stateは次である。

```text
Candidate state: READY_FOR_TEST
```

## 5. Dependency semantics

```text
Pxx dependency  -> upstream package canonical report / canonical 999
Gate dependency -> upstream canonical 999
```

Pxx documentのstatus literal、P00、Gate local README、別のcontrol sheetからdependency成立を推測しない。

## 6. Audit-only artifacts

Implementation Detail Ledger等の詳細audit artifactはOPTIONALとし、normal execution-time read dependency / workflow cursorにしない。

## 7. README naming

Gate / Trial等のnested local READMEを作る場合、`40_operator_workflows/tools/readme_naming.py` のpath-derived namingを使用する。
