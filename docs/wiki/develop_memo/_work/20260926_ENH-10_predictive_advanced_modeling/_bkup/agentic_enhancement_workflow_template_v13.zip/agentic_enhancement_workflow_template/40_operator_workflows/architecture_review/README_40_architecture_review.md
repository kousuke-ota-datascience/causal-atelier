# Architecture Review

## 1. Purpose

Gate contract freeze前にPlanning / Designでdeferされたsource factをcurrent repositoryから確認し、FactsとDesign recommendationを分離する。

## 2. Entry point

```text
01_architecture_discovery_prompt.md
```

Enhancement instance側の同promptを使用し、対象Gate / deferred questionをHuman/operatorが指定する。

## 3. Output

Architecture Discoveryの結果は、必要に応じて次へ反映する。

```text
02_target_architecture_decision_record.md
00_enhance_background/04_design_revision.md
00_enhance_background/05_requirements_design_consistency_and_traceability_review.md
10_enhance_instruction/<GATE_ID>/Gate 06 / Gate 07 / affected Pxx
```

## 4. Boundary

Architecture Reviewはsource factの確認とDesign decision支援を行う。

Product code / test codeを変更する実装工程ではない。
