# Template Structure

## 1. Scope

この文書はAgentic Enhancement Workflow Templateのcanonical namespace / control-plane構造を示す。

本reconstructed baselineでは、引継ぎ資料から存在・役割を確認できないhistorical semantic bodyを推測で復元しない。

## 2. Canonical top-level structure

```text
agentic_enhancement_workflow_template/
├─ README.md
├─ README_Appendix_HowToUse.md
├─ README_NAMING_CONVENTION.md
├─ RECONSTRUCTION_NOTES.md
├─ RECONSTRUCTION_MANIFEST.json
├─ TEMPLATE_STRUCTURE.md
├─ 00_enhance_background/
│  ├─ README_00.md
│  ├─ 04_design_revision.md
│  └─ 05_requirements_design_consistency_and_traceability_review.md
├─ 10_enhance_instruction/
│  └─ README_10.md
├─ 20_implementation_reports/
│  └─ README_20.md
├─ 30_test_report/
│  └─ README_30.md
└─ 40_operator_workflows/
   ├─ README_40.md
   ├─ architecture_review/
   │  ├─ README_40_architecture_review.md
   │  ├─ 01_architecture_discovery_prompt.md
   │  └─ 02_target_architecture_decision_record.md
   ├─ agent_entry_prompts/
   │  ├─ README_40_agent_entry_prompts.md
   │  ├─ 00_variable_conventions.md
   │  ├─ 10_normal_execution_01_single_execution_coding_agent_prompt.md
   │  ├─ 10_normal_execution_02_work_package_coding_agent_prompt.md
   │  ├─ 20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md
   │  ├─ 30_independent_verification_01_test_agent_prompt.md
   │  ├─ 40_fail_remediation_01_fail_rework_coding_agent_prompt.md
   │  └─ 50_orchestration_01_gate_orchestrator_prompt.md
   ├─ preflight/
   │  └─ AGENT_EXECUTION_READINESS.md
   └─ tools/
      ├─ instantiate_agent_entry_prompts.py
      ├─ readme_naming.py
      ├─ test_workflow_metadata.py
      ├─ validate_agent_execution_readiness.py
      └─ workflow_metadata.py
```

## 3. Enhancement-instance dynamic structure

Enhancement instanceではruntime identityに応じて次が生成・作成される。

```text
10_enhance_instruction/Gxx/
  README_10_Gxx.md              # optional Human index
  Gate 06                         # routing + implementation authority
  Gate 07                         # verification authority
  P00                             # optional authoring/audit artifact
  Pxx contract(s) when WORK_PACKAGE

20_implementation_reports/Gxx/Trialxx/
  packages/*__status.md          # canonical package completion evidence
  implementation completion report # candidate identity authority
  implementation checkpoint report # optional
  implementation detail report     # optional audit

30_test_report/Gxx/Trialxx/
  verification evidence
  *_999_gate_decision.md
```

## 4. Artifact authority

```text
Pxx dependency       -> upstream package canonical report
Gate dependency      -> upstream canonical 999_gate_decision
Gate readiness       -> Gate 06 + Gate 07 + 06-declared prerequisite evidence + blocking preflightなし
Candidate readiness  -> implementation completion report
Final Gate authority -> canonical 999_gate_decision
Gate local README     -> Human index only
P00                   -> optional authoring/audit only
```

別のmutable state sheetへ再集約しない。

Phase Fのruntime read-setはcurrent Gateのcanonical `999_gate_decision`だけとし、next Gate readinessはNext Gate Phase Aで解決する。

## 5. README identity

rootだけが `README.md` を使用する。

nested local READMEはpath-derived deterministic filename `README_<PATH_ID>.md` を使用する。canonical implementationは以下。

```text
40_operator_workflows/tools/readme_naming.py
```

## 6. Agent prompt instantiation

`40_operator_workflows/agent_entry_prompts/` はauthoring sourceでありtemplate-sideから直接実行しない。

Enhancement開始時にEnhancement-fixed identityを解決して次へinstance化する。

```text
{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/
```

## 7. Reconstruction boundary

以下は引継ぎ資料だけではhistorical semantic bodyを復元できていない。

- Single Execution prompt
- Candidate Assembly prompt
- Independent Verification prompt
- Formal FAIL Remediation prompt
- Gate Orchestrator prompt
- `00_enhance_background/` の04/05より前に存在した可能性のあるartifact
- actual repositoryの `MANIFEST.json` schema / content

これらをsource confirmationなしに旧本文として捏造しない。
