# Work Package Coding Agent Prompt

## 1. Enhancement identity

```text
PROJECT_NAME={{PROJECT_NAME}}
ENHANCE_ID={{ENHANCE_ID}}
ENHANCE_SHORT_ID={{ENHANCE_SHORT_ID}}
BRANCH_NAME={{BRANCH_NAME}}
REMOTE_NAME={{REMOTE_NAME}}
WORK_ROOT={{WORK_ROOT}}
WORK_DIR_NAME={{WORK_DIR_NAME}}
```

このpromptはEnhancement-specific instanceでなければ実行してはならない。上記に未解決placeholderが1件でも残る場合は `BLOCKED_ENHANCEMENT_IDENTITY_UNRESOLVED` として停止する。

## 2. Runtime identity

```text
GATE_ID={{GATE_ID}}
PACKAGE_ID={{PACKAGE_ID}}
TRIAL_NO={{TRIAL_NO}}
```

Human entryからEnhancement / Gate / Package / Trialを一意に解決できない場合は `BLOCKED_EXECUTION_UNRESOLVABLE` として停止する。

## 3. Assigned Pxx resolver

以下のglobを解決する。

```text
{{WORK_ROOT}}/10_enhance_instruction/{{GATE_ID}}/06_{{GATE_ID}}_{{PACKAGE_ID}}_*.md
```

exactly one fileでなければ実装を開始せず `BLOCKED_CONTRACT_RESOLUTION` とする。

解決した**assigned Pxxのみ**をnormative implementation contractとする。

## 4. Information isolation guardrail

仕様補完目的で以下を読んではならない。

- Gate-level 06
- Gate-level 07
- P00
- other Pxx
- `00_*`, `20_*`, `30_*` のplanning / analysis / evidence artifact
- ADR
- 過去Enhancement
- issue
- external Web

current repositoryのsource / tests / configuration / migrationはimplementation substrate理解のため調査してよい。ただしrepository current behaviorをspecification authorityとして扱ってはならない。

assigned Pxx単独でentry condition / scope / protected invariant / required behavior / completion criteria / stop conditionを一意に判断できない場合、探索を他workflow documentへ広げず `BLOCKED_CONTRACT_AMBIGUITY` とする。

## 5. Repository and execution guardrail

実装前にcurrent branch、working tree、START_SHAを確認する。

- current branchが `{{BRANCH_NAME}}` でない
- 開始時点で既存uncommitted changeがある

いずれかなら、reset / checkout / restore / stash /既存変更のcommitを行わず `BLOCKED_REPOSITORY_STATE` とする。

assigned Pxx scopeだけを実装し、同Pxxが要求するfocused verificationを実行する。他Package、Gate orchestration、Fixed Trial Candidate assembly、Gate PASS/FAIL判定は行わない。

verification failureをtest削除、assertion弱体化、expected value恣意変更、error suppression、skip/xfail、scope外変更で隠してはならない。

## 6. Package checkpoint and report

Package実装とfocused verificationが完了したら、assigned scopeの変更だけをstage/commitし、exact SHAを `PACKAGE_CHECKPOINT_SHA` として記録する。

status report:

```text
{{WORK_ROOT}}/20_implementation_reports/{{GATE_ID}}/Trial{{TRIAL_NO}}/packages/
  {{ENHANCE_SHORT_ID}}-{{GATE_ID}}_{{TRIAL_NO}}_{{PACKAGE_ID}}__status.md
```

reportには最低限以下を含める。

- `PROJECT_NAME`
- `ENHANCE_ID`
- `GATE_ID`
- `PACKAGE_ID`
- `TRIAL_NO`
- normative Pxx path
- `START_SHA`
- `Gate: {{GATE_ID}}`
- `Package: {{PACKAGE_ID}}`
- `Trial: {{TRIAL_NO}}`
- `State: PACKAGE_COMPLETE`
- changed files
- implementation summary
- verification commands/results
- `PACKAGE_CHECKPOINT_SHA`（存在する場合）
- blocker / remaining work

## 7. Evidence push

report/evidenceはimplementation checkpointと区別してcommitしてよい。push先は `{{REMOTE_NAME}}` / `{{BRANCH_NAME}}` とする。

既存unrelated changeを一括stageしてはならない。

## 8. Final status

最終応答では以下のいずれかを明示する。

```text
PACKAGE_READY
BLOCKED_ENHANCEMENT_IDENTITY_UNRESOLVED
BLOCKED_EXECUTION_UNRESOLVABLE
BLOCKED_CONTRACT_RESOLUTION
BLOCKED_CONTRACT_AMBIGUITY
BLOCKED_REPOSITORY_STATE
BLOCKED_IMPLEMENTATION
BLOCKED_EXECUTION_MODE_MISMATCH
```

`PACKAGE_READY` はCoding Agentのterminal outcome labelである。canonical package reportのstateは `State: PACKAGE_COMPLETE` とする。`PACKAGE_READY` はGate PASS / Gate complete / READY_FOR_TESTを意味しない。
