# Requirements / Design Consistency and Traceability Review

**Reconstruction status:** GENERIC_CONTRACT_SCAFFOLD

## 1. Purpose

Requirements、Design、Gate implementation contract、Work Package、Verification contract間の整合とtraceabilityを確認する。

## 2. Consistency review

最低限、以下を確認する。

- RequirementとDesign decisionが矛盾しない
- Gate 06とGate 07が矛盾しない
- Work Package modeでは各Pxxがself-containedである
- Gate 07のAcceptance Criteria / Test ItemがRequirement / Designを検証可能である
- Coding Agentへ背景資料の再探索を要求しない

## 3. Traceability review

Enhancement固有のtraceabilityを記録する。

```text
Requirement
    -> Design decision
        -> Gate / assigned Pxx
            -> Acceptance Criteria / Test Item
```

## 4. Unresolved blockers

Gate freezeをBLOCKするunresolved semantic / acceptance itemを列挙する。

ゼロでない場合、単なるstatus literalの変更によってFROZEN扱いにしてはならない。
