# Enhancement Instruction

## 1. Purpose

`10_enhance_instruction/` はGate単位のexecution contractを保持する。

通常経路ではGate-level runtime authorityを `06` と `07` に集約する。Gate local READMEはHuman向けindexであり、execution routing / dependency / readiness authorityではない。

## 2. Per-Gate structure

Enhancement instanceでは原則として次の形を取る。

```text
10_enhance_instruction/
└─ Gxx/
   ├─ README_10_Gxx.md             # optional Human index
   ├─ 06_*_Gxx_implementation_instruction.md
   ├─ 07_*_Gxx_test_instruction.md
   ├─ 06_Gxx_P00_*.md              # optional authoring/audit artifact
   └─ 06_Gxx_Pxx_*.md              # WORK_PACKAGE modeの場合
```

具体的なprefix / semantic filenameはEnhancement instanceのcontractをauthorityとする。

## 3. Gate 06 responsibility

Gate 06はGate Entry + Implementation Contractであり、最低限次のmetadataを保持する。

```text
Gate: G03
Contract status: FROZEN
Depends on: G02 PASS
Execution mode: WORK_PACKAGE
Required packages: P01, P02, P03
```

`SINGLE_EXECUTION` の場合:

```text
Gate: G01
Contract status: FROZEN
Depends on: NONE
Execution mode: SINGLE_EXECUTION
Required packages: NONE
```

Grammar:

- `Gate`: `G\d{2}`
- `Contract status`: runtime開始条件は `FROZEN`
- `Depends on`: `NONE` または comma-separated `Gxx PASS`
- `Execution mode`: `SINGLE_EXECUTION | WORK_PACKAGE`
- `Required packages`: SINGLE_EXECUTIONでは`NONE`、WORK_PACKAGEでは1件以上のcomma-separated `Pxx`

Markdown decorationはsemanticではない。

## 4. Gate 07 responsibility

Gate 07はVerification Contract / Acceptance Criteria authorityである。

runtime開始前に `Verification contract status: FROZEN` でなければならない。

06のimplementation semanticsと07のacceptance semanticsを混同しない。

## 5. Gate local README

Gate local READMEを置く場合、Human navigation / canonical artifact indexだけを保持する。

以下をruntime authorityとして保持しない。

- dependency declaration
- execution mode
- mutable readiness/status
- package completion state

Gate local READMEのmissing / staleだけをpreflight Hard FAILにしない。

## 6. P00 Work Package Plan

P00はOPTIONAL authoring / audit artifactとする。

package set / dependency graph / Candidate Assembly routingのruntime authorityにはしない。

```text
required package set = Gate 06 `Required packages`
package dependency   = each Pxx `Depends on`
```

## 7. Work Package contract

Work Package Coding Agentのnormative authorityはassigned Pxxのみとする。

Pxxは最低限、次をself-containedに記述する。

- Gate / Package identity
- Depends on
- Self-containment
- Information isolation
- required implementation scope
- prohibited / protected scope
- focused verification
- package reporting contract
- completion criteria
- stop rule

推奨metadata:

```text
Gate: G03
Package: P02
Depends on: P01
Self-containment: MUST
Information isolation: MUST
```

`Status at issuance` はdiagnostic metadataでありworkflow cursorとして使用しない。

## 8. Gate readiness

Gate readinessは次から導出する。

```text
Gate 06 = exactly one + FROZEN
    + Gate 06 `Depends on` のupstream canonical 999 PASS evidence
    + Gate 07 = exactly one + FROZEN
    + Gate 06 `Execution mode` / `Required packages` consistency
    + blocking preflightなし
```

Planning / Design / Architecture artifactsは06 freeze前のauthoring inputにはなり得るが、FROZEN後のnormal runtime read dependencyにしない。
