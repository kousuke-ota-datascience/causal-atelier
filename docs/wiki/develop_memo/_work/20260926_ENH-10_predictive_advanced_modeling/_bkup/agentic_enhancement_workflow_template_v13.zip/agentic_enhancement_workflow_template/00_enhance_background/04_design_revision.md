# Design Revision

**Reconstruction status:** GENERIC_CONTRACT_SCAFFOLD

## 1. Purpose

EnhancementのDesign revisionを記録し、source confirmationが必要な事項と確定済みDesign decisionを分離する。

このファイルはPlanning / Design authorityであり、Work Package Coding Agentのnormative contractではない。

## 2. Design revisions

Enhancement固有のDesign revisionを記録する。

各revisionでは最低限、以下を区別する。

- confirmed fact
- design decision
- affected requirement / Gate / Pxx
- protected invariant
- unresolved item

## 3. Deferred source confirmation

current source / tests / config / runtime factの確認が必要な事項を列挙する。

未確認事項を推測で補完して確定扱いにしない。

## 4. Gate freeze impact

各unresolved itemについて、どのGate contract freezeをBLOCKするかを明示する。

source confirmation完了後、影響するGate 06 / 07 / Pxxだけへ必要な事実・decisionを反映する。

## 5. Traceability

Requirements → Design → Gate / Pxx → Verificationの追跡可能性を保持する。
