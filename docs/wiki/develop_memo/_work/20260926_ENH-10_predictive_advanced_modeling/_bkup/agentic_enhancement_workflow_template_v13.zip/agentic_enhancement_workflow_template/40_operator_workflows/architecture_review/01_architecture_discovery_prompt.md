# Architecture Discovery / Source Confirmation Prompt

## 1. Purpose

対象Gate contractをfreezeする前に、Planning / Requirements / Design artifactでsource confirmationへdeferされた項目をcurrent source / tests / config / runtime factsから確定する。

## 2. Inputs

Human/operatorは最低限、次を指定する。

```text
WORK_ROOT=<Enhancement work root>
GATE_ID=<target Gate>
```

対象Enhancementに記録されたdeferred questionだけを扱う。

## 3. Required investigation

各deferred itemについて以下を分離して報告する。

1. current source / tests / config / runtime factsから確認できる事実
2. 対象項目に必要なactual behavior / semantics / route / operation / persistence / API
3. Gate implementationに追加変更が必要か否か
4. factから導かれるDesign recommendation
5. Gate freezeをBLOCKする未解決事項が残るか

## 4. Constraints

- Product codeを変更しない
- test codeを変更しない
- FactsとDesign recommendationを明確に分離する
- sourceに存在しない仕様・operation・behaviorを補完目的で捏造しない
- current source / tests / config / runtime factを根拠とする
- 対象Enhancementに記録されたdeferred questionだけを扱い、無関係な探索へ広げない

## 5. Completion

最後に、対象Gate freezeをBLOCKする未解決事項が残っているかを明示する。
