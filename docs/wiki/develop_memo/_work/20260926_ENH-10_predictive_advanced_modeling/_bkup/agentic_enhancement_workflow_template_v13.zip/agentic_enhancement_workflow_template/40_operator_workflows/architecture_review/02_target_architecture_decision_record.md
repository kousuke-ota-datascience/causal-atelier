# Target Architecture Decision Record

**Status:** DRAFT
**Reconstruction status:** GENERIC_CONTRACT_SCAFFOLD

## 1. Purpose

Architecture Discovery / source confirmationで確認したFactsを基礎として、対象Enhancement / Gateに必要なarchitecture / design decisionを記録する。

## 2. Confirmed facts

source / tests / config / runtimeから確認した事実を記録する。

推測・Design preferenceをFactsへ混在させない。

## 3. Design decisions

Confirmed factsから採用するDesign decisionを記録する。

各decisionについて、影響するRequirement / Gate / Pxx / verificationを示す。

## 4. Alternatives and trade-offs

重要な代替案、棄却理由、trade-offを記録する。

## 5. Unresolved blockers

Gate freezeをBLOCKするunresolved itemを記録する。

ゼロでない場合、`Status` をfinalized stateへ変更しない。
