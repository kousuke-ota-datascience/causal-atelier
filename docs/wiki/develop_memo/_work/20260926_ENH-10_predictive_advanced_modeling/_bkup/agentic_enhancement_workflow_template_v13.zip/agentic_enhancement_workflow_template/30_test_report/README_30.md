# Test Reports / Gate Decision

## 1. Purpose

`30_test_report/` はIndependent Verification evidenceとcanonical Gate Decisionを保持する。

## 2. Independent Verification authority

execution modeにかかわらず、formal verificationのAcceptance authorityはfrozen Gate 07である。

Coding Agentのimplementation contractをAcceptance Criteria補完に使用しない。

## 3. Canonical Gate Decision

Gateの最終authorityは各Trialのcanonical `999_gate_decision` とする。

```text
30_test_report/<GATE_ID>/Trial<TRIAL_NO>/
<ENHANCE_ID>_<GATE_ID>_Trial<TRIAL_NO>_999_gate_decision.md
```

Gate decisionは以下のいずれかを明示する。

```text
PASS
FAIL
BLOCKED
```

## 4. Dependency semantics

後続Gateのdependencyはupstream Gateのcanonical `999_gate_decision` から導出する。

別のmutable current-state artifactへPASS/FAILを転記してauthorityを二重化しない。

## 5. README naming

Gate / Trial等のnested local READMEを作る場合、`40_operator_workflows/tools/readme_naming.py` のpath-derived namingを使用する。
