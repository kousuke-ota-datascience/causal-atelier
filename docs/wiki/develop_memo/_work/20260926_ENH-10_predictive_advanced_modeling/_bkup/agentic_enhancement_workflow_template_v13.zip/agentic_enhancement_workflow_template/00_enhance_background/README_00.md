# Enhancement Background / Requirements / Design

## 1. Purpose

`00_enhance_background/` はEnhancementの背景、要求、設計、source-confirmation結果を保持するHuman/operator向けのPlanning / Design領域である。

Coding Agentのnormative implementation authorityとしては使用しない。Work Package modeでは、Coding Agentに必要な確定事項をassigned Pxxへ転記し、Pxxをself-containedにする。

## 2. Authority boundary

```text
Human / Planning / Design traceability
    = 00_enhance_background/*

Work Package Coding Agent normative authority
    = assigned Pxx only
```

`00_enhance_background/*` をCoding Agentへ仕様補完目的で読ませてはならない。

## 3. Known canonical artifacts

現行operator contractから直接確認できるartifactは以下である。

- `04_design_revision.md`
- `05_requirements_design_consistency_and_traceability_review.md`

これより前のnumbered artifactの歴史的inventory / semantic bodyは、引継ぎ資料からは復元できない。推測で追加しない。

## 4. Deferred source confirmation

Planning / Design時点でsource factが未確認の場合、推測で確定せずdeferred itemとして明示する。

Gate freeze前に `40_operator_workflows/architecture_review/01_architecture_discovery_prompt.md` を用いてcurrent source / tests / config / runtime factを確認し、必要なDesign decisionとGate contractへ反映する。

## 5. State management

このdirectoryにmutable workflow cursorを置かない。

legacy/current-state用のmutable control sheetまたは同等の代替mutable state sheetを新設してはならない。進行状態はcanonical evidenceから導出する。
