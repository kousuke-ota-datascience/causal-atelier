# Template Structure

## 1. Directories
text

<!-- BEGIN MANAGED: EXECUTION_CONTROL_STRUCTURE -->
## 2. Execution control, README identity, and instantiated prompts

The template-side `40_operator_workflows/agent_entry_prompts/` directory is an authoring source, not a runnable Enhancement instance.

Nested local README names are path-derived. The template root alone keeps `README.md`; all nested README files use `README_<PATH_ID>.md`. Canonical implementation: `40_operator_workflows/tools/readme_naming.py`.

Each Enhancement MUST instantiate the full prompt inventory under:

```text
{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/
```

The instantiated set MUST contain:

- `README_40_agent_entry_prompts.md`
- `00_variable_conventions.md`
- `10_normal_execution_01_single_execution_coding_agent_prompt.md`
- `10_normal_execution_02_work_package_coding_agent_prompt.md`
- `20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md`
- `30_independent_verification_01_test_agent_prompt.md`
- `40_fail_remediation_01_fail_rework_coding_agent_prompt.md`
- `50_orchestration_01_gate_orchestrator_prompt.md`

Execution-control tooling is located under `40_operator_workflows/tools/` and readiness policy under `40_operator_workflows/preflight/AGENT_EXECUTION_READINESS.md`. Shared Markdown metadata parsing is implemented by `40_operator_workflows/tools/workflow_metadata.py`; its regression self-test is `40_operator_workflows/tools/test_workflow_metadata.py`.
<!-- END MANAGED: EXECUTION_CONTROL_STRUCTURE -->

<!-- BEGIN MANAGED: README_NAMING_CONVENTION -->
## 3. README Naming Convention

### 3.1. Rule

Enhancement work root / workflow template rootのtop-level READMEだけを無印 `README.md` とする。

nested directoryのlocal READMEは、directory pathから機械的に導出した `PATH_ID` をpostfixとして付与する。

```text
README filename = deterministic function(directory path)
```

```text
root/
  README.md

root/00_enhance_background/
  README_00.md

root/20_implementation_reports/G01/Trial01/
  README_20_G01_Trial01.md

root/40_operator_workflows/agent_entry_prompts/
  README_40_agent_entry_prompts.md
```

### 3.2. PATH_ID generation

Enhancement/template rootからREADME配置directoryまでのrelative pathを左から処理する。

1. `NN_<semantic_name>` 形式のworkflow namespace directoryは `NN` に短縮する。
2. `G01`, `P01`, `Trial01` 等のruntime identity directoryはそのまま保持する。
3. `agent_entry_prompts`, `preflight` 等の非numbered semantic directoryは名前を保持する。
4. tokenを `_` で連結する。
5. `README_<PATH_ID>.md` とする。

例:

```text
00_enhance_background
  -> 00
  -> README_00.md

20_implementation_reports/G01/Trial01
  -> 20_G01_Trial01
  -> README_20_G01_Trial01.md

40_operator_workflows/agent_entry_prompts
  -> 40_agent_entry_prompts
  -> README_40_agent_entry_prompts.md
```

### 3.3. Invariants

- root以外に無印 `README.md` を置いてはならない。
- 同一directoryに複数のlocal READMEを置いてはならない。
- 手作業でpostfixを決めてはならない。必ずpath-derived naming functionを使用する。
- rename時はMarkdown links、plain path references、operator prompts、structure/manifest、validator/instantiation toolingを同時更新する。
- target filename collisionが発生した場合は自動上書きせず `BLOCKED_README_NAMING_COLLISION` とする。

### 3.4. Canonical implementation

canonical naming functionは以下とする。

```text
40_operator_workflows/tools/readme_naming.py
```

Template migration/apply tooling、instantiation tooling、validatorは同一規則を使用し、別々の命名ロジックを持たない。
<!-- END MANAGED: README_NAMING_CONVENTION -->

## 4. Root operator appendix

The template root contains the canonical end-to-end operator runbook:

```text
README_Appendix_HowToUse.md
```

The filename is unversioned inside the template. Document revision is recorded in the document metadata.
