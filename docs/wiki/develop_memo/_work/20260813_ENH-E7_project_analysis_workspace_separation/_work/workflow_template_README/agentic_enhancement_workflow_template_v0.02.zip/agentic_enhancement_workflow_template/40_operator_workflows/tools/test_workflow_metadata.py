#!/usr/bin/env python3
from __future__ import annotations

import unittest

from workflow_metadata import metadata_field, parse_dependency_reference


class MetadataFieldTests(unittest.TestCase):
    def test_depends_on_bold(self) -> None:
        self.assertEqual(metadata_field("**Depends on:** P01\n", "Depends on"), "P01")

    def test_depends_on_plain(self) -> None:
        self.assertEqual(metadata_field("Depends on: P01\n", "Depends on"), "P01")

    def test_depends_on_bullet(self) -> None:
        self.assertEqual(metadata_field("- Depends on: P01\n", "Depends on"), "P01")

    def test_gate_dependency_bold(self) -> None:
        self.assertEqual(metadata_field("**Depends on:** G03 PASS\n", "Depends on"), "G03 PASS")

    def test_required_field_empty_is_not_repaired(self) -> None:
        self.assertEqual(metadata_field("Depends on:\n", "Depends on"), "")

    def test_missing_field_is_not_inferred(self) -> None:
        self.assertEqual(metadata_field("Dependency maybe P01\n", "Depends on"), "")

    def test_other_metadata_labels_use_same_tolerance(self) -> None:
        cases = {
            "Contract status": "FROZEN",
            "Verification contract status": "FROZEN",
            "Self-containment": "MUST",
            "Information isolation": "MUST",
            "Reporting contract": "REQUIRED",
            "Gate": "G03",
            "Package": "P01",
            "Status at issuance": "DRAFT_NOT_FROZEN",
        }
        for label, expected in cases.items():
            with self.subTest(label=label):
                self.assertEqual(metadata_field(f"- {label}: {expected}\n", label), expected)


class DependencyReferenceTests(unittest.TestCase):
    def test_package_reference(self) -> None:
        ref = parse_dependency_reference("P01", known_package_ids={"P01", "P02"})
        self.assertIsNotNone(ref)
        self.assertEqual(ref.kind, "package")
        self.assertEqual(ref.identifier, "P01")

    def test_gate_pass_reference(self) -> None:
        ref = parse_dependency_reference("G03 PASS", known_gate_ids={"G02", "G03"})
        self.assertIsNotNone(ref)
        self.assertEqual(ref.kind, "gate")
        self.assertEqual(ref.identifier, "G03")
        self.assertEqual(ref.required_state, "PASS")

    def test_unclear_dependency_is_rejected(self) -> None:
        self.assertIsNone(
            parse_dependency_reference(
                "something unclear",
                known_package_ids={"P01"},
                known_gate_ids={"G03"},
            )
        )

    def test_unknown_instance_id_is_rejected(self) -> None:
        self.assertIsNone(parse_dependency_reference("P99", known_package_ids={"P01", "P02"}))


if __name__ == "__main__":
    unittest.main()
