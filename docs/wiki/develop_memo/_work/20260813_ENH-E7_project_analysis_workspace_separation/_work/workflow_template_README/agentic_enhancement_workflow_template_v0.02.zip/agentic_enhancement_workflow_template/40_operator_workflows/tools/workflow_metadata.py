#!/usr/bin/env python3
"""Shared helpers for workflow Markdown metadata parsing.

This module intentionally tolerates cosmetic Markdown differences while keeping
semantic interpretation explicit.  It does not infer labels or repair ambiguous
metadata.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True)
class DependencyReference:
    kind: str
    identifier: str
    required_state: str | None = None


def metadata_field(text: str, label: str) -> str:
    """Return a metadata field value for supported cosmetic variants.

    Accepted forms are intentionally narrow and semantically equivalent:

      **Label:** value
      Label: value
      - Label: value

    The function performs no semantic guessing. Missing or empty values return
    an empty string so the caller can apply required/optional severity policy.
    """
    escaped = re.escape(label)
    patterns = (
        rf"(?im)^\s*\*\*{escaped}\s*:\*\*\s*(.*?)\s*$",
        rf"(?im)^\s*-\s*{escaped}\s*:\s*(.*?)\s*$",
        rf"(?im)^\s*{escaped}\s*:\s*(.*?)\s*$",
    )
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1).strip()
    return ""


def parse_dependency_reference(
    value: str,
    *,
    known_package_ids: Iterable[str] = (),
    known_gate_ids: Iterable[str] = (),
) -> DependencyReference | None:
    """Parse only dependency forms whose meaning is explicit.

    Repository-derived known IDs are supplied by the caller. This prevents
    enhancement-instance IDs from being hard-coded into the protocol parser.

    Canonical minimum forms covered here:
      Pxx
      Gxx PASS

    Unknown prose is not guessed into a dependency.
    """
    value = value.strip()
    package_ids = set(known_package_ids)
    gate_ids = set(known_gate_ids)

    if value in package_ids:
        return DependencyReference(kind="package", identifier=value)

    gate_match = re.fullmatch(r"(G\d{2})\s+PASS", value, flags=re.IGNORECASE)
    if gate_match:
        gate_id = gate_match.group(1).upper()
        if gate_id in gate_ids:
            return DependencyReference(kind="gate", identifier=gate_id, required_state="PASS")

    return None
