# ENH-E7 G03/G04 Instruction Patch — Manifest

Generated files: 25

- `10_enhance_instruction/G03/06_Ariadne_ENH-E7_G03_implementation_instruction.md`
- `10_enhance_instruction/G03/06_G03_P00_work_package_plan.md`
- `10_enhance_instruction/G03/06_G03_P01_top_level_surface_activation_authority.md`
- `10_enhance_instruction/G03/06_G03_P02_projects_surface_separation.md`
- `10_enhance_instruction/G03/06_G03_P03_project_management_shell.md`
- `10_enhance_instruction/G03/06_G03_P04_analysis_workspace_shell.md`
- `10_enhance_instruction/G03/06_G03_P05_obsolete_global_shell_cleanup.md`
- `10_enhance_instruction/G03/06_G03_P06_surface_architecture_integration.md`
- `10_enhance_instruction/G03/07_Ariadne_ENH-E7_G03_test_instruction.md`
- `10_enhance_instruction/G03/08_ENH-E7_G03_TEMPLATE_Remediation_Instruction.md`
- `10_enhance_instruction/G03/09_ENH-E7_G03_TEMPLATE_Gate_Contract_Amendment.md`
- `10_enhance_instruction/G03/README.md`
- `10_enhance_instruction/G04/06_Ariadne_ENH-E7_G04_implementation_instruction.md`
- `10_enhance_instruction/G04/06_G04_P00_work_package_plan.md`
- `10_enhance_instruction/G04/06_G04_P01_root_project_route_reintegration.md`
- `10_enhance_instruction/G04/06_G04_P02_project_management_navigation_state.md`
- `10_enhance_instruction/G04/06_G04_P03_analysis_context_family_stage_state.md`
- `10_enhance_instruction/G04/06_G04_P04_cross_surface_history_navigation.md`
- `10_enhance_instruction/G04/06_G04_P05_legacy_operation_resource_regression.md`
- `10_enhance_instruction/G04/06_G04_P06_full_integration_cleanup.md`
- `10_enhance_instruction/G04/07_Ariadne_ENH-E7_G04_test_instruction.md`
- `10_enhance_instruction/G04/08_ENH-E7_G04_TEMPLATE_Remediation_Instruction.md`
- `10_enhance_instruction/G04/09_ENH-E7_G04_TEMPLATE_Gate_Contract_Amendment.md`
- `10_enhance_instruction/G04/README.md`
- `10_enhance_instruction/README.md`
