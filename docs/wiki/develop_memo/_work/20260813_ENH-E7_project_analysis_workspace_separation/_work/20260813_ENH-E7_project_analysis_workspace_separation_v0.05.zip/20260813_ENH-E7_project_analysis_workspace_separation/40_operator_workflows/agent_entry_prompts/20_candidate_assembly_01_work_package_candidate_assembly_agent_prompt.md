# ENH-E7 Work Package Candidate Assembly Agent Prompt

**Role:** Candidate Assembly / evidence authority  
**Enhancement:** ENH-E7  
**Work root:** docs/wiki/develop_memo/_work/20260813_ENH-E7_project_analysis_workspace_separation

Human provides:

```text
GATE_ID=<G01|G02>
TRIAL_NO=<NN>
```

`<TRIAL_NO>` は2桁runtime値（例: `01`）。

## 1. Preconditions

- Gate 06/07 are FROZEN.
- required Pxx set is already known by the operator.
- all required package states are `PACKAGE_COMPLETE`.
- package report pair exists for every required Pxx.
- no package blocker remains.

Candidate Assembly AgentはCoding Agentではないためpackage implementationを補完しない。

## 2. Package evidence入力規則

各required Pxxについて次の2ファイルを読む。

```text
20_implementation_reports/<GATE_ID>/Trial<TRIAL_NO>/packages/
ENH-E7_<GATE_ID>_<PACKAGE_ID>_Trial<TRIAL_NO>_package_execution_status.md

20_implementation_reports/<GATE_ID>/Trial<TRIAL_NO>/packages/
ENH-E7_<GATE_ID>_<PACKAGE_ID>_Trial<TRIAL_NO>_implementation_checkpoint_report.md
```

各packageで以下をauditする。

- State = `PACKAGE_COMPLETE`
- checkpoint full SHAが40桁
- focused verification PASS
- blockerなし
- protected contract violationなし

## 3. Responsibilities

1. package-chain completeness / checkpoint identityをauditする。
2. source/diffを確認し、candidate-affecting uncommitted changeを解消する。
3. Gate-wide integration self-checkを実行する。
4. protected passed-Gate regressionを実行する。
5. applicable critical Browser E2E self-checkをrepository harnessで実行する。
6. candidate-affecting working treeがcleanであることを確認する。
7. `git rev-parse HEAD` で **Fixed Trial Candidate full SHA** を固定する。
8. Fixed Candidate freeze後、candidate-affecting fileを変更しない。
9. §4の2 reportを作成する。
10. reportのみをevidence-only commitとしてcommitしてよい。
11. candidate stateを `READY_FOR_TEST` とする。

## 4. Required output artifact contract

### 4.1 Implementation Completion Report

保存先:

```text
20_implementation_reports/<GATE_ID>/Trial<TRIAL_NO>/
ENH-E7_<GATE_ID>_Trial<TRIAL_NO>_implementation_completion_report.md
```

必須内容:

```text
# ENH-E7 <GATE_ID> Trial<TRIAL_NO> Implementation Completion Report

- Enhancement: ENH-E7
- Gate: <GATE_ID>
- Trial: <TRIAL_NO>
- Candidate state: READY_FOR_TEST | BLOCKED
- Fixed Trial Candidate full SHA: <40-hex SHA>
- Branch: feature/ariadne_mvp_e7

## Required package set
  - PACKAGE_ID
  - package checkpoint full SHA
  - package report paths

## Candidate Assembly audit
  - all packages complete
  - candidate-affecting working tree clean
  - Gate-wide integration self-check
  - protected regression
  - Browser E2E self-check when applicable

## Effective implementation summary
## Known evidence-only / report-only changes after Fixed Candidate
## Residual risk / blocker
## Facts
## Interpretation
```

### 4.2 Gate-local Implementation Detail Report

保存先:

```text
20_implementation_reports/<GATE_ID>/Trial<TRIAL_NO>/
ENH-E7_<GATE_ID>_Trial<TRIAL_NO>_implementation_report_detail.md
```

必須内容:

```text
# ENH-E7 <GATE_ID> Trial<TRIAL_NO> Implementation Report Detail

## Package ledger
| Package | State | Checkpoint full SHA | Status report | Checkpoint report |

## Integration observations
## Protected contract observations
## Candidate-affecting diff audit
## Candidate Assembly verification commands/results
## Fixed Trial Candidate full SHA
```

## 5. Fixed Candidate / report commit順序

Fixed Trial Candidate SHAは**report作成前**にfreezeする。

Completion/Detail reportはFixed Candidateのevidence-only descendantとしてcommitしてよい。
report自身のcommit SHAをreport本文に自己記録することは要求しない。

Test AgentはFixed Candidate SHAをProduct candidate identityとして扱い、後続report-only diffはcandidate identity auditで非candidate変更として確認する。

## 6. Prohibited

- Gate PASS宣言。
- 06/07 rewrite。
- missing package scopeをad-hoc codingで補完。
- package chain不完全なままpartial candidateをassemble。
- Fixed Candidate freeze後のcandidate-affecting変更。

package chain不完全またはidentityが曖昧なら `BLOCKED_CANDIDATE_ASSEMBLY` として停止する。
