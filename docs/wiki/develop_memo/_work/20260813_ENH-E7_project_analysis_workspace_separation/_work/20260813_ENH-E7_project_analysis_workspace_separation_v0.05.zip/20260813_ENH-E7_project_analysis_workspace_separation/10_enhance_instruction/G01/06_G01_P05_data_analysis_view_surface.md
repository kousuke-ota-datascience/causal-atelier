# ENH-E7 G01 P05 — Data / Analysis View Surface

**文書種別:** Primary Execution Contract  
**Self-containment:** MUST
**Information isolation:** MUST
**Reporting contract:** SELF_CONTAINED  
**Gate:** G01  
**初回発行Trial:** 01  
**Package:** P05  
**Depends on:** P01,P03  
**Status at issuance:** DRAFT_NOT_FROZEN

## 1. 目的

DataをDataset / Version / Schema・Preview / Analysis View lifecycle managementのauthorityとする。

## 2. このpackageに適用するconstraint

- Project ManagementとAnalysis Workspaceは異なるnavigation scopeである。
- existing domain/execution semanticsを保護する。
- ENH-E6 canonical Analysis route / Family / Stage semanticsをregressionさせない。
- package completionはGate PASSではない。
- **本PxxだけがこのCoding executionのnormative workflow implementation contractである。**
- parent 06 / 07 / P00 / other PxxはHuman traceability用であり、仕様補完目的で読まない。
- source / tests / config / migrationsはimplementation substrateとして調査可能。
- 未承認backend/API/persistence semantic changeが必要なら停止する。

## 3. In scope

- Dataset Register
- Registered Dataset / Version
- Schema / Preview
- Analysis View lifecycle management

## 4. Explicitly out of scope

- Analysis ViewをFamily横断inputとして維持する。
- sourceで不可避と証明されない限りAPI/schema変更を行わない。

加えて以下はout of scope。
- Acceptance Criteria変更
- unrelated cleanup / refactoring
- next package実装

## 5. Entry criteria

- current checkoutが`feature/ariadne_mvp_e7`。
- `G01/P05/Trial01`のAgent Execution ReadinessがPASS。
- dependency `P01,P03` が満たされている。
- Architecture Review / Gate contractがexecution前にFROZEN。
- in-scope behaviorを曖昧にする未解決source factがない。

確認不能なら`PACKAGE_BLOCKED`として停止する。

## 6. Required implementation

1. §3 responsibilityを特定する範囲でcurrent source/testsを調査する。
2. §2/§4を維持して§3 behaviorを実装する。
3. repository conventionに従ってfocused testを追加・更新する。
4. substitute backend semanticsを作らない。
5. source factとcontractが矛盾する場合はsilent reinterpretせず停止する。

## 7. Focused verification

| Check | Command / method | Required result |
|---|---|---|
| focused product test | `uv run pytest -q tests/product/test_enh_e7_g01_p05_data_analysis_view_surface.py` | PASS |
| nearby regression | touched responsibilityをcoverするrepository test | PASS |
| source/diff audit | ownership/navigationを含むdiff確認 | out-of-scope semantic changeなし |

## 8. Protected contract

- Protected upstream: ENH-E6 G01 PASS candidate `575cdd139aea09d4f19b46ab6a6d38545f645c71` が確立したcanonical Analysis Family/Stage navigation / transition semantics。
- intentional open Transition Debtは導入しない。
- legacy URL compatibilityを削除しない。

## 9. Reporting artifact contract

本packageのCoding Agentは、**他のworkflow artifactを読まずに**以下2ファイルを作成する。

`<TRIAL_NO>` はoperator promptから渡された2桁runtime値（例: `01`）である。

### 9.1 Canonical保存先 / filename

#### Package Execution Status Report

```text
20_implementation_reports/G01/Trial<TRIAL_NO>/packages/
ENH-E7_G01_P05_Trial<TRIAL_NO>_package_execution_status.md
```

#### Implementation Checkpoint Report

```text
20_implementation_reports/G01/Trial<TRIAL_NO>/packages/
ENH-E7_G01_P05_Trial<TRIAL_NO>_implementation_checkpoint_report.md
```

directoryが存在しない場合は作成してよい。

### 9.2 Package Execution Status Report 必須内容

最低限、以下を本文内に持つ。

```text
# ENH-E7 G01 P05 Package Execution Status

- Enhancement: ENH-E7
- Gate: G01
- Trial: <TRIAL_NO>
- Package: P05
- State: PACKAGE_COMPLETE | PACKAGE_BLOCKED
- Branch: feature/ariadne_mvp_e7
- Baseline full SHA: 1beea1c9eb3ffa5d01f7c266b826e52136d01e8f
- Implementation checkpoint full SHA: <40-hex SHA or NOT_FIXED>

## 実施したscope
## Focused verification
  - exact command / method
  - exit code / result
## Protected contract確認
## Remaining / blocker
## Scope guard確認
  - next package workなし
  - Gate acceptance decisionなし
  - prohibited workflow-document dependencyなし
## Facts
## Interpretation
```

`PACKAGE_COMPLETE` と記録する場合、Implementation checkpoint full SHAは40桁full SHAでなければならない。

### 9.3 Implementation Checkpoint Report 必須内容

最低限、以下を本文内に持つ。

```text
# ENH-E7 G01 P05 Implementation Checkpoint Report

- Enhancement: ENH-E7
- Gate: G01
- Trial: <TRIAL_NO>
- Package: P05
- Implementation checkpoint full SHA: <40-hex SHA>
- Branch: feature/ariadne_mvp_e7

## 実装したbehavior
## Changed files / responsibility
## Focused verification
  - exact command / method
  - exit code / result
## Nearby regression
## Protected contract確認
## Checkpoint時点のcandidate-affecting working tree
## Residual risk / blocker
## Facts
## Interpretation
```

### 9.4 Commit / SHA順序

SHA自己参照を避けるため、順序を固定する。

1. source / test / config等の**candidate-affecting変更**を実装・検証する。
2. candidate-affecting変更をcommitする。
3. `git rev-parse HEAD` で **Implementation checkpoint full SHA** を固定する。
4. checkpoint固定後、当該packageについてcandidate-affecting fileを変更しない。
5. §9.1の2 reportを作成し、固定済みcheckpoint SHAを記録する。
6. reportのみを別commitとしてcommitしてよい。これは **evidence-only report commit** であり、Implementation checkpoint SHAとは別identityである。
7. report自身のcommit SHAをreport本文へ自己記録することは要求しない。自己参照commit loopを作らないためである。

checkpoint固定後にcandidate-affecting変更が必要になった場合、古いcheckpointを破棄し、再検証・再commit後に新しいfull SHAを固定してreportを更新する。

## 10. Package completion criteria

Dataset / Analysis View regressionがPASSする。

加えてfocused verification完了、unresolved blockerなし、checkpoint full SHA固定、required report作成済みであること。

## 11. External reference policy

Coding Agentはsource/test/runtime factを調査してよい。
Gate 06 / Gate 07 / P00 / other Pxx / 00 / 20 / 30をpackage specification補完目的で読まない。

本Pxxが不十分またはverified source factと矛盾する場合は
`PACKAGE_BLOCKED_CONTRACT_AMBIGUITY`として停止する。

## 12. Stop rule

- scope完了 → `PACKAGE_COMPLETE`
- 安全に継続不能 → `PACKAGE_BLOCKED`
- Gate PASS/FAILを宣言しない
- 別packageへ自動継続しない
