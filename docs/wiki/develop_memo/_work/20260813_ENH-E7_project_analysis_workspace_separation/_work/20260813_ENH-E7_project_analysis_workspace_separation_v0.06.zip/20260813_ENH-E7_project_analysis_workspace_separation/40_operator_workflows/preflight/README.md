# ENH-E7 Agent Execution Readiness Preflight

Document compliance is not enough to start an Agent.

Every Coding execution must independently PASS:

1. Artifact completeness
2. Content completeness
3. Execution resolvability
4. Information isolation

Use:

```bash
python3 docs/wiki/develop_memo/_work/20260813_ENH-E7_project_analysis_workspace_separation/40_operator_workflows/preflight/check_agent_execution_readiness.py \
  --repo-root . --gate G01 --package P02 --trial 01
```

G01/P02について以下は解決済み。

- local Git remote alias: `causal-atelier`
- E7 baseline full SHA: `1beea1c9eb3ffa5d01f7c266b826e52136d01e8f`
- Architecture Review: APPROVED
- G01 06/07: FROZEN
- G01 P02: READY_TO_EXECUTE

したがって、actual local repository上のmechanical preflightがPASSすればG01/P02 Coding executionを開始してよい。


## PRE-02 / PRE-07 rule update (v0.04)

### PRE-02

Placeholder走査では以下をnon-normativeとして除外する。

- `00_enhance_background/provenance/`
- Enhancement root直下の `_work/`

### PRE-07

自然言語の完全一致は使用しない。assigned Pxxに以下の固定metadataが存在することを検査する。

```text
**Self-containment:** MUST
**Information isolation:** MUST
```

日本語/英語の説明文は人間向けcontract本文であり、PRE-07の機械判定キーにはしない。


## PRE-16 Package reporting self-containment (v0.05)

Work Package Coding Agentのinformation isolationと矛盾しないよう、
assigned Pxx内にreport artifact contractをself-containedで持たせる。

PRE-16は以下を機械検査する。

- `**Reporting contract:** SELF_CONTAINED`
- canonical `20_implementation_reports/...` 保存先
- package execution status filename
- implementation checkpoint filename
- `Commit / SHA順序` section

Pxxがreport作成に20-layer template参照を必要とする場合はBLOCKED。
