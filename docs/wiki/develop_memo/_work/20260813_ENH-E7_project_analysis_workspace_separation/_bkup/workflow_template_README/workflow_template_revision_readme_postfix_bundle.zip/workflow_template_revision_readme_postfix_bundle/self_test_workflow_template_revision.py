#!/usr/bin/env python3
"""Self-test workflow execution-control + README postfix migration."""
from __future__ import annotations

from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile

BUNDLE = Path(__file__).resolve().parent
APPLY = BUNDLE / "apply_workflow_template_revision.py"
VALIDATE = BUNDLE / "validate_workflow_template_revision.py"

PROMPTS = [
    "10_normal_execution_01_single_execution_coding_agent_prompt.md",
    "10_normal_execution_02_work_package_coding_agent_prompt.md",
    "20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md",
    "30_independent_verification_01_test_agent_prompt.md",
    "40_fail_remediation_01_fail_rework_coding_agent_prompt.md",
    "50_orchestration_01_gate_orchestrator_prompt.md",
]
NON_WP = [name for name in PROMPTS if "_02_work_package_" not in name]


def run(*args: str | Path, expect: int = 0) -> subprocess.CompletedProcess[str]:
    cp = subprocess.run([str(a) for a in args], text=True, capture_output=True)
    if cp.returncode != expect:
        raise AssertionError(
            f"command returned {cp.returncode}, expected {expect}: {' '.join(map(str, args))}\n"
            f"stdout:\n{cp.stdout}\nstderr:\n{cp.stderr}"
        )
    return cp


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_template(root: Path, *, missing_prompt: str | None = None, collision: bool = False) -> None:
    pdir = root / "40_operator_workflows" / "agent_entry_prompts"
    pdir.mkdir(parents=True)
    (root / "README.md").write_text(
        "# Agentic Enhancement Workflow Template\n\n"
        "## 1. Intro\n\nold text\n\n"
        "## 2. エンハンス文書を作成する順序\n\n"
        "### Step 1 — Background / requirements / designを作成する\n",
        encoding="utf-8",
    )
    (root / "00_enhance_background").mkdir(parents=True)
    (root / "00_enhance_background" / "README.md").write_text(
        "# Background Index\n\n## 1. Links\n\n[root](../README.md)\n", encoding="utf-8"
    )
    trial = root / "20_implementation_reports" / "G01" / "Trial01"
    trial.mkdir(parents=True)
    (trial / "README.md").write_text("# Trial Index\n\n## 1. Report\n\nTRIAL_INDEX\n", encoding="utf-8")
    (trial / "notes.md").write_text(
        "# Trial Notes\n\n## 1. Links\n\n"
        "[local index](README.md)\n\n"
        "Full path: `20_implementation_reports/G01/Trial01/README.md`\n",
        encoding="utf-8",
    )
    opdir = root / "40_operator_workflows"
    (opdir / "README.md").write_text(
        "# Operator Workflows\n\n## 1. Existing operation\n\nKEEP_OPERATOR_README\n",
        encoding="utf-8",
    )
    (root / "TEMPLATE_STRUCTURE.md").write_text(
        "# Template Structure\n\n## 1. Existing structure\n\n"
        "Prompt index: `40_operator_workflows/agent_entry_prompts/README.md`\n",
        encoding="utf-8",
    )
    (pdir / "README.md").write_text("# Existing Prompt README\n\nKEEP_PROMPT_README\n", encoding="utf-8")
    (pdir / "00_variable_conventions.md").write_text(
        "# Existing Variable Conventions\n\nKEEP_VARIABLE_DOC\n\nSee `README.md`.\n", encoding="utf-8"
    )
    concrete = (
        "PROJECT_NAME=Ariadne\n"
        "ENHANCE_ID=ENH-E6\n"
        "ENHANCE_SHORT_ID=E6\n"
        "BRANCH_NAME=bugfix/ariadne_mvp_e6\n"
        "REMOTE_NAME=causal-atelier\n"
        "WORK_ROOT=docs/wiki/develop_memo/_work/20260813_ENH-E6_family_stage_navigation_bugfix\n"
        "WORK_DIR_NAME=20260813_ENH-E6_family_stage_navigation_bugfix\n"
    )
    for name in PROMPTS:
        if name == missing_prompt:
            continue
        (pdir / name).write_text(
            f"# Existing {name}\n\n## 1. Existing semantics\n\n"
            + concrete
            + "\nKEEP_THIS_SEMANTIC_SENTENCE\n",
            encoding="utf-8",
        )

    manifest = {
        "root": "README.md",
        "prompt_index": "40_operator_workflows/agent_entry_prompts/README.md",
        "trial_index": {"directory": "20_implementation_reports/G01/Trial01", "filename": "README.md"},
    }
    (root / "MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")

    if collision:
        (trial / "README_20_G01_Trial01.md").write_text("DIFFERENT\n", encoding="utf-8")


def instantiate(template: Path, work: Path) -> None:
    (work / "10_enhance_instruction" / "G01").mkdir(parents=True)
    (work / "10_enhance_instruction" / "G01" / "06_G01_P01_demo.md").write_text(
        "# P01 Demo\n\n"
        "## 1. Scope\nPackage scope.\n\n"
        "## 2. Constraints\nProtected constraints.\n\n"
        "## 3. Completion criteria\nFocused verification.\n\n"
        "## 4. Stop condition\nStop on ambiguity.\n",
        encoding="utf-8",
    )
    tool = template / "40_operator_workflows" / "tools" / "instantiate_agent_entry_prompts.py"
    run(
        sys.executable, tool,
        "--template-root", template,
        "--work-root", work,
        "--project-name", "Ariadne",
        "--enhance-id", "ENH-TEST",
        "--enhance-short-id", "ET",
        "--branch-name", "test/workflow",
        "--remote-name", "origin",
        "--work-dir-name", work.name,
    )


def readiness(template: Path, work: Path, *extra: str, expect: int = 0) -> subprocess.CompletedProcess[str]:
    tool = template / "40_operator_workflows" / "tools" / "validate_agent_execution_readiness.py"
    return run(sys.executable, tool, "--work-root", work, *extra, expect=expect)


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="workflow-template-revision-selftest-") as td:
        base = Path(td)
        template = base / "template"
        make_template(template)

        first = run(sys.executable, APPLY, template)
        assert "modified_created_or_deleted=" in first.stdout
        validation = run(sys.executable, VALIDATE, template)
        assert "OVERALL: PASS" in validation.stdout

        # Deterministic path-derived README naming.
        expected = [
            template / "README.md",
            template / "00_enhance_background" / "README_00.md",
            template / "20_implementation_reports" / "G01" / "Trial01" / "README_20_G01_Trial01.md",
            template / "40_operator_workflows" / "README_40.md",
            template / "40_operator_workflows" / "agent_entry_prompts" / "README_40_agent_entry_prompts.md",
        ]
        for path in expected:
            assert path.is_file(), path
        nested_plain = [p for p in template.rglob("README.md") if p.parent != template]
        assert not nested_plain, nested_plain

        # Markdown/plain-path references and MANIFEST schema are migrated.
        notes = (template / "20_implementation_reports" / "G01" / "Trial01" / "notes.md").read_text(encoding="utf-8")
        assert "[local index](README_20_G01_Trial01.md)" in notes
        assert "20_implementation_reports/G01/Trial01/README_20_G01_Trial01.md" in notes
        var_doc = (template / "40_operator_workflows" / "agent_entry_prompts" / "00_variable_conventions.md").read_text(encoding="utf-8")
        assert "README_40_agent_entry_prompts.md" in var_doc
        manifest = json.loads((template / "MANIFEST.json").read_text(encoding="utf-8"))
        assert manifest["root"] == "README.md"
        assert manifest["prompt_index"].endswith("README_40_agent_entry_prompts.md")
        assert manifest["trial_index"]["filename"] == "README_20_G01_Trial01.md"

        # Existing operational semantics are retained for prompts whose originals were unavailable.
        for name in NON_WP:
            text = (template / "40_operator_workflows" / "agent_entry_prompts" / name).read_text(encoding="utf-8")
            assert "KEEP_THIS_SEMANTIC_SENTENCE" in text, name
            for concrete in ["ENHANCE_ID=ENH-E6", "bugfix/ariadne_mvp_e6", "REMOTE_NAME=causal-atelier"]:
                assert concrete not in text, (name, concrete)

        # Heading hierarchy and README naming rule are both documented.
        root_text = (template / "README.md").read_text(encoding="utf-8")
        assert "### 2.1. Step 1 — Background / requirements / designを作成する" in root_text
        assert "Operator Quick HowToUse" in root_text
        assert "README filename = deterministic function(directory path)" in root_text

        # Second application must be content-idempotent.
        second = run(sys.executable, APPLY, template)
        assert "modified_created_or_deleted=0" in second.stdout

        # Positive instantiation/readiness and canonical Enhancement-side prompt README.
        good = base / "good"
        instantiate(template, good)
        prompt_readme = good / "40_operator_workflows" / "agent_entry_prompts" / "README_40_agent_entry_prompts.md"
        assert prompt_readme.is_file()
        assert not (prompt_readme.parent / "README.md").exists()
        positive = readiness(
            template, good,
            "--mode", "package", "--gate-id", "G01", "--package-id", "P01", "--trial-no", "01",
        )
        assert "OVERALL: READY_FOR_AGENT_EXECUTION" in positive.stdout

        # Existing execution-control negative guards.
        direct = readiness(
            template, template,
            "--mode", "package", "--gate-id", "G01", "--package-id", "P01", "--trial-no", "01",
            expect=2,
        )
        assert "CONTENT_COMPLETENESS: FAIL" in direct.stdout and "OVERALL: BLOCKED" in direct.stdout

        unresolved = base / "unresolved"
        instantiate(template, unresolved)
        wp = unresolved / "40_operator_workflows" / "agent_entry_prompts" / "10_normal_execution_02_work_package_coding_agent_prompt.md"
        wp.write_text(wp.read_text(encoding="utf-8") + "\nBRANCH_NAME={{BRANCH_NAME}}\n", encoding="utf-8")
        cp = readiness(
            template, unresolved,
            "--mode", "package", "--gate-id", "G01", "--package-id", "P01", "--trial-no", "01",
            expect=2,
        )
        assert "unresolved Enhancement-fixed placeholders" in cp.stdout

        cp = readiness(template, good, "--mode", "package", "--gate-id", "G01", "--trial-no", "01", expect=2)
        assert "missing runtime values: PACKAGE_ID" in cp.stdout

        zero = base / "zero"
        instantiate(template, zero)
        (zero / "10_enhance_instruction" / "G01" / "06_G01_P01_demo.md").unlink()
        cp = readiness(
            template, zero,
            "--mode", "package", "--gate-id", "G01", "--package-id", "P01", "--trial-no", "01",
            expect=2,
        )
        assert "assigned Pxx resolver count=0" in cp.stdout

        multi = base / "multi"
        instantiate(template, multi)
        src = multi / "10_enhance_instruction" / "G01" / "06_G01_P01_demo.md"
        (src.parent / "06_G01_P01_second.md").write_bytes(src.read_bytes())
        cp = readiness(
            template, multi,
            "--mode", "package", "--gate-id", "G01", "--package-id", "P01", "--trial-no", "01",
            expect=2,
        )
        assert "assigned Pxx resolver count=2" in cp.stdout

        bad_guard = base / "bad-guard"
        instantiate(template, bad_guard)
        wp = bad_guard / "40_operator_workflows" / "agent_entry_prompts" / "10_normal_execution_02_work_package_coding_agent_prompt.md"
        bad = wp.read_text(encoding="utf-8").replace("assigned Pxxのみ", "assigned contract")
        bad = bad.replace("仕様補完目的で以下を読んではならない", "参考資料に関する注意")
        wp.write_text(bad, encoding="utf-8")
        cp = readiness(
            template, bad_guard,
            "--mode", "package", "--gate-id", "G01", "--package-id", "P01", "--trial-no", "01",
            expect=2,
        )
        assert "INFORMATION_ISOLATION: FAIL" in cp.stdout

        bad_pxx = base / "bad-pxx"
        instantiate(template, bad_pxx)
        pxx = bad_pxx / "10_enhance_instruction" / "G01" / "06_G01_P01_demo.md"
        pxx.write_text(pxx.read_text(encoding="utf-8") + "\nGate 07を参照して仕様を補完すること。\n", encoding="utf-8")
        cp = readiness(
            template, bad_pxx,
            "--mode", "package", "--gate-id", "G01", "--package-id", "P01", "--trial-no", "01",
            expect=2,
        )
        assert "assigned Pxx appears to require forbidden specification source" in cp.stdout

        no_branch = base / "no-branch"
        instantiate(template, no_branch)
        wp = no_branch / "40_operator_workflows" / "agent_entry_prompts" / "10_normal_execution_02_work_package_coding_agent_prompt.md"
        wp.write_text(wp.read_text(encoding="utf-8").replace("BRANCH_NAME=test/workflow\n", ""), encoding="utf-8")
        cp = readiness(
            template, no_branch,
            "--mode", "package", "--gate-id", "G01", "--package-id", "P01", "--trial-no", "01",
            expect=2,
        )
        assert "selected prompt lacks explicit BRANCH_NAME" in cp.stdout

        # Missing prompt inventory blocks before any write.
        incomplete = base / "incomplete-template"
        make_template(incomplete, missing_prompt="30_independent_verification_01_test_agent_prompt.md")
        readme_before = sha(incomplete / "README.md")
        cp = run(sys.executable, APPLY, incomplete, expect=2)
        assert "refusing partial semantic synthesis" in cp.stderr
        assert sha(incomplete / "README.md") == readme_before
        assert (incomplete / "40_operator_workflows" / "README.md").exists()

        # README target collision blocks and restores the original tree.
        collision = base / "collision-template"
        make_template(collision, collision=True)
        before_root = sha(collision / "README.md")
        cp = run(sys.executable, APPLY, collision, expect=2)
        assert "BLOCKED_README_NAMING_COLLISION" in cp.stderr
        assert sha(collision / "README.md") == before_root
        assert (collision / "20_implementation_reports" / "G01" / "Trial01" / "README.md").exists()

    print("SELF TEST: PASS")
    print("- deterministic nested README naming: PASS")
    print("- Markdown/plain path reference migration: PASS")
    print("- MANIFEST path + directory/filename migration: PASS")
    print("- instantiation/readiness use canonical naming function: PASS")
    print("- root README.md remains unqualified: PASS")
    print("- nested README.md count == 0 after migration: PASS")
    print("- collision guard + fail-before-write: PASS")
    print("- prior execution-control/heading guards: PASS")
    print("- idempotent second apply: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
