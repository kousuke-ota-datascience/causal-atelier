# Existing Prompt README

## 1. Existing
KEEP_README

<!-- BEGIN MANAGED: AGENT_ENTRY_PROMPT_CONTROL -->
## 2. Agent Entry Prompts

### 2.1. Purpose

このdirectoryはAgent execution entry pointのgeneric templateを保持する。

**template directory上のpromptをAgentへ直接渡してはならない。** Enhancement開始時にEnhancement-specific instanceを `{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/` へ生成し、Enhancement-fixed variablesを全て展開してから使用する。

### 2.2. Prompt inventory

| File | Role | Runtime variables |
|---|---|---|
| `10_normal_execution_01_single_execution_coding_agent_prompt.md` | Single Execution Coding Agent | `GATE_ID`, `TRIAL_NO` |
| `10_normal_execution_02_work_package_coding_agent_prompt.md` | Work Package Coding Agent | `GATE_ID`, `PACKAGE_ID`, `TRIAL_NO` |
| `20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md` | Fixed Trial Candidate Assembly | `GATE_ID`, `TRIAL_NO` |
| `30_independent_verification_01_test_agent_prompt.md` | Independent Verification | `GATE_ID`, `TRIAL_NO` |
| `40_fail_remediation_01_fail_rework_coding_agent_prompt.md` | Formal FAIL Remediation Coding | `GATE_ID`, `REMEDIATION_PACKAGE_ID`, `TRIAL_NO` |
| `50_orchestration_01_gate_orchestrator_prompt.md` | Gate-wide Orchestration | `GATE_ID`, `TRIAL_NO` |

### 2.3. Instantiation MUST

Enhancement開始時に `../tools/instantiate_agent_entry_prompts.py` または同等の手順でこのdirectoryをEnhancement work rootへinstance化する。

instance化完了条件:

1. Enhancement-side `agent_entry_prompts/` が存在する。
2. Enhancement-fixed placeholdersが0件である。
3. `WORK_ROOT` がexactly one Enhancement rootを指す。
4. branch / remote identityが具体値である。

未達ならAgent executionを開始しない。

### 2.4. Agent Execution Readiness

Document/template complianceとAgent Execution Readinessを別判定する。

| Axis | Required check |
|---|---|
| Artifact completeness | 必須instance artifactが存在する |
| Content completeness | required section/fieldを省略していない |
| Execution resolvability | Human entryからEnhancement/Gate/Package/Trial等が一意 |
| Information isolation | Agentが許可されたnormative sourceだけで実行可能 |

template-side `40_operator_workflows/tools/validate_agent_execution_readiness.py` をexecution前に使用し、`--work-root` へEnhancement work rootを渡す。tools directory自体はEnhancement-side `agent_entry_prompts/` instanceへ複製する必要はない。

### 2.5. Information isolation

Work Package Coding Agentのnormative workflow documentはassigned Pxxのみである。

```text
Normative workflow document reachable by Work Package Coding Agent = assigned Pxx only
```

Human/auditor向けtraceability linkをCoding Agentのread dependencyにしてはならない。

Independent Test AgentはGate 07をverification authorityとして使用する。Gate 07をCoding Agentのacceptance-answer keyとして露出させてはならない。

### 2.6. README identity

このdirectoryのlocal README canonical filenameは `README_40_agent_entry_prompts.md` とする。root以外の無印 `README.md` は禁止する。

filenameは手作業で決めず、`40_operator_workflows/tools/readme_naming.py` のpath-derived naming functionから導出する。
<!-- END MANAGED: AGENT_ENTRY_PROMPT_CONTROL -->
