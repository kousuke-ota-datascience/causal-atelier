# Operator Quick HowToUse

## 1. Prerequisite

以下のentry instructionは、**Enhancement-specificにinstance化済みの** `{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/` を参照する。

template directory上の `agentic_enhancement_workflow_template/40_operator_workflows/agent_entry_prompts/` をAgentへ直接指定してはならない。

## 2. SINGLE EXECUTION

```text
下記文書に記載の指示を実行すること。

- {{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/
    - 10_normal_execution_01_single_execution_coding_agent_prompt.md

今回の指示は
- GATE_ID=<GATE_ID>
- TRIAL_NO=<TRIAL_NO>
である。
```

## 3. WORK PACKAGE EXECUTION — STEP by STEP

```text
下記文書に記載の指示を実行すること。

- {{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/
    - 10_normal_execution_02_work_package_coding_agent_prompt.md

今回の指示は
- GATE_ID=<GATE_ID>
- PACKAGE_ID=<PACKAGE_ID>
- TRIAL_NO=<TRIAL_NO>
である。
```

## 4. CANDIDATE ASSEMBLY

```text
下記文書に記載の指示を実行すること。

- {{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/
    - 20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md

今回の指示は
- GATE_ID=<GATE_ID>
- TRIAL_NO=<TRIAL_NO>
である。
```

## 5. INDEPENDENT VERIFICATION

```text
下記文書に記載の指示を実行すること。

- {{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/
    - 30_independent_verification_01_test_agent_prompt.md

今回の指示は
- GATE_ID=<GATE_ID>
- TRIAL_NO=<TRIAL_NO>
である。
```

## 6. FORMAL FAIL REMEDIATION

```text
下記文書に記載の指示を実行すること。

- {{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/
    - 40_fail_remediation_01_fail_rework_coding_agent_prompt.md

今回の指示は
- GATE_ID=<GATE_ID>
- REMEDIATION_PACKAGE_ID=<REMEDIATION_PACKAGE_ID>
- TRIAL_NO=<TRIAL_NO>
である。
```

## 7. GATE WIDE AUTONOMOUS EXECUTION

```text
下記文書に記載の指示を実行すること。

- {{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/
    - 50_orchestration_01_gate_orchestrator_prompt.md

今回の指示は
- GATE_ID=<GATE_ID>
- TRIAL_NO=<TRIAL_NO>
である。
```


## 8. SUPPORTING DOCUMENTS — NOT DIRECT EXECUTION ENTRY POINTS

以下もEnhancement-specific `agent_entry_prompts/` instanceへ含めるが、Human operatorがAgentへ直接指定するexecution promptではない。

- `README_40_agent_entry_prompts.md`
- `00_variable_conventions.md`

Agent起動前にtemplate-side readiness validatorを実行し、`OVERALL: READY_FOR_AGENT_EXECUTION` の場合のみ上記entry instructionを使用する。
