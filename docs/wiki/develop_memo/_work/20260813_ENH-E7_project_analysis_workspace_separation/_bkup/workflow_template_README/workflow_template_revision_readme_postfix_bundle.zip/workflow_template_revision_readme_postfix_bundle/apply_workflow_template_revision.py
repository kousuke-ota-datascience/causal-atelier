#!/usr/bin/env python3
"""Apply workflow execution-control + deterministic nested README naming revisions.

The script is idempotent and does not commit or push.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
import shutil
import sys
from typing import Any

from readme_naming import (
    nested_readme_migration_map,
    readme_filename_for_directory,
    validate_readme_names,
)

BEGIN_EXEC = "<!-- BEGIN MANAGED: WORKFLOW_EXECUTION_CONTROL -->"
END_EXEC = "<!-- END MANAGED: WORKFLOW_EXECUTION_CONTROL -->"
BEGIN_HOWTO = "<!-- BEGIN MANAGED: OPERATOR_QUICK_HOWTOUSE -->"
END_HOWTO = "<!-- END MANAGED: OPERATOR_QUICK_HOWTOUSE -->"
BEGIN_STRUCTURE = "<!-- BEGIN MANAGED: EXECUTION_CONTROL_STRUCTURE -->"
END_STRUCTURE = "<!-- END MANAGED: EXECUTION_CONTROL_STRUCTURE -->"
BEGIN_IDENTITY = "<!-- BEGIN MANAGED: EXECUTION_IDENTITY_CONTROL -->"
END_IDENTITY = "<!-- END MANAGED: EXECUTION_IDENTITY_CONTROL -->"
BEGIN_PROMPT_DOC = "<!-- BEGIN MANAGED: AGENT_ENTRY_PROMPT_CONTROL -->"
END_PROMPT_DOC = "<!-- END MANAGED: AGENT_ENTRY_PROMPT_CONTROL -->"
BEGIN_README_NAMING = "<!-- BEGIN MANAGED: README_NAMING_CONVENTION -->"
END_README_NAMING = "<!-- END MANAGED: README_NAMING_CONVENTION -->"

FIXED = [
    "PROJECT_NAME",
    "ENHANCE_ID",
    "ENHANCE_SHORT_ID",
    "BRANCH_NAME",
    "REMOTE_NAME",
    "WORK_ROOT",
    "WORK_DIR_NAME",
]

RUNTIME_BY_PROMPT = {
    "10_normal_execution_01_single_execution_coding_agent_prompt.md": ["GATE_ID", "TRIAL_NO"],
    "20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md": ["GATE_ID", "TRIAL_NO"],
    "30_independent_verification_01_test_agent_prompt.md": ["GATE_ID", "TRIAL_NO"],
    "40_fail_remediation_01_fail_rework_coding_agent_prompt.md": ["GATE_ID", "REMEDIATION_PACKAGE_ID", "TRIAL_NO"],
    "50_orchestration_01_gate_orchestrator_prompt.md": ["GATE_ID", "TRIAL_NO"],
}

REQUIRED_EXECUTION_PROMPTS = [
    "00_variable_conventions.md",
    "10_normal_execution_01_single_execution_coding_agent_prompt.md",
    "10_normal_execution_02_work_package_coding_agent_prompt.md",
    "20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md",
    "30_independent_verification_01_test_agent_prompt.md",
    "40_fail_remediation_01_fail_rework_coding_agent_prompt.md",
    "50_orchestration_01_gate_orchestrator_prompt.md",
]

TEXT_EXTENSIONS = {
    ".md", ".py", ".json", ".yaml", ".yml", ".toml", ".txt", ".sh", ".bash", ".zsh", ".ini", ".cfg"
}
SKIP_PARTS = {".git", ".venv", "node_modules", "__pycache__"}


def replace_managed(text: str, begin: str, end: str, body: str) -> str:
    block = f"{begin}\n{body.rstrip()}\n{end}"
    pattern = re.compile(re.escape(begin) + r".*?" + re.escape(end), re.S)
    if pattern.search(text):
        return pattern.sub(block, text)
    return text.rstrip() + "\n\n" + block + "\n"


def demote_fragment_title(fragment: str) -> str:
    out: list[str] = []
    in_fence = False
    fence_token: str | None = None
    for line in fragment.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            token = stripped[:3]
            if not in_fence:
                in_fence = True
                fence_token = token
            elif token == fence_token:
                in_fence = False
                fence_token = None
            out.append(line)
            continue
        if in_fence:
            out.append(line)
            continue
        m = re.match(r"^(#{1,5})(\s+.+)$", line)
        out.append("#" + m.group(1) + m.group(2) if m else line)
    return "\n".join(out)


def strip_numeric_prefix(label: str) -> str:
    return re.sub(r"^\s*\d+(?:\.\d+)*\.\s+", "", label).strip()


def renumber_markdown(text: str) -> str:
    counters = [0] * 7
    out: list[str] = []
    in_fence = False
    fence_token: str | None = None
    for line in text.splitlines():
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            token = stripped[:3]
            if not in_fence:
                in_fence = True
                fence_token = token
            elif token == fence_token:
                in_fence = False
                fence_token = None
            out.append(line)
            continue
        if in_fence:
            out.append(line)
            continue
        m = re.match(r"^(#{1,6})\s+(.+?)\s*$", line)
        if not m:
            out.append(line)
            continue
        level = len(m.group(1))
        label = m.group(2)
        if level == 1:
            counters = [0] * 7
            out.append(f"# {strip_numeric_prefix(label)}")
            continue
        counters[level] += 1
        for deeper in range(level + 1, 7):
            counters[deeper] = 0
        for parent in range(2, level):
            if counters[parent] == 0:
                counters[parent] = 1
        number = ".".join(str(counters[i]) for i in range(2, level + 1)) + "."
        out.append(f"{'#' * level} {number} {strip_numeric_prefix(label)}")
    return "\n".join(out) + ("\n" if text.endswith("\n") else "")


def ensure_base_file(path: Path, title: str) -> None:
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"# {title}\n", encoding="utf-8")


def copy_file_if_changed(src: Path, dst: Path) -> bool:
    dst.parent.mkdir(parents=True, exist_ok=True)
    new = src.read_bytes()
    old = dst.read_bytes() if dst.exists() else None
    if old == new:
        return False
    dst.write_bytes(new)
    return True


def genericize_fixed_assignments(text: str) -> str:
    discovered: dict[str, str] = {}
    for key in FIXED:
        m = re.search(rf"(?m)^\s*{re.escape(key)}\s*=\s*(.+?)\s*$", text)
        if m:
            value = m.group(1).strip()
            if not value.startswith("{{"):
                discovered[key] = value
    if "WORK_ROOT" in discovered and "WORK_DIR_NAME" not in discovered:
        discovered["WORK_DIR_NAME"] = discovered["WORK_ROOT"].rstrip("/").split("/")[-1]
    for key, value in sorted(discovered.items(), key=lambda item: len(item[1]), reverse=True):
        if value and len(value) >= 2:
            text = text.replace(value, "{{" + key + "}}")
    for key in FIXED:
        text = re.sub(
            rf"(?m)^(\s*{re.escape(key)}\s*=\s*).+$",
            lambda m, key=key: m.group(1) + "{{" + key + "}}",
            text,
        )
    return text


def prompt_identity_block(runtime: list[str]) -> str:
    fixed_lines = "\n".join(f"{key}={{{{{key}}}}}" for key in FIXED)
    runtime_lines = "\n".join(f"{key}={{{{{key}}}}}" for key in runtime)
    return (
        "## Execution identity control\n\n"
        "This prompt MUST be instantiated under `{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/` "
        "before Agent execution. The template-side prompt MUST NOT be executed directly.\n\n"
        "Enhancement-fixed values:\n\n"
        f"```text\n{fixed_lines}\n```\n\n"
        "Runtime values for this execution:\n\n"
        f"```text\n{runtime_lines}\n```\n\n"
        "If any Enhancement-fixed value remains unresolved in the Enhancement-side prompt, stop with "
        "`BLOCKED_ENHANCEMENT_IDENTITY_UNRESOLVED`. If required Runtime values are missing or ambiguous, "
        "stop with `BLOCKED_EXECUTION_UNRESOLVABLE`.\n"
    )


def prompt_support_readme_name(template_root: Path) -> str:
    prompt_dir = template_root / "40_operator_workflows" / "agent_entry_prompts"
    return readme_filename_for_directory(template_root, prompt_dir)


def require_prompt_inventory(template_root: Path) -> None:
    prompt_dir = template_root / "40_operator_workflows" / "agent_entry_prompts"
    support_new = prompt_support_readme_name(template_root)
    support_exists = (prompt_dir / support_new).is_file() or (prompt_dir / "README.md").is_file()
    missing = [name for name in REQUIRED_EXECUTION_PROMPTS if not (prompt_dir / name).is_file()]
    if not support_exists:
        missing.insert(0, f"README.md or {support_new}")
    if missing:
        formatted = "\n  - ".join(missing)
        raise RuntimeError(
            "required existing agent_entry_prompts inventory is incomplete; refusing partial semantic synthesis:\n"
            f"  - {formatted}"
        )


def preflight_readme_migration(template_root: Path) -> dict[Path, Path]:
    try:
        mapping = nested_readme_migration_map(template_root)
    except ValueError as exc:
        raise RuntimeError(f"BLOCKED_README_NAMING_COLLISION: {exc}") from exc
    for old, new in mapping.items():
        if new.exists() and new != old and new.read_bytes() != old.read_bytes():
            raise RuntimeError(
                "BLOCKED_README_NAMING_COLLISION: target already exists with different content: "
                f"{old.relative_to(template_root)} -> {new.relative_to(template_root)}"
            )
    manifest = template_root / "MANIFEST.json"
    if manifest.is_file():
        try:
            json.loads(manifest.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise RuntimeError(f"MANIFEST.json is invalid JSON; refusing cross-schema migration: {exc}") from exc
    return mapping


def rename_nested_readmes(template_root: Path, mapping: dict[Path, Path]) -> list[Path]:
    changed: list[Path] = []
    for old, new in sorted(mapping.items(), key=lambda item: len(item[0].parts), reverse=True):
        new.parent.mkdir(parents=True, exist_ok=True)
        if new.exists():
            if new.read_bytes() != old.read_bytes():
                raise RuntimeError(f"BLOCKED_README_NAMING_COLLISION: {old} -> {new}")
            old.unlink()
        else:
            old.rename(new)
        changed.append(new)
    return changed


def _replace_markdown_link_targets(text: str, file_path: Path, mapping: dict[Path, Path]) -> str:
    # Resolve only local Markdown link targets; external URLs are untouched.
    pattern = re.compile(r"(?P<prefix>!?\[[^\]]*\]\()(?P<target><[^>]+>|[^)\s]+)(?P<suffix>(?:\s+['\"][^'\"]*['\"])?\))")

    resolved_map = {old.resolve(): new.resolve() for old, new in mapping.items()}

    def repl(match: re.Match[str]) -> str:
        raw = match.group("target")
        wrapped = raw.startswith("<") and raw.endswith(">")
        target = raw[1:-1] if wrapped else raw
        if re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", target) or target.startswith("#"):
            return match.group(0)
        path_part, sep, fragment = target.partition("#")
        if not path_part:
            return match.group(0)
        candidate = (file_path.parent / path_part).resolve()
        new_abs = resolved_map.get(candidate)
        if new_abs is None:
            return match.group(0)
        new_rel = os.path.relpath(new_abs, file_path.parent).replace(os.sep, "/")
        if path_part.startswith("./") and not new_rel.startswith("."):
            new_rel = "./" + new_rel
        new_target = new_rel + (sep + fragment if sep else "")
        if wrapped:
            new_target = "<" + new_target + ">"
        return match.group("prefix") + new_target + match.group("suffix")

    return pattern.sub(repl, text)


def _plain_reference_replacements(text: str, file_path: Path, template_root: Path, mapping: dict[Path, Path]) -> str:
    for old, new in sorted(mapping.items(), key=lambda item: len(item[0].as_posix()), reverse=True):
        old_rel_root = old.relative_to(template_root).as_posix()
        new_rel_root = new.relative_to(template_root).as_posix()
        text = text.replace(old_rel_root, new_rel_root)
        text = text.replace(old_rel_root.replace("/", "\\"), new_rel_root.replace("/", "\\"))

        old_rel_file = os.path.relpath(old, file_path.parent).replace(os.sep, "/")
        new_rel_file = os.path.relpath(new, file_path.parent).replace(os.sep, "/")
        if old_rel_file != "README.md":
            text = text.replace(old_rel_file, new_rel_file)
        elif file_path.parent.resolve() == old.parent.resolve():
            # Same-directory local index references. Restrict the basename
            # replacement to path/link/code-like wrappers to avoid rewriting
            # prose about the root README.md.
            for left, right in [
                ("`README.md`", f"`{new.name}`"),
                ("'README.md'", f"'{new.name}'"),
                ('"README.md"', f'"{new.name}"'),
                ("(README.md)", f"({new.name})"),
                ("(./README.md)", f"(./{new.name})"),
            ]:
                text = text.replace(left, right)
    return text


def rewrite_references(template_root: Path, mapping: dict[Path, Path]) -> list[Path]:
    if not mapping:
        return []
    changed: list[Path] = []
    for path in sorted(template_root.rglob("*")):
        if not path.is_file() or any(part in SKIP_PARTS for part in path.parts):
            continue
        if path.suffix.lower() not in TEXT_EXTENSIONS:
            continue
        try:
            old_text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        new_text = old_text
        if path.suffix.lower() == ".md":
            new_text = _replace_markdown_link_targets(new_text, path, mapping)
        new_text = _plain_reference_replacements(new_text, path, template_root, mapping)
        if new_text != old_text:
            path.write_text(new_text, encoding="utf-8")
            changed.append(path)
    return changed


def _rewrite_manifest_object(obj: Any, template_root: Path, mapping: dict[Path, Path]) -> tuple[Any, bool]:
    changed = False
    old_to_new_rel = {
        old.relative_to(template_root).as_posix(): new.relative_to(template_root).as_posix()
        for old, new in mapping.items()
    }
    if isinstance(obj, str):
        new_value = obj
        for old_rel, new_rel in old_to_new_rel.items():
            new_value = new_value.replace(old_rel, new_rel)
        return new_value, new_value != obj
    if isinstance(obj, list):
        out = []
        for item in obj:
            new_item, item_changed = _rewrite_manifest_object(item, template_root, mapping)
            changed |= item_changed
            out.append(new_item)
        return out, changed
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for key, value in obj.items():
            new_value, item_changed = _rewrite_manifest_object(value, template_root, mapping)
            changed |= item_changed
            out[key] = new_value

        # Support manifests that split directory + filename instead of storing
        # one path string. Only rewrite when directory context identifies a
        # nested README unambiguously.
        dir_value = None
        for key in ("directory", "dir", "parent", "parent_path"):
            if isinstance(out.get(key), str):
                dir_value = out[key]
                break
        if dir_value:
            dir_path = (template_root / dir_value).resolve()
            for key in ("filename", "file", "name"):
                if out.get(key) == "README.md" and dir_path != template_root.resolve():
                    try:
                        expected = readme_filename_for_directory(template_root, dir_path)
                    except ValueError:
                        continue
                    out[key] = expected
                    changed = True
        return out, changed
    return obj, False


def patch_manifest(template_root: Path, mapping: dict[Path, Path]) -> list[Path]:
    manifest = template_root / "MANIFEST.json"
    if not manifest.is_file():
        return []
    old_text = manifest.read_text(encoding="utf-8")
    data = json.loads(old_text)
    new_data, changed = _rewrite_manifest_object(data, template_root, mapping)
    if not changed:
        return []
    new_text = json.dumps(new_data, ensure_ascii=False, indent=2) + "\n"
    manifest.write_text(new_text, encoding="utf-8")
    return [manifest]


def copy_control_plane(bundle_root: Path, template_root: Path) -> list[Path]:
    overlay = bundle_root / "overlay"
    rels = [
        Path("40_operator_workflows/agent_entry_prompts/10_normal_execution_02_work_package_coding_agent_prompt.md"),
        Path("40_operator_workflows/preflight/AGENT_EXECUTION_READINESS.md"),
        Path("40_operator_workflows/tools/instantiate_agent_entry_prompts.py"),
        Path("40_operator_workflows/tools/validate_agent_execution_readiness.py"),
        Path("40_operator_workflows/tools/readme_naming.py"),
    ]
    changed = []
    for rel in rels:
        if copy_file_if_changed(overlay / rel, template_root / rel):
            changed.append(template_root / rel)
    return changed


def patch_existing_prompts(bundle_root: Path, template_root: Path) -> list[Path]:
    changed = []
    prompt_dir = template_root / "40_operator_workflows" / "agent_entry_prompts"
    overlay_dir = bundle_root / "overlay" / "40_operator_workflows" / "agent_entry_prompts"
    prompt_dir.mkdir(parents=True, exist_ok=True)

    for name, runtime in RUNTIME_BY_PROMPT.items():
        dst = prompt_dir / name
        if not dst.exists():
            raise RuntimeError(f"required existing prompt disappeared during apply: {dst}")
        old = dst.read_text(encoding="utf-8")
        new = genericize_fixed_assignments(old)
        new = replace_managed(new, BEGIN_IDENTITY, END_IDENTITY, prompt_identity_block(runtime))
        if new != old:
            dst.write_text(new, encoding="utf-8")
            changed.append(dst)

    support_name = prompt_support_readme_name(template_root)
    support_docs = [support_name, "00_variable_conventions.md"]
    for name in support_docs:
        dst = prompt_dir / name
        source_body = (overlay_dir / name).read_text(encoding="utf-8")
        if not dst.exists():
            dst.write_text(source_body, encoding="utf-8")
            changed.append(dst)
            continue
        old = dst.read_text(encoding="utf-8")
        new = replace_managed(old, BEGIN_PROMPT_DOC, END_PROMPT_DOC, demote_fragment_title(source_body))
        if new != old:
            dst.write_text(new, encoding="utf-8")
            changed.append(dst)
    return changed


def readme_naming_managed_body(bundle_root: Path) -> str:
    fragment = (bundle_root / "README_NAMING_CONVENTION.md").read_text(encoding="utf-8")
    return demote_fragment_title(fragment)


def patch_docs(bundle_root: Path, template_root: Path) -> list[Path]:
    changed = []
    root_readme = template_root / "README.md"
    operator_dir = template_root / "40_operator_workflows"
    operator_readme = operator_dir / readme_filename_for_directory(template_root, operator_dir)
    structure = template_root / "TEMPLATE_STRUCTURE.md"
    ensure_base_file(root_readme, "Agentic Enhancement Workflow Template")
    ensure_base_file(operator_readme, "Operator Workflows")
    ensure_base_file(structure, "Template Structure")
    convention_doc = template_root / "README_NAMING_CONVENTION.md"
    if copy_file_if_changed(bundle_root / "README_NAMING_CONVENTION.md", convention_doc):
        changed.append(convention_doc)

    exec_fragment = demote_fragment_title((bundle_root / "EXECUTION_CONTROL_SECTION.md").read_text(encoding="utf-8"))
    howto_fragment = demote_fragment_title((bundle_root / "OPERATOR_QUICK_HOWTOUSE.md").read_text(encoding="utf-8"))
    naming_fragment = readme_naming_managed_body(bundle_root)

    for path in [root_readme, operator_readme]:
        old = path.read_text(encoding="utf-8")
        new = replace_managed(old, BEGIN_EXEC, END_EXEC, exec_fragment)
        new = replace_managed(new, BEGIN_HOWTO, END_HOWTO, howto_fragment)
        new = replace_managed(new, BEGIN_README_NAMING, END_README_NAMING, naming_fragment)
        if new != old:
            path.write_text(new, encoding="utf-8")
            changed.append(path)

    support_name = prompt_support_readme_name(template_root)
    structure_body = f"""## Execution control, README identity, and instantiated prompts

The template-side `40_operator_workflows/agent_entry_prompts/` directory is an authoring source, not a runnable Enhancement instance.

Nested local README names are path-derived. The template root alone keeps `README.md`; all nested README files use `README_<PATH_ID>.md`. Canonical implementation: `40_operator_workflows/tools/readme_naming.py`.

Each Enhancement MUST instantiate the full prompt inventory under:

```text
{{{{WORK_ROOT}}}}/40_operator_workflows/agent_entry_prompts/
```

The instantiated set MUST contain:

- `{support_name}`
- `00_variable_conventions.md`
- `10_normal_execution_01_single_execution_coding_agent_prompt.md`
- `10_normal_execution_02_work_package_coding_agent_prompt.md`
- `20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md`
- `30_independent_verification_01_test_agent_prompt.md`
- `40_fail_remediation_01_fail_rework_coding_agent_prompt.md`
- `50_orchestration_01_gate_orchestrator_prompt.md`

Execution-control tooling is located under `40_operator_workflows/tools/` and readiness policy under `40_operator_workflows/preflight/AGENT_EXECUTION_READINESS.md`.
"""
    old = structure.read_text(encoding="utf-8")
    new = replace_managed(old, BEGIN_STRUCTURE, END_STRUCTURE, structure_body)
    new = replace_managed(new, BEGIN_README_NAMING, END_README_NAMING, naming_fragment)
    if new != old:
        structure.write_text(new, encoding="utf-8")
        changed.append(structure)
    return changed


def renumber_tree(template_root: Path) -> list[Path]:
    changed = []
    for path in sorted(template_root.rglob("*.md")):
        if any(part in SKIP_PARTS for part in path.parts):
            continue
        old = path.read_text(encoding="utf-8")
        new = renumber_markdown(old)
        if new != old:
            path.write_text(new, encoding="utf-8")
            changed.append(path)
    return changed


def snapshot_tree(root: Path) -> dict[Path, bytes]:
    snapshot: dict[Path, bytes] = {}
    for path in sorted(root.rglob("*")):
        if not path.is_file() or any(part in SKIP_PARTS for part in path.parts):
            continue
        snapshot[path.relative_to(root)] = path.read_bytes()
    return snapshot


def restore_snapshot(root: Path, snapshot: dict[Path, bytes]) -> None:
    current = [p for p in root.rglob("*") if p.is_file() and not any(part in SKIP_PARTS for part in p.parts)]
    for path in current:
        rel = path.relative_to(root)
        if rel not in snapshot:
            path.unlink()
    for rel, content in snapshot.items():
        path = root / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("template_root", type=Path, help="path to agentic_enhancement_workflow_template")
    p.add_argument("--no-renumber", action="store_true", help="skip hierarchical heading normalization")
    args = p.parse_args()

    template_root = args.template_root.resolve()
    if not template_root.is_dir():
        print(f"not a directory: {template_root}", file=sys.stderr)
        return 2

    try:
        require_prompt_inventory(template_root)
        readme_mapping = preflight_readme_migration(template_root)
    except RuntimeError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    before = snapshot_tree(template_root)
    bundle_root = Path(__file__).resolve().parent
    try:
        rename_nested_readmes(template_root, readme_mapping)
        rewrite_references(template_root, readme_mapping)
        patch_manifest(template_root, readme_mapping)
        copy_control_plane(bundle_root, template_root)
        patch_existing_prompts(bundle_root, template_root)
        patch_docs(bundle_root, template_root)
        if not args.no_renumber:
            renumber_tree(template_root)
        name_errors = validate_readme_names(template_root)
        if name_errors:
            raise RuntimeError("README naming validation failed:\n  - " + "\n  - ".join(name_errors))
    except Exception as exc:
        restore_snapshot(template_root, before)
        print(f"apply failed; original tree restored: {exc}", file=sys.stderr)
        return 2

    after = snapshot_tree(template_root)
    modified = sorted(set(before) | set(after))
    modified = [rel for rel in modified if before.get(rel) != after.get(rel)]
    print(f"modified_created_or_deleted={len(modified)}")
    for rel in modified:
        state = "DELETED" if rel not in after else ("CREATED" if rel not in before else "MODIFIED")
        print(f"{state}: {rel}")
    print("No git commit/push was performed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
