# Workflow Execution Control

## 1. Template-side prompt direct execution prohibition

`agentic_enhancement_workflow_template/40_operator_workflows/agent_entry_prompts/` はauthoring sourceであり、Agent executionへ直接指定してはならない。

Enhancement開始時にEnhancement-specific prompt instanceを以下へ生成する。

```text
{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/
```

## 2. Variable lifecycle

Enhancement-fixed variablesはinstance化時に確定する。

```text
PROJECT_NAME
ENHANCE_ID
ENHANCE_SHORT_ID
BRANCH_NAME
REMOTE_NAME
WORK_ROOT
WORK_DIR_NAME
```

Runtime variablesだけをexecution時にHuman operator / Orchestratorが与える。

```text
GATE_ID
PACKAGE_ID
TRIAL_NO
REMEDIATION_PACKAGE_ID
AMENDMENT_ID
```

## 3. Coding Agent context isolation

Work Package Coding Agentのnormative contextはassigned Pxxだけとする。

Human/auditor traceabilityとAgent-visible normative contextを分離する。

```text
Human traceability != Agent-visible normative context
```

## 4. Execution readiness

Document complianceとAgent Execution Readinessを独立判定する。readinessがFAILならAgentを起動しない。

最低4軸:

1. Artifact completeness
2. Content completeness
3. Execution resolvability
4. Information isolation
