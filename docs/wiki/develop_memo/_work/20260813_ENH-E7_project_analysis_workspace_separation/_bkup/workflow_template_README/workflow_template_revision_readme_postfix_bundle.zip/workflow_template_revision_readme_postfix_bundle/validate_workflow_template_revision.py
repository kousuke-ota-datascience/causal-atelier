#!/usr/bin/env python3
"""Validate execution-control, heading, and deterministic README naming invariants."""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import re
from typing import Any

from readme_naming import readme_filename_for_directory, validate_readme_names

PROMPTS = [
    "10_normal_execution_01_single_execution_coding_agent_prompt.md",
    "10_normal_execution_02_work_package_coding_agent_prompt.md",
    "20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md",
    "30_independent_verification_01_test_agent_prompt.md",
    "40_fail_remediation_01_fail_rework_coding_agent_prompt.md",
    "50_orchestration_01_gate_orchestrator_prompt.md",
]
RUNTIME_BY_PROMPT = {
    "10_normal_execution_01_single_execution_coding_agent_prompt.md": {"GATE_ID", "TRIAL_NO"},
    "10_normal_execution_02_work_package_coding_agent_prompt.md": {"GATE_ID", "PACKAGE_ID", "TRIAL_NO"},
    "20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md": {"GATE_ID", "TRIAL_NO"},
    "30_independent_verification_01_test_agent_prompt.md": {"GATE_ID", "TRIAL_NO"},
    "40_fail_remediation_01_fail_rework_coding_agent_prompt.md": {"GATE_ID", "REMEDIATION_PACKAGE_ID", "TRIAL_NO"},
    "50_orchestration_01_gate_orchestrator_prompt.md": {"GATE_ID", "TRIAL_NO"},
}
FIXED = ["PROJECT_NAME", "ENHANCE_ID", "ENHANCE_SHORT_ID", "BRANCH_NAME", "REMOTE_NAME", "WORK_ROOT", "WORK_DIR_NAME"]
SKIP_PARTS = {".git", ".venv", "node_modules", "__pycache__"}
TEXT_EXTENSIONS = {".md", ".py", ".json", ".yaml", ".yml", ".toml", ".txt", ".sh", ".ini", ".cfg"}


def heading_errors(path: Path) -> list[str]:
    errors = []
    counters = [0] * 7
    in_fence = False
    fence = None
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        s = line.lstrip()
        if s.startswith("```") or s.startswith("~~~"):
            tok = s[:3]
            if not in_fence:
                in_fence, fence = True, tok
            elif tok == fence:
                in_fence, fence = False, None
            continue
        if in_fence:
            continue
        m = re.match(r"^(#{1,6})\s+(.+)$", line)
        if not m:
            continue
        level = len(m.group(1))
        label = m.group(2)
        if level == 1:
            counters = [0] * 7
            if re.match(r"^\d+(?:\.\d+)*\.\s+", label):
                errors.append(f"{path}:{lineno}: H1 must not be numbered")
            continue
        counters[level] += 1
        for deeper in range(level + 1, 7):
            counters[deeper] = 0
        for parent in range(2, level):
            if counters[parent] == 0:
                counters[parent] = 1
        expected = ".".join(str(counters[i]) for i in range(2, level + 1)) + "."
        if not label.startswith(expected + " "):
            errors.append(f"{path}:{lineno}: expected prefix {expected}")
    return errors


def quick_howto_content_errors(path: Path, prompt_readme_name: str) -> list[str]:
    errors: list[str] = []
    text = path.read_text(encoding="utf-8")
    text_fences = re.findall(r"```text\s*\n(.*?)```", text, flags=re.S)
    for prompt, expected_runtime in RUNTIME_BY_PROMPT.items():
        matches = [fence for fence in text_fences if prompt in fence]
        if len(matches) != 1:
            errors.append(f"{path}: expected exactly one runnable example for {prompt}, found {len(matches)}")
            continue
        fence = matches[0]
        actual_runtime = set(re.findall(r"(?m)^-\s+([A-Z][A-Z0-9_]*)=<\1>\s*$", fence))
        if actual_runtime != expected_runtime:
            errors.append(
                f"{path}: runtime variables for {prompt}: expected {sorted(expected_runtime)}, got {sorted(actual_runtime)}"
            )
        if "agentic_enhancement_workflow_template/40_operator_workflows/agent_entry_prompts" in fence:
            errors.append(f"{path}: template-side prompt used in runnable example for {prompt}")
        if "{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/" not in fence:
            errors.append(f"{path}: runnable example is not instance-specific for {prompt}")
    for support in [prompt_readme_name, "00_variable_conventions.md"]:
        if support not in text:
            errors.append(f"{path}: supporting prompt document not listed: {support}")
    if "- `README.md`" in text:
        errors.append(f"{path}: stale unqualified nested prompt README listed")
    return errors


def quick_howto_hierarchy_errors(path: Path) -> list[str]:
    errors: list[str] = []
    headings: list[tuple[int, int, str]] = []
    in_fence = False
    fence = None
    for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        stripped = line.lstrip()
        if stripped.startswith("```") or stripped.startswith("~~~"):
            token = stripped[:3]
            if not in_fence:
                in_fence, fence = True, token
            elif token == fence:
                in_fence, fence = False, None
            continue
        if in_fence:
            continue
        m = re.match(r"^(#{1,6})\s+(.+)$", line)
        if m:
            label = re.sub(r"^\d+(?:\.\d+)*\.\s+", "", m.group(2)).strip()
            headings.append((lineno, len(m.group(1)), label))

    quick_indexes = [i for i, (_, _, label) in enumerate(headings) if label == "Operator Quick HowToUse"]
    if not quick_indexes:
        return [f"{path}: Operator Quick HowToUse heading not found"]
    expected_children = {
        "Prerequisite",
        "SINGLE EXECUTION",
        "WORK PACKAGE EXECUTION — STEP by STEP",
        "CANDIDATE ASSEMBLY",
        "INDEPENDENT VERIFICATION",
        "FORMAL FAIL REMEDIATION",
        "GATE WIDE AUTONOMOUS EXECUTION",
        "SUPPORTING DOCUMENTS — NOT DIRECT EXECUTION ENTRY POINTS",
    }
    for idx in quick_indexes:
        lineno, level, _ = headings[idx]
        if level != 2:
            errors.append(f"{path}:{lineno}: Operator Quick HowToUse must be H2")
            continue
        seen: set[str] = set()
        for child_lineno, child_level, child_label in headings[idx + 1:]:
            if child_level <= 2:
                break
            if child_label in expected_children:
                seen.add(child_label)
                if child_level != 3:
                    errors.append(f"{path}:{child_lineno}: Quick HowToUse child must be H3: {child_label}")
        for label in sorted(expected_children - seen):
            errors.append(f"{path}:{lineno}: Quick HowToUse child missing: {label}")
    return errors


def stale_readme_reference_errors(root: Path) -> list[str]:
    errors: list[str] = []
    canonical_nested = [p for p in root.rglob("README_*.md") if p.parent != root]
    old_rel_paths = {
        (p.parent / "README.md").relative_to(root).as_posix(): p.relative_to(root).as_posix()
        for p in canonical_nested
    }
    md_link_pattern = re.compile(r"!?\[[^\]]*\]\((?P<target><[^>]+>|[^)\s]+)")

    for path in sorted(root.rglob("*")):
        if not path.is_file() or any(part in SKIP_PARTS for part in path.parts):
            continue
        if path.suffix.lower() not in TEXT_EXTENSIONS:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        for stale, canonical in old_rel_paths.items():
            if stale in text:
                errors.append(f"{path.relative_to(root)}: stale nested README path {stale}; expected {canonical}")
        if path.suffix.lower() == ".md":
            for m in md_link_pattern.finditer(text):
                raw = m.group("target")
                target = raw[1:-1] if raw.startswith("<") and raw.endswith(">") else raw
                if re.match(r"^[A-Za-z][A-Za-z0-9+.-]*:", target) or target.startswith("#"):
                    continue
                path_part = target.partition("#")[0]
                if "README" not in path_part or not path_part:
                    continue
                resolved = (path.parent / path_part).resolve()
                try:
                    resolved.relative_to(root)
                except ValueError:
                    continue
                if not resolved.exists():
                    errors.append(f"{path.relative_to(root)}: broken README Markdown link: {target}")
    return errors


def _manifest_strings(obj: Any):
    if isinstance(obj, str):
        yield obj
    elif isinstance(obj, list):
        for item in obj:
            yield from _manifest_strings(item)
    elif isinstance(obj, dict):
        for value in obj.values():
            yield from _manifest_strings(value)


def manifest_errors(root: Path) -> list[str]:
    manifest = root / "MANIFEST.json"
    if not manifest.is_file():
        return []
    try:
        data = json.loads(manifest.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return [f"MANIFEST.json invalid JSON: {exc}"]
    errors = []
    for value in _manifest_strings(data):
        normalized = value.replace("\\", "/")
        if re.search(r"(?:^|/)README\.md(?:$|[#?])", normalized) and normalized != "README.md":
            errors.append(f"MANIFEST.json stale nested README reference: {value}")
    return errors


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("template_root", type=Path)
    args = p.parse_args()
    root = args.template_root.resolve()
    failures: list[str] = []

    failures.extend(validate_readme_names(root))
    prompt_dir = root / "40_operator_workflows" / "agent_entry_prompts"
    prompt_readme_name = readme_filename_for_directory(root, prompt_dir)
    for name in [prompt_readme_name, "00_variable_conventions.md", *PROMPTS]:
        if not (prompt_dir / name).is_file():
            failures.append(f"missing prompt artifact: {name}")
    if (prompt_dir / "README.md").exists():
        failures.append("nested unqualified agent_entry_prompts/README.md remains")

    operator_dir = root / "40_operator_workflows"
    operator_readme = operator_dir / readme_filename_for_directory(root, operator_dir)
    for readme in [root / "README.md", operator_readme]:
        if not readme.is_file():
            failures.append(f"missing README: {readme}")
            continue
        text = readme.read_text(encoding="utf-8")
        if "Operator Quick HowToUse" not in text:
            failures.append(f"Quick HowToUse missing: {readme}")
        if "README filename = deterministic function(directory path)" not in text:
            failures.append(f"README deterministic naming rule missing: {readme}")
        for name in PROMPTS:
            if name not in text:
                failures.append(f"Quick HowToUse does not cover {name}: {readme}")
        for line in text.splitlines():
            if line.strip().startswith("- ") and "agent_entry_prompts" in line and "agentic_enhancement_workflow_template" in line:
                failures.append(f"template-direct runnable example remains: {readme}: {line.strip()}")
        if "{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/" not in text:
            failures.append(f"instance-specific prompt path missing: {readme}")
        failures.extend(quick_howto_content_errors(readme, prompt_readme_name))
        failures.extend(quick_howto_hierarchy_errors(readme))

    convention_doc = root / "README_NAMING_CONVENTION.md"
    if not convention_doc.is_file():
        failures.append("README_NAMING_CONVENTION.md missing")
    else:
        convention_text = convention_doc.read_text(encoding="utf-8")
        for token in ["README filename = deterministic function(directory path)", "README_<PATH_ID>.md", "readme_naming.py"]:
            if token not in convention_text:
                failures.append(f"README_NAMING_CONVENTION.md missing token: {token}")

    structure = root / "TEMPLATE_STRUCTURE.md"
    if not structure.is_file():
        failures.append("TEMPLATE_STRUCTURE.md missing")
    else:
        st = structure.read_text(encoding="utf-8")
        for token in [prompt_readme_name, "README_<PATH_ID>.md", "readme_naming.py"]:
            if token not in st:
                failures.append(f"TEMPLATE_STRUCTURE.md missing README schema token: {token}")

    wp = prompt_dir / "10_normal_execution_02_work_package_coding_agent_prompt.md"
    if wp.is_file():
        text = wp.read_text(encoding="utf-8")
        for token in FIXED:
            if "{{" + token + "}}" not in text:
                failures.append(f"template Work Package prompt missing fixed placeholder {token}")
        if "assigned Pxxのみ" not in text:
            failures.append("Work Package prompt lacks assigned-Pxx-only authority")
        for forbidden in ["Gate-level 06", "Gate-level 07", "P00", "other Pxx"]:
            if forbidden not in text:
                failures.append(f"Work Package forbidden-read guardrail missing token: {forbidden}")
        if "BLOCKED_CONTRACT_AMBIGUITY" not in text:
            failures.append("Work Package ambiguity stop rule missing")
        for token in ["source / tests / configuration / migration", "status report:", "BLOCKED_REPOSITORY_STATE", "BLOCKED_EXECUTION_MODE_MISMATCH"]:
            if token not in text:
                failures.append(f"Work Package resolver/guardrail element missing: {token}")

    readiness = root / "40_operator_workflows" / "preflight" / "AGENT_EXECUTION_READINESS.md"
    if not readiness.is_file():
        failures.append("Agent Execution Readiness policy missing")
    else:
        rt = readiness.read_text(encoding="utf-8")
        for axis in ["Artifact completeness", "Content completeness", "Execution resolvability", "Information isolation"]:
            if axis not in rt:
                failures.append(f"readiness axis missing: {axis}")

    naming_tool = root / "40_operator_workflows" / "tools" / "readme_naming.py"
    instantiate_tool = root / "40_operator_workflows" / "tools" / "instantiate_agent_entry_prompts.py"
    readiness_tool = root / "40_operator_workflows" / "tools" / "validate_agent_execution_readiness.py"
    if not naming_tool.is_file():
        failures.append("canonical README naming tool missing")
    for tool in [instantiate_tool, readiness_tool]:
        if not tool.is_file():
            failures.append(f"tool missing: {tool}")
        elif "readme_filename_for_directory" not in tool.read_text(encoding="utf-8"):
            failures.append(f"tool does not use canonical README naming function: {tool}")

    failures.extend(stale_readme_reference_errors(root))
    failures.extend(manifest_errors(root))

    for path in root.rglob("*.md"):
        if any(part in SKIP_PARTS for part in path.parts):
            continue
        failures.extend(heading_errors(path))

    print("WORKFLOW TEMPLATE REVISION VALIDATION")
    if failures:
        for item in failures:
            print("FAIL", item)
        print(f"OVERALL: FAIL ({len(failures)})")
        return 2
    print("PASS prompt inventory / instantiation rule")
    print("PASS Operator Quick HowToUse coverage")
    print("PASS Work Package context isolation")
    print("PASS Agent Execution Readiness policy")
    print("PASS hierarchical heading numbering")
    print("PASS deterministic nested README naming")
    print("PASS README reference migration / tooling integration")
    print("OVERALL: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
