# Existing Variables

## 1. Existing
KEEP_VARIABLE_DOC

<!-- BEGIN MANAGED: AGENT_ENTRY_PROMPT_CONTROL -->
## 2. Agent Entry Prompt Variable Conventions

### 2.1. Purpose

`agent_entry_prompts/` は、template側のgeneric promptをEnhancement開始時に `{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/` へinstance化して使用する。

template directory上のpromptをAgent executionへ直接指定してはならない。

### 2.2. Enhancement-fixed variables

以下はEnhancement-specific prompt instance生成時に必ず具体値へ展開する。

```text
PROJECT_NAME
ENHANCE_ID
ENHANCE_SHORT_ID
BRANCH_NAME
REMOTE_NAME
WORK_ROOT
WORK_DIR_NAME
```

Enhancement-side `agent_entry_prompts/` に上記の未解決placeholderが1件でも残る場合、Agent execution readinessは `BLOCKED_ENHANCEMENT_IDENTITY_UNRESOLVED` とする。

### 2.3. Runtime variables

以下はexecution単位でHuman operatorまたはOrchestratorが指定する。

```text
GATE_ID
PACKAGE_ID
TRIAL_NO
REMEDIATION_PACKAGE_ID
AMENDMENT_ID
```

各promptは必要なRuntime variableだけを要求する。不要なRuntime variableを推測で補完してはならない。

### 2.4. Resolution rule

Enhancement identityはEnhancement-fixed variablesから、execution identityはRuntime variablesから解決する。

```text
Execution identity = Enhancement identity + Runtime identity
```

Human entryだけで対象を一意に解決できない場合は実行を開始せず `BLOCKED_EXECUTION_UNRESOLVABLE` とする。

### 2.5. Template and instance distinction

- template側: `agentic_enhancement_workflow_template/40_operator_workflows/agent_entry_prompts/`
  - authoring source
  - Enhancement-fixed placeholdersを保持してよい
  - Agent executionへ直接使用しない
- Enhancement側: `{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/`
  - execution source
  - Enhancement-fixed placeholdersは0件でなければならない
  - Human Quick HowToUseが参照するcanonical path

### 2.6. Markdown heading numbering

Markdown artifactの見出しは原則として以下に従う。

```text
#       document title: no numeric prefix
##      1. / 2. / 3.
###     1.1. / 1.2.
####    1.1.1.
#####   1.1.1.1.
######  1.1.1.1.1.
```

コードフェンス内の `#` は対象外とする。
<!-- END MANAGED: AGENT_ENTRY_PROMPT_CONTROL -->
