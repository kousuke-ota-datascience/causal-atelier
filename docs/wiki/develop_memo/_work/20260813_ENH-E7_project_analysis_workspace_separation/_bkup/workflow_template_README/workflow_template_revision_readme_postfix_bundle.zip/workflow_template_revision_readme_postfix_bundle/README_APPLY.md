# Workflow Template Revision Bundle — Apply Guide

## 1. Purpose

This bundle applies both:

1. Agent execution-control / context-isolation / readiness changes.
2. Deterministic nested README postfix schema migration.

No git commit or push is performed.

## 2. Apply to the actual workflow template

From any shell with access to the repository:

```bash
python3 /path/to/apply_workflow_template_revision.py \
  docs/wiki/develop_memo/_work/agentic_enhancement_workflow_template
```

The apply script performs the README rename, reference migration, MANIFEST migration when present, tooling update, README/structure documentation update, and heading normalization as one transaction-like operation. On failure it restores the original file snapshot.

## 3. Validate

```bash
python3 /path/to/validate_workflow_template_revision.py \
  docs/wiki/develop_memo/_work/agentic_enhancement_workflow_template
```

Expected final line:

```text
OVERALL: PASS
```

Then run repository-native checks:

```bash
git diff --check
git diff -- docs/wiki/develop_memo/_work/agentic_enhancement_workflow_template
```

## 4. Canonical README naming

```text
root README             -> README.md
nested local README     -> README_<PATH_ID>.md
```

Examples:

```text
00_enhance_background/README_00.md
20_implementation_reports/G01/Trial01/README_20_G01_Trial01.md
40_operator_workflows/README_40.md
40_operator_workflows/agent_entry_prompts/README_40_agent_entry_prompts.md
```

Canonical implementation after apply:

```text
40_operator_workflows/tools/readme_naming.py
```

## 5. Instantiate prompts for an Enhancement

```bash
python3 docs/wiki/develop_memo/_work/agentic_enhancement_workflow_template/40_operator_workflows/tools/instantiate_agent_entry_prompts.py \
  --template-root docs/wiki/develop_memo/_work/agentic_enhancement_workflow_template \
  --work-root docs/wiki/develop_memo/_work/<WORK_DIR_NAME> \
  --project-name <PROJECT_NAME> \
  --enhance-id <ENHANCE_ID> \
  --enhance-short-id <ENHANCE_SHORT_ID> \
  --branch-name <BRANCH_NAME> \
  --remote-name <REMOTE_NAME> \
  --work-dir-name <WORK_DIR_NAME>
```

The Enhancement-side prompt index is generated as:

```text
{{WORK_ROOT}}/40_operator_workflows/agent_entry_prompts/README_40_agent_entry_prompts.md
```

A nested unqualified `README.md` is treated as invalid.

## 6. Validate Agent execution

Example Work Package execution:

```bash
python3 docs/wiki/develop_memo/_work/agentic_enhancement_workflow_template/40_operator_workflows/tools/validate_agent_execution_readiness.py \
  --work-root <WORK_ROOT> \
  --mode package \
  --gate-id G01 \
  --package-id P01 \
  --trial-no 01
```

Only:

```text
OVERALL: READY_FOR_AGENT_EXECUTION
```

permits Agent startup.

## 7. MANIFEST behavior

If `MANIFEST.json` exists, the migration updates:

- root-relative nested README path strings, and
- objects that represent a nested README as `directory`/`dir`/`parent` + `filename`/`file`/`name`.

The root-level literal `README.md` remains unchanged.

If the actual MANIFEST uses a different, non-path schema, repository-specific validation is still required after apply.
