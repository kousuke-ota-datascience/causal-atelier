# Markdown Heading Convention

## 1. Rule

Markdown artifactを新規作成またはtemplateとして更新するとき、H2以下の見出しにhierarchical numeric prefixを付与する。

```text
# Title
## 1. Section
### 1.1. Subsection
#### 1.1.1. Sub-subsection
```

## 2. Scope

- `#` document titleは原則番号なし
- `##`〜`######` は親番号を継承
- fenced code block内部は採番対象外
- 既存numeric prefixを再採番するときは二重付与しない
