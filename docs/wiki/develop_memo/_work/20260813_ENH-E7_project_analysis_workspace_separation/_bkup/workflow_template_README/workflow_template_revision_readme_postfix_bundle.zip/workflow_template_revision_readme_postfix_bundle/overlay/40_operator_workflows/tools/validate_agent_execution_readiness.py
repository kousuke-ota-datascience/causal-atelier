#!/usr/bin/env python3
"""Mechanical readiness validation for Enhancement-specific Agent execution."""
from __future__ import annotations

import argparse
from pathlib import Path
import re

from readme_naming import readme_filename_for_directory

FIXED = [
    "PROJECT_NAME", "ENHANCE_ID", "ENHANCE_SHORT_ID", "BRANCH_NAME",
    "REMOTE_NAME", "WORK_ROOT", "WORK_DIR_NAME",
]
PROMPT_BY_MODE = {
    "single": "10_normal_execution_01_single_execution_coding_agent_prompt.md",
    "package": "10_normal_execution_02_work_package_coding_agent_prompt.md",
    "assembly": "20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md",
    "test": "30_independent_verification_01_test_agent_prompt.md",
    "remediation": "40_fail_remediation_01_fail_rework_coding_agent_prompt.md",
    "orchestrator": "50_orchestration_01_gate_orchestrator_prompt.md",
}
RUNTIME_BY_MODE = {
    "single": ["GATE_ID", "TRIAL_NO"],
    "package": ["GATE_ID", "PACKAGE_ID", "TRIAL_NO"],
    "assembly": ["GATE_ID", "TRIAL_NO"],
    "test": ["GATE_ID", "TRIAL_NO"],
    "remediation": ["GATE_ID", "REMEDIATION_PACKAGE_ID", "TRIAL_NO"],
    "orchestrator": ["GATE_ID", "TRIAL_NO"],
}


def fail(code: str, message: str, failures: list[tuple[str, str]]) -> None:
    failures.append((code, message))


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--work-root", required=True, type=Path)
    p.add_argument("--mode", required=True, choices=sorted(RUNTIME_BY_MODE))
    p.add_argument("--gate-id")
    p.add_argument("--package-id")
    p.add_argument("--trial-no")
    p.add_argument("--remediation-package-id")
    args = p.parse_args()

    failures: list[tuple[str, str]] = []
    work_root = args.work_root.resolve()
    prompts = work_root / "40_operator_workflows" / "agent_entry_prompts"
    prompt_readme_name = readme_filename_for_directory(work_root, prompts)

    if not prompts.is_dir():
        fail("ARTIFACT_COMPLETENESS", f"missing {prompts}", failures)
    else:
        required = {
            "00_variable_conventions.md",
            "10_normal_execution_01_single_execution_coding_agent_prompt.md",
            "10_normal_execution_02_work_package_coding_agent_prompt.md",
            "20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md",
            "30_independent_verification_01_test_agent_prompt.md",
            "40_fail_remediation_01_fail_rework_coding_agent_prompt.md",
            "50_orchestration_01_gate_orchestrator_prompt.md",
            prompt_readme_name,
        }
        missing = sorted(name for name in required if not (prompts / name).is_file())
        if missing:
            fail("ARTIFACT_COMPLETENESS", "missing prompt files: " + ", ".join(missing), failures)
        if (prompts / "README.md").exists():
            fail("ARTIFACT_COMPLETENESS", "nested unqualified README.md is forbidden", failures)

        fixed_re = re.compile(r"\{\{(" + "|".join(map(re.escape, FIXED)) + r")\}\}")
        unresolved = []
        for path in prompts.glob("*.md"):
            if fixed_re.search(path.read_text(encoding="utf-8")):
                unresolved.append(path.name)
        if unresolved:
            fail("CONTENT_COMPLETENESS", "unresolved Enhancement-fixed placeholders: " + ", ".join(unresolved), failures)

    if prompts.is_dir():
        selected_prompt = prompts / PROMPT_BY_MODE[args.mode]
        if selected_prompt.is_file():
            selected_text = selected_prompt.read_text(encoding="utf-8")
            assignments: dict[str, str] = {}
            for key in FIXED:
                m = re.search(rf"(?m)^\s*{re.escape(key)}\s*=\s*(.+?)\s*$", selected_text)
                if not m or not m.group(1).strip():
                    fail("CONTENT_COMPLETENESS", f"selected prompt lacks explicit {key}", failures)
                else:
                    assignments[key] = m.group(1).strip()
            prompt_work_root = assignments.get("WORK_ROOT")
            if prompt_work_root and "{{" not in prompt_work_root:
                supplied_text = work_root.as_posix().rstrip("/")
                prompt_text = prompt_work_root.replace("\\", "/").rstrip("/")
                if not (supplied_text == prompt_text or supplied_text.endswith("/" + prompt_text)):
                    fail(
                        "EXECUTION_RESOLVABILITY",
                        f"prompt WORK_ROOT does not identify supplied work root: {prompt_work_root}",
                        failures,
                    )

    supplied = {
        "GATE_ID": args.gate_id,
        "PACKAGE_ID": args.package_id,
        "TRIAL_NO": args.trial_no,
        "REMEDIATION_PACKAGE_ID": args.remediation_package_id,
    }
    missing_runtime = [k for k in RUNTIME_BY_MODE[args.mode] if not supplied.get(k)]
    if missing_runtime:
        fail("EXECUTION_RESOLVABILITY", "missing runtime values: " + ", ".join(missing_runtime), failures)

    if not work_root.is_dir():
        fail("EXECUTION_RESOLVABILITY", f"WORK_ROOT does not exist: {work_root}", failures)

    if args.mode == "package" and args.gate_id and args.package_id:
        gate_dir = work_root / "10_enhance_instruction" / args.gate_id
        matches = sorted(gate_dir.glob(f"06_{args.gate_id}_{args.package_id}_*.md")) if gate_dir.is_dir() else []
        if len(matches) != 1:
            fail("EXECUTION_RESOLVABILITY", f"assigned Pxx resolver count={len(matches)}", failures)
        package_prompt = prompts / "10_normal_execution_02_work_package_coding_agent_prompt.md"
        if package_prompt.is_file():
            text = package_prompt.read_text(encoding="utf-8")
            if "assigned Pxxのみ" not in text and "assigned Pxx only" not in text:
                fail("INFORMATION_ISOLATION", "package prompt does not state assigned-Pxx-only authority", failures)
            if "仕様補完目的で以下を読んではならない" not in text:
                fail("INFORMATION_ISOLATION", "package prompt lacks explicit forbidden-read guardrail", failures)
        if len(matches) == 1:
            pxx = matches[0].read_text(encoding="utf-8")
            suspicious = []
            for token in ["Gate 07を参照", "07を参照", "P00を参照", "Gate 06を参照"]:
                if token in pxx:
                    suspicious.append(token)
            if suspicious:
                fail(
                    "INFORMATION_ISOLATION",
                    "assigned Pxx appears to require forbidden specification source: " + ", ".join(suspicious),
                    failures,
                )

    print("AGENT EXECUTION READINESS")
    for axis in ["ARTIFACT_COMPLETENESS", "CONTENT_COMPLETENESS", "EXECUTION_RESOLVABILITY", "INFORMATION_ISOLATION"]:
        axis_failures = [m for c, m in failures if c == axis]
        print(f"{axis}: {'FAIL' if axis_failures else 'PASS'}")
        for msg in axis_failures:
            print(f"  - {msg}")

    if failures:
        print("OVERALL: BLOCKED")
        return 2
    print("OVERALL: READY_FOR_AGENT_EXECUTION")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
