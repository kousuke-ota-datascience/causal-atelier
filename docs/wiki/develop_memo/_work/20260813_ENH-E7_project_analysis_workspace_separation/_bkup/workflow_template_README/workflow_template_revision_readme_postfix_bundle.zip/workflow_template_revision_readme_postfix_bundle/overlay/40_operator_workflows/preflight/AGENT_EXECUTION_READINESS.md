# Agent Execution Readiness

## 1. Purpose

Document/template complianceとは独立して、Agent executionを開始可能か判定する。

## 2. Validation axes

| Axis | PASS condition |
|---|---|
| Artifact completeness | required instantiated artifactsが存在する |
| Content completeness | required sections/fieldsが存在する |
| Execution resolvability | Human entryからexecution identityが一意に解決できる |
| Information isolation | Agentが許可されたnormative sourceだけで実行できる |

## 3. Mechanical checks

1. Enhancement-side `40_operator_workflows/agent_entry_prompts/` が存在する。
2. Enhancement-fixed placeholdersが0件である。
3. `WORK_ROOT` が存在し、exactly one Enhancement rootを指す。
4. Work Packageの場合、assigned Pxx globがexactly one fileを解決する。
5. Work Package Coding Agent promptがGate 06 / 07 / P00 / other Pxxをdirect-readする指示を持たない。
6. assigned Pxxが06 / 07 / P00を仕様補完sourceとして要求しない。
7. required Runtime identifiersが全て存在する。
8. branch / remote identityが具体値である。

## 4. Decision

全checkがPASSした場合のみ `READY_FOR_AGENT_EXECUTION` とする。

1件でもFAILならAgentを起動せず、該当する `BLOCKED_*` とfailed checkを報告する。

## 5. Separation from template compliance

`unresolved {{...}} == 0` だけではexecution readinessを証明しない。

required artifactの欠落、resolverの0/複数match、information isolation違反を別途検査する。
