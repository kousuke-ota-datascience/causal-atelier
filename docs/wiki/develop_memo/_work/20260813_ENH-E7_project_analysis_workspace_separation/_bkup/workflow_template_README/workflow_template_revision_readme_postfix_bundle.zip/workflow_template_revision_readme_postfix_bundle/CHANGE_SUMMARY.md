# Workflow Template Revision — README Postfix Schema

## 1. Summary

本revisionは、既存のAgent execution-control修正に加えて、nested local READMEをpath-derived postfix filenameへ移行する横断的schema変更を実装する。

canonical rule:

```text
root README                   = README.md
nested README filename       = README_<PATH_ID>.md
README filename              = deterministic function(directory path)
```

examples:

```text
00_enhance_background/
  README_00.md

20_implementation_reports/G01/Trial01/
  README_20_G01_Trial01.md

40_operator_workflows/agent_entry_prompts/
  README_40_agent_entry_prompts.md
```

## 2. Implemented cross-cutting changes

1. template root以外の全 `README.md` をpath-derived canonical filenameへrenameするmigrationを追加。
2. Markdown relative linksをrename mapに従って更新。
3. root-relative / file-relative plain path referenceを更新。
4. same-directory code/link-like `README.md` referencesをcanonical nested READMEへ更新。
5. `TEMPLATE_STRUCTURE.md` にREADME naming schemaとcanonical naming implementationを明記。
6. `MANIFEST.json` が存在する場合、full path stringおよび `directory + filename` 形式をmigration対象化。
7. Agent entry prompt inventoryのsupport READMEを `README_40_agent_entry_prompts.md` へ変更。
8. Enhancement instantiationがcanonical naming functionを使用し、nested `README.md` を生成しないことを強制。
9. Agent Execution Readiness validatorがcanonical prompt READMEを要求し、無印nested READMEをBLOCKするよう変更。
10. template validatorへnested README naming、stale reference、README Markdown link、MANIFEST整合検査を追加。
11. `README_NAMING_CONVENTION.md` をtemplate rootへ配置し、root README / operator README / `TEMPLATE_STRUCTURE.md` に同規約をmanaged sectionとして反映。
12. rename collision時は上書きせず `BLOCKED_README_NAMING_COLLISION` で停止する。
13. apply処理は失敗時に変更前snapshotへrestoreする。

## 3. Canonical naming function

canonical implementation:

```text
40_operator_workflows/tools/readme_naming.py
```

numbered workflow directoryは先頭2桁namespaceへ縮約する。

```text
00_enhance_background      -> 00
20_implementation_reports -> 20
40_operator_workflows      -> 40
```

非numbered semantic directoryおよびruntime identityは保持する。

```text
agent_entry_prompts -> agent_entry_prompts
G01                 -> G01
Trial01             -> Trial01
```

## 4. Execution-control changes retained

- Enhancement-specific `agent_entry_prompts/` instantiation MUST
- Enhancement-fixed / Runtime variable separation
- template-side prompt direct execution prohibition
- Work Package Coding Agent assigned-Pxx-only normative context
- Agent Execution Readiness 4-axis validation
- Operator Quick HowToUse copy/paste examples
- hierarchical Markdown heading numbering

## 5. Validation

`self_test_workflow_template_revision.py` verifies:

- root README remains `README.md`
- nested `README.md` count becomes zero
- deterministic names for 00 / 20-Gate-Trial / 40-agent-entry examples
- Markdown link migration
- plain path migration
- MANIFEST full-path migration
- MANIFEST directory+filename migration
- instantiation output naming
- readiness acceptance of canonical support README
- rename collision block
- fail-before-write behavior
- previous execution-control negative guards
- idempotent second apply
