# Source Scope

## 1. Materialized template files

`revised_template_files/` is a physically materialized revised template based on the template fixture available in this ChatGPT runtime from the preceding workflow-template revision work.

It is validated and internally consistent, but it is **not claimed to be a byte-for-byte complete copy of the current repository's full `agentic_enhancement_workflow_template/` tree**, because that repository checkout is not mounted in this runtime.

## 2. Full repository application

`apply_workflow_template_revision.py` is designed to apply the same schema change to the actual full template tree. In particular, it discovers every nested `README.md` dynamically rather than relying on the fixture inventory.

Therefore, for repository integration the authoritative procedure is:

1. run the apply script against the actual `agentic_enhancement_workflow_template/` directory;
2. run `validate_workflow_template_revision.py`;
3. review `git diff --check` and the full git diff.

No missing repository file has been fabricated in `revised_template_files/`.
