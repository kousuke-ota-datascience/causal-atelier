# Implementation Reports

## 1. Purpose

`20_implementation_reports/` はCoding / Candidate Assemblyが生成するimplementation evidenceを保持する。

workflow cursorを手動管理する領域ではなく、後続dependency / candidate readinessをcanonical evidenceから導出するための領域である。

## 2. Work Package evidence

Work Package modeのcanonical package reportは次のdirectoryに置く。

```text
20_implementation_reports/<GATE_ID>/Trial<TRIAL_NO>/packages/
```

現行operator contractのcanonical filename:

```text
<ENHANCE_SHORT_ID>-<GATE_ID>_<TRIAL_NO>_<PACKAGE_ID>__status.md
```

最低限のidentity / state metadata:

```text
Gate: <GATE_ID>
Package: <PACKAGE_ID>
Trial: <TRIAL_NO>
State: PACKAGE_COMPLETE
```

`PACKAGE_READY` はCoding Agentのterminal response labelであり、canonical report stateではない。

## 3. Gate-level candidate evidence

Work Package modeでは全required Pxx完了後、Candidate AssemblyがGate-level implementation completion evidenceを作る。

Single Execution modeではGate-wide implementation完了後に同等のcandidate identity evidenceを作る。

Candidate readiness authorityはimplementation completion reportであり、期待stateは次である。

```text
Candidate state: READY_FOR_TEST
```

## 4. Dependency semantics

Pxx dependencyはupstream packageのcanonical package reportから導出する。

Pxx documentのstatus literalや別のcontrol sheetから推測しない。

## 5. README naming

Gate / Trial等のnested local READMEを作る場合、`40_operator_workflows/tools/readme_naming.py` のpath-derived namingを使用する。
