# Reconstruction Notes

## 1. Baseline status

このtreeは、`agentic_enhancement_workflow_template_v0.02` をcontrol-plane baselineとして、handoff、README postfix revision bundle、ENH-E7で使用されたactual preflight scriptを参照して再構成した統合baselineである。

actual repository checkoutのbyte-for-byte full copyではない。

## 2. Source-preserved files

v0.02 baselineから既存本文を保持している主な領域:

- root README / HowToUse / naming convention
- `40_operator_workflows/agent_entry_prompts/*`
- prompt instantiation / README naming tooling

必要なcontrol-plane修正だけを追加している。

## 3. Reconstructed from current contracts

現行HowToUse / handoffで役割とpathを確認できるため、新しいcanonical scaffold / indexとして追加したもの:

- `00_enhance_background/README_00.md`
- `00_enhance_background/04_design_revision.md`
- `00_enhance_background/05_requirements_design_consistency_and_traceability_review.md`
- `10_enhance_instruction/README_10.md`
- `20_implementation_reports/README_20.md`
- `30_test_report/README_30.md`
- `40_operator_workflows/architecture_review/*`

これらは「失われた旧本文の復元」ではなく、現在確定しているworkflow contractから再構成したgeneric scaffoldである。

## 4. Preflight robustness integration

ENH-E7 actual preflightで確認された問題をtemplate control planeへ一般化して反映した。

- decorator-specific `bold_field()` を共通parserへ置換する設計
- `**Field:** value` / `Field: value` / `- Field: value` のformat tolerance
- conflicting duplicate / missing / empty / unparseable dependencyはsemantic failure
- `G\d{2}` / `P\d{2}` はprotocol grammarのみ固定
- Gate / Package existenceはrepository artifactsから導出
- Pxx dependencyはpackage report、Gate dependencyはcanonical 999から導出
- `Status at issuance` はINFO diagnosticのみ

## 5. Known unresolved semantic bodies

以下5本には取得元baseline由来の `KEEP_THIS_SEMANTIC_SENTENCE` が残る。

- `10_normal_execution_01_single_execution_coding_agent_prompt.md`
- `20_candidate_assembly_01_work_package_candidate_assembly_agent_prompt.md`
- `30_independent_verification_01_test_agent_prompt.md`
- `40_fail_remediation_01_fail_rework_coding_agent_prompt.md`
- `50_orchestration_01_gate_orchestrator_prompt.md`

actual repositoryのsemantic bodyを取得するまでproduction-readyとは判定しない。

## 6. Deliberately not fabricated

- unknown historical `00_enhance_background/01..03` body
- actual repository `MANIFEST.json`
- actual repository固有のreport / planning template inventory

`MANIFEST.json` は未知schemaを推測して作らず、代わりにprovenance用 `RECONSTRUCTION_MANIFEST.json` を置く。
