# Enhancement Instruction

## 1. Purpose

`10_enhance_instruction/` はGate単位のstatic execution contractを保持する。

各Gateは`Gxx` directoryを持ち、Gate local READMEからimplementation contract、verification contract、execution mode、static dependencyを一意に解決できなければならない。

## 2. Per-Gate structure

Enhancement instanceでは原則として次の形を取る。

```text
10_enhance_instruction/
└─ Gxx/
   ├─ README_10_Gxx.md
   ├─ 06_*_Gxx_implementation_instruction.md
   ├─ 07_*_Gxx_test_instruction.md
   └─ 06_Gxx_Pxx_*.md            # WORK_PACKAGE modeの場合
```

具体的なprefix / semantic filenameはEnhancement instanceのcontractをauthorityとする。

## 3. Gate local README responsibility

Gate local READMEは以下に限定する。

- static routing
- static dependency declaration
- execution mode declaration
- canonical artifact index

Gate local READMEをmutable state sheetとして使用してはならない。

## 4. Execution modes

Gate contract / Gate local READMEのstatic routingから、次のいずれかを一意に解決する。

```text
WORK_PACKAGE
SINGLE_EXECUTION
```

prompt fileの存在だけをexecution mode enablementの根拠にしない。

## 5. Work Package contract

Work Package Coding Agentのnormative authorityはassigned Pxxのみとする。

Pxxは最低限、次をself-containedに記述する。

- Gate / Package identity
- Depends on
- Self-containment
- Information isolation
- required implementation scope
- prohibited / protected scope
- focused verification
- package reporting contract
- completion criteria
- stop rule

`Status at issuance` はdiagnostic metadataでありworkflow cursorとして使用しない。

## 6. Gate readiness

Gate readinessは次から導出する。

```text
static routing / dependency declaration
    + upstream canonical evidence
    + Gate 06 = FROZEN
    + Gate 07 = FROZEN
    + blocking preflightなし
```

別のmutable state fileへ再集約しない。
