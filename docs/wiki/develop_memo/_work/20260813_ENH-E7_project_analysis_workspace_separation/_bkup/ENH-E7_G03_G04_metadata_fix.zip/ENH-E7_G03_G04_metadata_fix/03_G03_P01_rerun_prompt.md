# G03/P01 再実行プロンプト

metadata修正とverification PASS後、同じTrialで以下をCoding Agentへ渡す。

```text
下記ファイルを実行せよ

- docs/wiki/develop_memo/_work/20260813_ENH-E7_project_analysis_workspace_separation/40_operator_workflows/agent_entry_prompts/
    - 10_normal_execution_02_work_package_coding_agent_prompt.md

Runtime identityは以下の通り

- GATE_ID=G03
- PACKAGE_ID=P01
- TRIAL_NO=01

プロンプトの際の基本言語は日本語とする
```
