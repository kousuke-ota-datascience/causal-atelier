# ENH-E7 G03/G04 Metadata Fix

## 目的

G03/G04 instructionのworkflow metadataを、既存G01/G02および
`check_agent_execution_readiness.py` が認識する形式へ統一する。

今回の修正は **format compatibility correctionのみ** であり、
Gate semantics / Pxx scope / Acceptance Criteria / verification predicateは変更しない。

## Root cause

G03/G04 v1では以下のplain形式になっている。

```text
Depends on: G02 PASS
Contract status: FROZEN
Verification contract status: FROZEN
```

既存preflightは既存G01/G02 conventionである次の形式を読む。

```text
**Depends on:** G02 PASS
**Contract status:** FROZEN
**Verification contract status:** FROZEN
```

そのため、dependency自体は記載済みでもPRE-15で
`missing Depends on declaration` と判定された。

## 対象

```text
docs/wiki/develop_memo/_work/
  20260813_ENH-E7_project_analysis_workspace_separation/
    10_enhance_instruction/
      G03/
      G04/
```

対象metadata:

- 文書種別
- Self-containment
- Information isolation
- Reporting contract
- Gate
- 初回発行Trial
- Package
- Depends on
- Status at issuance
- Project
- Enhancement
- Active Gate
- Branch
- Baseline
- Contract status
- Execution Mode
- Verification contract status

## 適用手順

repository rootで実行する。

```bash
python3 /path/to/01_fix_g03_g04_metadata.py --repo-root .
```

その後、

```bash
bash /path/to/02_verify_g03_g04_metadata.sh .
```

`PASS: G03/G04 metadata is preflight-compatible` が出れば修正完了。

次に同じTrialでpreflightを再実行する。

```bash
python3 \
  docs/wiki/develop_memo/_work/20260813_ENH-E7_project_analysis_workspace_separation/40_operator_workflows/preflight/check_agent_execution_readiness.py \
  --repo-root . \
  --gate G03 \
  --package P01 \
  --trial 01
```

## Trial

今回の停止は`BLOCKED_PRECHECK`でありformal Gate FAILではない。
Trial番号は増やさず、`G03 / P01 / Trial01`を再実行する。

## 期待diff

semantic本文は変えず、metadataのみ例えば次のように変わる。

```diff
- Depends on: G02 PASS
+ **Depends on:** G02 PASS

- Contract status: FROZEN
+ **Contract status:** FROZEN

- Verification contract status: FROZEN
+ **Verification contract status:** FROZEN
```
