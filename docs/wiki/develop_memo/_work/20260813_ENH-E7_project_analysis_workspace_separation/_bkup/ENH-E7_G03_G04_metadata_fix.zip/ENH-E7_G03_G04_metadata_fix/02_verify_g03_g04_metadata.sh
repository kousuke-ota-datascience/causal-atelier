#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-.}"
ROOT="$REPO_ROOT/docs/wiki/develop_memo/_work/20260813_ENH-E7_project_analysis_workspace_separation/10_enhance_instruction"

for gate in G03 G04; do
  if [[ ! -d "$ROOT/$gate" ]]; then
    echo "FAIL: missing gate directory: $ROOT/$gate" >&2
    exit 2
  fi
done

echo "== 1. Plain workflow metadata must be absent =="

if grep -RnsE \
  '^(文書種別|Self-containment|Information isolation|Reporting contract|Gate|初回発行Trial|Package|Depends on|Status at issuance|Project|Enhancement|Active Gate|Branch|Baseline|Contract status|Execution Mode|Verification contract status):' \
  "$ROOT/G03" "$ROOT/G04"
then
  echo "FAIL: plain metadata remains" >&2
  exit 2
fi

echo "PASS"

echo
echo "== 2. Every Pxx must have bold Depends on =="

shopt -s nullglob
pxx_files=(
  "$ROOT"/G03/06_G03_P??_*.md
  "$ROOT"/G04/06_G04_P??_*.md
)

if [[ "${#pxx_files[@]}" -eq 0 ]]; then
  echo "FAIL: no Pxx files found" >&2
  exit 2
fi

for f in "${pxx_files[@]}"; do
  if ! grep -qE '^\*\*Depends on:\*\*[[:space:]]+.+' "$f"; then
    echo "FAIL: missing preflight-compatible Depends on: $f" >&2
    exit 2
  fi
done

echo "PASS: ${#pxx_files[@]} Pxx file(s)"

echo
echo "== 3. Gate 06/07 readiness metadata =="

for gate in G03 G04; do
  g06="$ROOT/$gate/06_Ariadne_ENH-E7_${gate}_implementation_instruction.md"
  g07="$ROOT/$gate/07_Ariadne_ENH-E7_${gate}_test_instruction.md"

  grep -qE '^\*\*Contract status:\*\*[[:space:]]+FROZEN[[:space:]]*$' "$g06" || {
    echo "FAIL: Contract status not readable in $g06" >&2
    exit 2
  }

  grep -qE '^\*\*Verification contract status:\*\*[[:space:]]+FROZEN[[:space:]]*$' "$g07" || {
    echo "FAIL: Verification contract status not readable in $g07" >&2
    exit 2
  }
done

echo "PASS"

echo
echo "PASS: G03/G04 metadata is preflight-compatible"
