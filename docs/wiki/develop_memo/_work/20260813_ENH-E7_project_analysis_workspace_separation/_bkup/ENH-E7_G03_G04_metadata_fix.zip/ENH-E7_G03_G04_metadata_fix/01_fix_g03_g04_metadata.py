#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

WORK_ROOT = (
    Path("docs/wiki/develop_memo/_work")
    / "20260813_ENH-E7_project_analysis_workspace_separation"
)
INSTRUCTION_ROOT = WORK_ROOT / "10_enhance_instruction"

FIELDS = (
    "文書種別",
    "Self-containment",
    "Information isolation",
    "Reporting contract",
    "Gate",
    "初回発行Trial",
    "Package",
    "Depends on",
    "Status at issuance",
    "Project",
    "Enhancement",
    "Active Gate",
    "Branch",
    "Baseline",
    "Contract status",
    "Execution Mode",
    "Verification contract status",
)

def convert_line(line: str) -> str:
    # Preserve already-correct metadata.
    if line.startswith("**"):
        return line

    for field in FIELDS:
        prefix = f"{field}:"
        if line.startswith(prefix):
            rest = line[len(prefix):].lstrip()
            # Preserve Markdown hard break if present.
            newline = "\n" if line.endswith("\n") else ""
            body = line[:-1] if newline else line
            trailing_spaces = len(body) - len(body.rstrip(" "))
            hard_break = "  " if trailing_spaces >= 2 else ""
            value = body[len(prefix):].strip()
            return f"**{field}:** {value}{hard_break}{newline}"
    return line

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root", default=".")
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()

    repo = Path(args.repo_root).resolve()
    root = repo / INSTRUCTION_ROOT

    targets = []
    for gate in ("G03", "G04"):
        gate_dir = root / gate
        if not gate_dir.is_dir():
            raise SystemExit(f"ERROR: missing gate directory: {gate_dir}")
        targets.extend(sorted(gate_dir.glob("*.md")))

    changed = []
    for path in targets:
        original = path.read_text(encoding="utf-8")
        converted = "".join(convert_line(line) for line in original.splitlines(keepends=True))

        if converted != original:
            changed.append(path)
            if not args.check:
                path.write_text(converted, encoding="utf-8")

    mode = "would change" if args.check else "changed"
    print(f"{mode}: {len(changed)} file(s)")
    for path in changed:
        print(f"- {path.relative_to(repo)}")

    if args.check and changed:
        return 1
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
