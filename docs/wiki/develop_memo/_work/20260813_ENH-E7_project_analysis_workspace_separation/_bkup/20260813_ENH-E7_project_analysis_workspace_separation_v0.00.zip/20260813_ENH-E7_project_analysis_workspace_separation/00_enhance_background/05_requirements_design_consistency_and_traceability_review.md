# ENH-E7 Requirements / Design Consistency and Traceability Review

**Document class:** Planning / Audit Artifact  
**Status:** PROPOSED; MUST BE RE-RUN BEFORE 06/07 FREEZE

## 1. Consistency conclusion

The current plan is internally consistent at planning level:

- Project resource management and Analysis execution have separate ownership.
- Analysis Context is not another navigation hierarchy.
- Existing Analysis canonical route is protected.
- Existing analysis functions are migrated to Stage Contents rather than replaced.
- Agent execution control is separated from product acceptance.

Remaining source-confirmation items are recorded in the Architecture Review decision record.

## 2. Traceability matrix

| Requirement | Design responsibility | Gate / Package | Acceptance / Test linkage |
|---|---|---|---|
| E7-REQ-001 | Project Navigation / Projects Surface | G01 P01/P02/P07 | Defined in Gate 07 before freeze |
| E7-REQ-002 | Project Navigation / Projects Surface | G01 P01/P02/P07 | Defined in Gate 07 before freeze |
| E7-REQ-003 | Project Navigation / Projects Surface | G01 P01/P02/P07 | Defined in Gate 07 before freeze |
| E7-REQ-004 | Project Management ownership | G01 P03-P06 | Defined in Gate 07 before freeze |
| E7-REQ-005 | Project Management ownership | G01 P03-P06 | Defined in Gate 07 before freeze |
| E7-REQ-006 | Project Management ownership | G01 P03-P06 | Defined in Gate 07 before freeze |
| E7-REQ-007 | Data / Analysis View ownership | G01 P05 | Defined in Gate 07 before freeze |
| E7-REQ-008 | Analysis Shell / Context | G02 P01 | Defined in Gate 07 before freeze |
| E7-REQ-009 | Analysis Shell / Context | G02 P01 | Defined in Gate 07 before freeze |
| E7-REQ-010 | Analysis Shell / Context | G02 P01 | Defined in Gate 07 before freeze |
| E7-REQ-011 | Analysis Shell / Context | G02 P01 | Defined in Gate 07 before freeze |
| E7-REQ-012 | Analysis routing / compatibility | G02 P02/P06 | Defined in Gate 07 before freeze |
| E7-REQ-013 | Analysis routing / compatibility | G02 P02/P06 | Defined in Gate 07 before freeze |
| E7-REQ-014 | Causal Stage migration | G02 P03 | Defined in Gate 07 before freeze |
| E7-REQ-015 | Exploratory Stage migration | G02 P04 | Defined in Gate 07 before freeze |
| E7-REQ-016 | Predictive Stage migration | G02 P05 | Defined in Gate 07 before freeze |
| E7-REQ-017 | Predictive Stage migration | G02 P05 | Defined in Gate 07 before freeze |
| E7-REQ-018 | Analysis routing / compatibility | G02 P02/P06 | Defined in Gate 07 before freeze |
| E7-REQ-019 | Project Navigation / Projects Surface | G01 P01/P02/P07 | Defined in Gate 07 before freeze |
| E7-REQ-020 | Results / Lineage ownership | G01 P06 | Defined in Gate 07 before freeze |
| E7-REQ-021 | Scope guard / regression | G01 P07 / G02 P06 | Defined in Gate 07 before freeze |

## 3. Workflow traceability

| Workflow Requirement | Mechanism | Verification |
|---|---|---|
| E7-WF-001/002 | Enhancement-specific `agent_entry_prompts/` | preflight PRE-01 / prompt-path audit |
| E7-WF-003/004 | fixed/runtime variable convention | preflight PRE-02/08/09/10/11/12 |
| E7-WF-005/006/007 | assigned-Pxx-only information isolation | preflight PRE-06/07 + Test Agent separation |
| E7-WF-008/009/010 | readiness 4-axis validation | preflight result + BLOCKED semantics |

## 4. Freeze rule

Before each Gate 06/07 changes to FROZEN:

1. Every MUST requirement for that Gate maps to at least one AC.
2. Every AC maps to at least one Test Item.
3. Browser E2E is used only for critical cross-layer journeys.
4. No Pxx requires 06/07/P00/other Pxx to determine its package contract.
5. architecture unresolved items affecting the Gate are zero.
