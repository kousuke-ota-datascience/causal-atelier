# Product Concept Memo — ENH-E7 delta

Ariadne is reorganized around two primary user responsibilities:

1. Project Management — create and manage Project resources and versioned analysis inputs.
2. Analysis Workspace — analyze within an explicit Project context.

The design removes duplicate analytical navigation from the Project-management hierarchy while preserving the ENH-E6 Family / Stage model.
