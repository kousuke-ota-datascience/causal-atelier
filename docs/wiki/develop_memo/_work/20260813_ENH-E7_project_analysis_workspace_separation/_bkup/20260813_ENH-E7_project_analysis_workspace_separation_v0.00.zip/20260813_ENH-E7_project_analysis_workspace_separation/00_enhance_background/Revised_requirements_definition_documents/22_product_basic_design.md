# Product Basic Design — ENH-E7 delta

```text
Projects
├─ Project List
├─ New Project
└─ Selected Project
   ├─ Overview
   ├─ Research Context
   ├─ Data
   └─ Results / Lineage

Analysis Workspace
├─ Analysis Context
├─ Family tabs
├─ Stage sidebar
└─ Stage Contents
```

Project Management and Analysis Workspace are different surfaces with different navigation scopes.

Analysis Context contains Current Project, Active Research Context, Dataset Version and Analysis View. Current Project is read-only in Analysis Workspace.
