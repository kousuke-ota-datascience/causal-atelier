# Logical Data Design — ENH-E7 delta

## Decision

No logical persistence model change is expected or authorized by ENH-E7.

Existing Project, Research Context, Dataset Version, Analysis View, Result and Lineage domain objects remain authoritative.

Analysis View is clarified as a Family-crossing analysis input at the UI responsibility level. This clarification does not by itself change persistence schema or cardinality.

Any required schema change discovered during implementation must stop the affected package and trigger Architecture Review / contract amendment.
