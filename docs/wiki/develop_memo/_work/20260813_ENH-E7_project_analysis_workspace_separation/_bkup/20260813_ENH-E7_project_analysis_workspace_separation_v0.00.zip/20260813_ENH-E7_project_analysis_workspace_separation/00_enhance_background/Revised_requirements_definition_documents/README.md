# ENH-E7 Revised Requirements Definition Documents

These are ENH-E7 effective-delta snapshots, not replacements for repository-wide canonical documents until approved and merged.

- `00_product_concept_memo.md`: IA concept delta.
- `10_requirements_definition.md`: ENH-E7 product requirements.
- `21_logical_data_design.md`: no logical-data-model change expected.
- `22_product_basic_design.md`: screen / navigation ownership.
- `23_api_interface_design.md`: no API change expected.
- `30_detailed_design.md`: route/context/surface mapping.

Status: PROPOSED_PENDING_ARCHITECTURE_REVIEW.
