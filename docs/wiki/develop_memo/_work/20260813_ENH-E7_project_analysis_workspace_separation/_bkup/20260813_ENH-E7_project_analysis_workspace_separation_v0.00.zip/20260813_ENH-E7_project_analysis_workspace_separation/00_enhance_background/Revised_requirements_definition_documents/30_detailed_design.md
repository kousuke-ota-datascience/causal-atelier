# Detailed Design — ENH-E7 delta

## Project routes

- `/projects`
- `/projects/new`
- `/projects/<id>/overview`
- `/projects/<id>/context`
- `/projects/<id>/data`
- `/projects/<id>/results`
- `/projects/<id>` normalizes to `/projects/<id>/overview`

## Analysis route

- `/projects/<id>/analysis/<family>/<stage>` remains canonical.
- existing resource-route extension remains protected.

## Context behavior

- Current Project: URL-derived, read-only.
- Research Context: selectable existing resource.
- Dataset Version: selectable existing resource.
- Analysis View: selectable existing view compatible with Dataset Version.
- Family/Stage route is not rewritten merely because context selection changes.

## Surface migration

Causal, Exploratory and Predictive mappings are defined in `../04_design_revision.md` and Gate G02 package contracts.

## Browser semantics

Direct link, reload, Back and Forward must be observable product behavior, not an implementation detail.
