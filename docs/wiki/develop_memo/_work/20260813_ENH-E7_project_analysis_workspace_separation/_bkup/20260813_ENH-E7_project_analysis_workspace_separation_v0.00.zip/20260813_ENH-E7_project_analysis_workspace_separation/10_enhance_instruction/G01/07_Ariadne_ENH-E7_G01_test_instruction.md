# Ariadne ENH-E7 G01 Test Instruction — Gate Verification Contract

**Document class:** Primary Execution Contract  
**Self-containment:** MUST  
**Project:** Ariadne  
**Enhancement:** ENH-E7  
**Active Gate:** G01  
**Verification contract status:** DRAFT_NOT_FROZEN  
**Current State Control Sheet:** `docs/wiki/develop_memo/_work/20260813_ENH-E7_project_analysis_workspace_separation/Current_State_Control_Sheet.md`

## 1. Acceptance authority

This 07 becomes the original Gate Acceptance Criteria authority only when Human/operator changes it to FROZEN before Gate execution.

Work Package completion, Coding self-check and `READY_FOR_TEST` are not Gate acceptance.

## 2. Gate objective / claim

Establish canonical Project Management routing and relocate existing Project lifecycle, Research Context, Data/Analysis View and Results/Lineage functions to explicit Project-local responsibilities without changing domain semantics.

PASS establishes:

Project creation, selection and management become an independent URL-authoritative Project Management surface, and downstream work may rely on Project routes, section ownership and analysis-input resource ownership.

## 3. Effective verification context

- Fixed Trial Candidate must be identified before product tests.
- product semantics are judged against the complete AC below.
- protected upstream contracts are blocking regressions.
- Test Agent must not modify production/test/dependency/migration code.
- Coding reports are evidence inputs, not acceptance authority.

## 4. Required verification inputs

- Implementation Completion Report generated at Candidate Assembly.
- Fixed Trial Candidate full SHA from that report.
- actual tested checkout full SHA.
- current source/test/runtime facts.
- protected PASS evidence: ENH-E6 G01.
- remediation context only if a previous formal FAIL created one.

## 5. Candidate identity audit — MUST FIRST

1. obtain Fixed Trial Candidate SHA.
2. record actual checkout/HEAD.
3. audit any diff after Fixed Candidate.
4. block if candidate identity or candidate-affecting diff is ambiguous.

## 6. Acceptance Criteria

| AC ID | Criterion | Required evidence | Severity |
|---|---|---|---|
| AC-G01-01 | `/projects` is the canonical Project List surface. | independent source/test/runtime evidence | MUST |
| AC-G01-02 | `/projects/new` is the canonical Project Register surface. | independent source/test/runtime evidence | MUST |
| AC-G01-03 | Successful Project creation transitions to `/projects/<id>/overview`. | independent source/test/runtime evidence | MUST |
| AC-G01-04 | `/projects/<id>` normalizes to `/projects/<id>/overview` without duplicate history entry. | independent source/test/runtime evidence | MUST |
| AC-G01-05 | Overview / Research Context / Data / Results local navigation works and URL reflects the active section. | independent source/test/runtime evidence | MUST |
| AC-G01-06 | Project metadata and Dataset/Analysis View lifecycle management are separate responsibilities. | independent source/test/runtime evidence | MUST |
| AC-G01-07 | Project Archive belongs to selected Project / Overview. | independent source/test/runtime evidence | MUST |
| AC-G01-08 | Analysis View lifecycle management belongs to Data. | independent source/test/runtime evidence | MUST |
| AC-G01-09 | Analysis View remains a Family-crossing analysis input rather than an Exploratory-only object. | independent source/test/runtime evidence | MUST |
| AC-G01-10 | Results / Lineage retains existing cross-analysis functions. | independent source/test/runtime evidence | MUST |
| AC-G01-11 | Direct link, reload, Back and Forward work for Project routes. | independent source/test/runtime evidence | MUST |
| AC-G01-12 | Existing Project/domain semantics and protected ENH-E6 Analysis semantics do not regress. | independent source/test/runtime evidence | MUST |

## 7. Test Item plan

| Test Item ID | Name | Covers AC | Primary test layer | Gate blocking | Method |
|---|---|---|---|---|---|
| 001 | candidate_identity | META | META | YES | Audit Fixed Trial Candidate SHA vs tested checkout. |
| 002 | project_route_contract | AC-G01-01,02,03,04,05,11 | FRONTEND_CONTRACT | YES | Route parser/serializer/normalization/history contract tests. |
| 003 | project_surface_ownership | AC-G01-06,07,08,09,10 | FRONTEND_CONTRACT | YES | DOM/static/frontend contract tests for ownership and absence of mixed responsibilities. |
| 004 | project_domain_regression | AC-G01-03,07,08,10,12 | API_INTEGRATION/UNIT_DOMAIN | YES | Existing Project/Context/Data/Result regression tests plus focused additions. |
| 005 | project_browser_journey | AC-G01-01,02,03,05,11 | BROWSER_E2E | YES | Real browser: Projects -> New Project/cancel or select -> Overview -> Context -> Data -> Results -> Back/Forward/reload. |
| 006 | protected_analysis_regression | AC-G01-12 | FRONTEND_CONTRACT | YES | Run ENH-E6 protected Analysis navigation regression suite unchanged where possible. |

`999` is reserved for Gate Decision.


### Browser E2E execution policy

Use the repository's existing browser E2E harness and a clean/current-source environment. Do not substitute static DOM inspection for the browser Test Items.

For every blocking browser Test Item record:

- canonical command actually used.
- environment bootstrap/teardown.
- semantic synchronization point.
- observable assertion.
- screenshot/trace/console/network evidence when available.
- failure classification.

A harness/environment defect that prevents product judgment is BLOCKED, not product FAIL.


## 8. Protected passed-Gate regression

| Previous Gate | Protected semantic | Regression Test Item | Required result |
|---|---|---|---|
| ENH-E6 G01 | ENH-E6 G01 PASS candidate 575cdd139aea09d4f19b46ab6a6d38545f645c71: canonical Analysis Family/Stage navigation and Analysis transition semantics. | applicable regression item above | PASS |

## 9. Transition Debt audit

No intentional open Transition Debt is planned. Legacy URL compatibility is a product requirement and must not be treated as temporary debt.

## 10. Test Agent prohibited work

- production code modification.
- automated test code modification.
- migration/dependency modification.
- Acceptance Criteria modification.
- implementation repair.
- replacing Fixed Candidate with a package checkpoint.
- reading Coding Agent's Pxx as acceptance authority.

## 11. Evidence requirements

Every Test Item report records:

- Fixed Trial Candidate full SHA.
- tested repository full SHA.
- exact command/method and exit code.
- raw relevant evidence.
- Facts vs Interpretation separately.
- AC mapping.
- reproduction procedure.

## 12. Decision semantics

### PASS

All MUST AC, candidate identity audit, required regression and blocking Test Items PASS.

### FAIL

The candidate is testable and verified evidence shows a MUST AC/protected semantic violation.

### BLOCKED

Candidate identity, environment, harness, prerequisite or contract ambiguity prevents valid product judgment.

## 13. Required outputs

- one Test Item report per planned item.
- `999_gate_decision` report.
- stop after PASS / FAIL / BLOCKED decision.
