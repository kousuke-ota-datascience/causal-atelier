# Ariadne ENH-E7 G02 Test Instruction — Gate Verification Contract

**Document class:** Primary Execution Contract  
**Self-containment:** MUST  
**Project:** Ariadne  
**Enhancement:** ENH-E7  
**Active Gate:** G02  
**Verification contract status:** DRAFT_NOT_FROZEN  
**Current State Control Sheet:** `docs/wiki/develop_memo/_work/20260813_ENH-E7_project_analysis_workspace_separation/Current_State_Control_Sheet.md`

## 1. Acceptance authority

This 07 becomes the original Gate Acceptance Criteria authority only when Human/operator changes it to FROZEN before Gate execution.

Work Package completion, Coding self-check and `READY_FOR_TEST` are not Gate acceptance.

## 2. Gate objective / claim

Establish the final ENH-E7 Analysis Workspace without changing Analysis domain/execution semantics and remove duplicate analytical navigation only after the replacement surface is operable.

PASS establishes:

Analysis Workspace becomes a separate analysis surface with Analysis Context, Family/Stage navigation, mapped existing analysis surfaces, cross-surface navigation, legacy compatibility and browser-history semantics usable together.

## 3. Effective verification context

- Fixed Trial Candidate must be identified before product tests.
- product semantics are judged against the complete AC below.
- protected upstream contracts are blocking regressions.
- Test Agent must not modify production/test/dependency/migration code.
- Coding reports are evidence inputs, not acceptance authority.

## 4. Required verification inputs

- Implementation Completion Report generated at Candidate Assembly.
- Fixed Trial Candidate full SHA from that report.
- actual tested checkout full SHA.
- current source/test/runtime facts.
- protected PASS evidence: ENH-E7 G01 + ENH-E6 G01.
- remediation context only if a previous formal FAIL created one.

## 5. Candidate identity audit — MUST FIRST

1. obtain Fixed Trial Candidate SHA.
2. record actual checkout/HEAD.
3. audit any diff after Fixed Candidate.
4. block if candidate identity or candidate-affecting diff is ambiguous.

## 6. Acceptance Criteria

| AC ID | Criterion | Required evidence | Severity |
|---|---|---|---|
| AC-G02-01 | Analysis Workspace is a separate surface from Project Management. | independent source/test/runtime evidence | MUST |
| AC-G02-02 | Analysis Context exposes Current Project, Research Context, Dataset Version and Analysis View. | independent source/test/runtime evidence | MUST |
| AC-G02-03 | Current Project is read-only in Analysis Workspace. | independent source/test/runtime evidence | MUST |
| AC-G02-04 | Project changes occur through Projects / Project Management. | independent source/test/runtime evidence | MUST |
| AC-G02-05 | Research Context / Dataset Version / Analysis View can be selected as current inputs with valid dependency handling. | independent source/test/runtime evidence | MUST |
| AC-G02-06 | Family navigation exists only in Analysis Workspace. | independent source/test/runtime evidence | MUST |
| AC-G02-07 | Stage navigation is vertical under the active Family and selected state is observable. | independent source/test/runtime evidence | MUST |
| AC-G02-08 | Existing Causal surfaces are operable from the frozen Causal Stage mapping. | independent source/test/runtime evidence | MUST |
| AC-G02-09 | Existing Exploratory surfaces are operable from the frozen Exploratory Stage mapping. | independent source/test/runtime evidence | MUST |
| AC-G02-10 | Existing Predictive surfaces are operable from the frozen Predictive Stage mapping. | independent source/test/runtime evidence | MUST |
| AC-G02-11 | Predictive Execution semantics are unchanged. | independent source/test/runtime evidence | MUST |
| AC-G02-12 | Canonical Analysis URL semantics are unchanged. | independent source/test/runtime evidence | MUST |
| AC-G02-13 | Family default-Stage semantics remain catalog-authoritative. | independent source/test/runtime evidence | MUST |
| AC-G02-14 | Legacy analytical URLs normalize to canonical Analysis routes. | independent source/test/runtime evidence | MUST |
| AC-G02-15 | Project -> Analysis -> Project navigation works. | independent source/test/runtime evidence | MUST |
| AC-G02-16 | Analysis -> Results / Lineage navigation works. | independent source/test/runtime evidence | MUST |
| AC-G02-17 | Deep-link / reload / Back / Forward work for Analysis routes. | independent source/test/runtime evidence | MUST |
| AC-G02-18 | Existing resource-route semantics are preserved. | independent source/test/runtime evidence | MUST |
| AC-G02-19 | ENH-E6 protected Analysis navigation semantics do not regress. | independent source/test/runtime evidence | MUST |

## 7. Test Item plan

| Test Item ID | Name | Covers AC | Primary test layer | Gate blocking | Method |
|---|---|---|---|---|---|
| 001 | candidate_identity | META | META | YES | Audit Fixed Trial Candidate SHA vs tested checkout. |
| 002 | analysis_context_contract | AC-G02-01,02,03,04,05,06,07 | FRONTEND_CONTRACT | YES | DOM/state/route contract tests for shell/context and absence of duplicate navigation. |
| 003 | analysis_navigation_contract | AC-G02-12,13,14,17,18,19 | FRONTEND_CONTRACT | YES | Existing AnalysisNavigation plus legacy/resource/history regression. |
| 004 | causal_stage_operability | AC-G02-08,19 | FRONTEND_CONTRACT/API_INTEGRATION | YES | Causal mapped-surface operability and existing execution regression. |
| 005 | exploratory_stage_operability | AC-G02-09,19 | FRONTEND_CONTRACT/API_INTEGRATION | YES | Exploratory mapped-surface operability and existing operation regression. |
| 006 | predictive_stage_semantics | AC-G02-10,11,19 | FRONTEND_CONTRACT/API_INTEGRATION | YES | Predictive mapped presentation plus existing execution-model regression. |
| 007 | legacy_and_cross_surface_routing | AC-G02-14,15,16,17,18 | FRONTEND_CONTRACT | YES | Legacy normalization and Project/Analysis/Results route contract tests. |
| 008 | analysis_main_browser_journey | AC-G02-01,02,06,07,08,09,10,15,16 | BROWSER_E2E | YES | Real browser: selected Project -> Analysis -> Family/Stage/surface checks -> Results -> Project Management. |
| 009 | analysis_history_compat_browser | AC-G02-12,13,14,17,18,19 | BROWSER_E2E | YES | Real browser: canonical/legacy deep link -> normalization -> stage/family change -> reload -> Back/Forward. |

`999` is reserved for Gate Decision.


### Browser E2E execution policy

Use the repository's existing browser E2E harness and a clean/current-source environment. Do not substitute static DOM inspection for the browser Test Items.

For every blocking browser Test Item record:

- canonical command actually used.
- environment bootstrap/teardown.
- semantic synchronization point.
- observable assertion.
- screenshot/trace/console/network evidence when available.
- failure classification.

A harness/environment defect that prevents product judgment is BLOCKED, not product FAIL.


## 8. Protected passed-Gate regression

| Previous Gate | Protected semantic | Regression Test Item | Required result |
|---|---|---|---|
| ENH-E7 G01 + ENH-E6 G01 | G01 final PASS contract plus ENH-E6 Analysis canonical route / Family / Stage navigation semantics. | applicable regression item above | PASS |

## 9. Transition Debt audit

No intentional open Transition Debt is planned. Legacy URL compatibility is a product requirement and must not be treated as temporary debt.

## 10. Test Agent prohibited work

- production code modification.
- automated test code modification.
- migration/dependency modification.
- Acceptance Criteria modification.
- implementation repair.
- replacing Fixed Candidate with a package checkpoint.
- reading Coding Agent's Pxx as acceptance authority.

## 11. Evidence requirements

Every Test Item report records:

- Fixed Trial Candidate full SHA.
- tested repository full SHA.
- exact command/method and exit code.
- raw relevant evidence.
- Facts vs Interpretation separately.
- AC mapping.
- reproduction procedure.

## 12. Decision semantics

### PASS

All MUST AC, candidate identity audit, required regression and blocking Test Items PASS.

### FAIL

The candidate is testable and verified evidence shows a MUST AC/protected semantic violation.

### BLOCKED

Candidate identity, environment, harness, prerequisite or contract ambiguity prevents valid product judgment.

## 13. Required outputs

- one Test Item report per planned item.
- `999_gate_decision` report.
- stop after PASS / FAIL / BLOCKED decision.
