# ENH-E7 Enhance Instructions

**Execution mode:** WORK_PACKAGE for G01 and G02.

## Gate semantics

- Gate = semantic acceptance boundary.
- Work Package = bounded Coding Agent execution unit.
- Trial = one candidate-to-independent-verification transaction.
- Package completion is not Gate PASS.

## Gate order

```text
G01 final PASS
    ↓
G02 eligible to execute
```

## Freeze discipline

All generated 06 / 07 / P00 / Pxx files start as `DRAFT_NOT_FROZEN`.

Before execution, Human/operator must:

1. confirm Architecture Review.
2. resolve local repository identity.
3. review and freeze Gate 06 / 07.
4. ensure Pxx is self-contained.
5. run Agent Execution Readiness preflight.

## Information isolation

P00 and parent 06/07 paths inside Pxx are traceability only. Coding Agents are instructed not to read them to determine package semantics.

## Remediation

08 / 09 files in each Gate directory are template-only and inactive until formal workflow triggers occur.
