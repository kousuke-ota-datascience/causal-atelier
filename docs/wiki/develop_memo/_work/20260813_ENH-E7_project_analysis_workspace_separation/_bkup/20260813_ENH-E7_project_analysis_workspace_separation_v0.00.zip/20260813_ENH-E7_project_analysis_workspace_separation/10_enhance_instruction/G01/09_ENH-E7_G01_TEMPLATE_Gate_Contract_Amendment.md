# ENH-E7 G01 Gate Contract Amendment — TEMPLATE ONLY

**Status:** TEMPLATE_ONLY_DO_NOT_EXECUTE

Use only when the Gate semantic claim / Acceptance Criteria itself must change.

Required concrete amendment fields:

- Amendment ID.
- trigger and evidence.
- original semantic.
- amended semantic.
- impacted Requirements / Design / AC / Test Items.
- impact on passed-Gate contracts.
- Human approval.
- effective Trial.
