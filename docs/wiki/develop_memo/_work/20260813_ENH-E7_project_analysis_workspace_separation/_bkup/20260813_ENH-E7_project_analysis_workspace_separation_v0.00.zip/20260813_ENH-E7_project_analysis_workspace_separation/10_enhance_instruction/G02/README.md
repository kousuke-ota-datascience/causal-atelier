# ENH-E7 G02 — Analysis Workspace Contract

**Status:** DRAFT_NOT_FROZEN  
**Execution Mode:** WORK_PACKAGE

## Gate claim

Analysis Workspace becomes a separate analysis surface with Analysis Context, Family/Stage navigation, mapped existing analysis surfaces, cross-surface navigation, legacy compatibility and browser-history semantics usable together.

## Package order

- P01 — Analysis Shell / Analysis Context — depends on G01 PASS
- P02 — Project <-> Analysis Routing — depends on P01
- P03 — Causal Stage Surface Migration — depends on P01,P02
- P04 — Exploratory Stage Surface Migration — depends on P01,P02
- P05 — Predictive Stage Surface Migration — depends on P01,P02
- P06 — Legacy Cutover / Integration / Regression — depends on P03,P04,P05

## Active-contract rule

- 06/07 become authoritative only after Human/operator changes status to FROZEN following Architecture Review.
- Pxx becomes executable only if its dependency state and preflight are PASS.
- 08 is inactive until a formal FAIL.
- 09 is inactive unless a semantic Gate contract amendment is explicitly approved.
