# ENH-E7 G01 P05 — Data / Analysis View Surface

**Document class:** Primary Execution Contract  
**Self-containment:** MUST  
**Gate:** G01  
**Trial at first issuance:** 01  
**Package:** P05  
**Depends on:** P01,P03  
**Status at issuance:** DRAFT_NOT_FROZEN

## 1. Purpose

Make Data the lifecycle-management authority for Dataset, Dataset Version, Schema/Preview and Analysis View.

## 2. Effective Gate constraints applicable to this package

- Project Management and Analysis Workspace are different navigation scopes.
- Existing domain/execution semantics are protected.
- ENH-E6 Analysis canonical-route / Family / Stage semantics must not regress.
- package completion is not Gate PASS.
- this document is the Coding Agent's normative workflow implementation contract.
- parent 06 / 07 / P00 / other Pxx are traceability only and MUST NOT be read to fill missing package requirements.
- source, tests, config and migration files may be inspected as implementation substrate.
- if this package requires a backend/API/persistence semantic change not explicitly authorized below, stop.

## 3. In scope

- Dataset Register
- Registered Dataset / Version
- Schema / Preview
- Analysis View lifecycle management

## 4. Explicitly out of scope

- Analysis View must remain usable across Families.
- Do not require an API/schema change unless current domain APIs are proven insufficient; block instead.

Also out of scope:

- Acceptance Criteria changes.
- unrelated cleanup/refactoring.
- next package implementation.
- workflow artifact changes outside required package reports.

## 5. Entry criteria / required evidence

- current checkout is on `feature/ariadne_mvp_e7`.
- local Agent Execution Readiness for `G01/P05/Trial01` is PASS.
- dependency requirement is satisfied: `P01,P03`.
- Architecture Review and Gate contracts are FROZEN before execution.
- no unresolved source fact makes the listed in-scope behavior ambiguous.

If any entry criterion cannot be verified, stop as `PACKAGE_BLOCKED`.

## 6. Required implementation

1. Inspect the current source/tests only as needed to locate the responsibilities listed in §3.
2. Implement the ownership/behavior defined in §3 while preserving §2/§4 constraints.
3. Add or update focused automated tests using repository conventions.
4. Do not create substitute backend semantics to make the UI appear complete.
5. Record any source fact that contradicts this contract; stop rather than silently reinterpret the contract.

## 7. Focused verification

| Check | Command / method | Required result |
|---|---|---|
| focused product test | `uv run pytest -q tests/product/test_enh_e7_g01_p05_data_analysis_view_surface.py` | PASS after the package creates/updates the focused test |
| existing nearby regressions | run repository tests covering touched responsibility | PASS |
| static/source audit | inspect diff and ownership/navigation references | no out-of-scope semantic change |

If the repository's established test naming/layout makes the proposed focused path inappropriate, the Coding Agent may use the repository-standard equivalent, but must report the exact command and coverage.

## 8. Protected contract constraints

- Protected upstream: ENH-E6 G01 PASS candidate 575cdd139aea09d4f19b46ab6a6d38545f645c71: canonical Analysis Family/Stage navigation and Analysis transition semantics.
- No open Transition Debt is intentionally introduced by this package.
- Legacy URL compatibility must not be removed in G01; in G02 it may be normalized but not deleted.

## 9. Checkpoint / reporting rule

On package completion:

1. commit implementation-affecting changes.
2. fix the implementation checkpoint full SHA.
3. create an implementation checkpoint report.
4. create/update the package execution status report.
5. distinguish any report-only commit SHA from the implementation checkpoint SHA.

## 10. Package completion criteria

Dataset and Analysis View focused regressions pass.

Additionally:

- all §7 focused verification is complete.
- no unresolved package blocker remains.
- checkpoint full SHA is fixed.
- reports are written.

## 11. External reference policy

The Coding Agent may inspect source/test/runtime facts. It must not read Gate 06 / Gate 07 / P00 / other Pxx / 00 / 20 / 30 workflow artifacts to complete the package specification.

If this Pxx itself is insufficient or contradicts verified source facts, stop as `PACKAGE_BLOCKED_CONTRACT_AMBIGUITY`.

## 12. Stop rule

- scope complete -> `PACKAGE_COMPLETE`
- cannot continue safely -> `PACKAGE_BLOCKED`
- never declare Gate PASS/FAIL
- never continue automatically into another package
