# Requirements Definition — ENH-E7 effective delta

This snapshot summarizes the effective product requirements proposed by ENH-E7.

| E7-REQ-001 | `/projects` is the canonical Project List surface. | G01 |
| E7-REQ-002 | `/projects/new` is the canonical Project Register surface. | G01 |
| E7-REQ-003 | `/projects/<project_id>/overview` is the canonical selected-Project default surface. | G01 |
| E7-REQ-004 | Overview / Research Context / Data / Results are Project Management local navigation. | G01 |
| E7-REQ-005 | Project metadata and Dataset / Analysis View lifecycle management are separate responsibilities. | G01 |
| E7-REQ-006 | Project Archive is a selected-Project lifecycle operation owned by Overview. | G01 |
| E7-REQ-007 | Analysis View lifecycle management is owned by Data and usable across Analysis Families. | G01 |
| E7-REQ-008 | Analysis Workspace is a separate surface from Project Management. | G02 |
| E7-REQ-009 | Analysis Context exposes Current Project, Active Research Context, Dataset Version, and Analysis View. | G02 |
| E7-REQ-010 | Current Project is read-only inside Analysis Workspace; project changes go through Projects / Project Management. | G02 |
| E7-REQ-011 | Family and Stage navigation appear only in Analysis Workspace. | G02 |
| E7-REQ-012 | Canonical Analysis route `/projects/<id>/analysis/<family>/<stage>` semantics remain unchanged. | G02 |
| E7-REQ-013 | Family switching uses the existing catalog authority for default Stage selection. | G02 |
| E7-REQ-014 | Existing Causal surfaces remain operable from mapped Causal Stage Contents. | G02 |
| E7-REQ-015 | Existing Exploratory surfaces remain operable from mapped Exploratory Stage Contents. | G02 |
| E7-REQ-016 | Existing Predictive surfaces remain operable from mapped Predictive Stage Contents. | G02 |
| E7-REQ-017 | Predictive Stage navigation does not create a new Predictive Execution model. | G02 |
| E7-REQ-018 | Legacy analytical URLs normalize to canonical Analysis routes. | G02 |
| E7-REQ-019 | Direct-link, reload, Back and Forward work for Project and Analysis routes. | G01/G02 |
| E7-REQ-020 | Results / Lineage owns persisted cross-analysis aggregation, comparison, artifacts, lineage and annotation. | G01 |
| E7-REQ-021 | ENH-E7 UI restructuring alone must not change backend analysis/domain semantics. | G01/G02 |

Workflow execution-control requirements are defined in `../03_requirements_revision.md` and apply to the enhancement process rather than product runtime.
