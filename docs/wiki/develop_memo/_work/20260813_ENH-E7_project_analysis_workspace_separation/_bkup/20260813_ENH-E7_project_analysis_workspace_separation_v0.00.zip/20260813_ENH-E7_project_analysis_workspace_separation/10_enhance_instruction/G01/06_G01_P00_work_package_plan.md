# ENH-E7 G01 P00 Work Package Plan

**Document class:** Planning / Operator Artifact  
**Status:** DRAFT_NOT_FROZEN  
**P00 is not an implementation Work Package.**

## 1. Why Work Package Mode is required

The Gate spans multiple UI ownership/routing boundaries and needs bounded execution, dependency control and failure localization. Gate semantics remain indivisible.

## 2. Effective Gate semantic boundary

- Gate claim: Project creation, selection and management become an independent URL-authoritative Project Management surface, and downstream work may rely on Project routes, section ownership and analysis-input resource ownership.
- Downstream result: G02 may rely on selected-Project routing, Data-owned Analysis View management, Results/Lineage ownership and a stable Project Management return target.
- Shared constraints:
  - existing domain semantics are protected.
  - package completion is not Gate PASS.
  - each Pxx must be self-contained for its Coding Agent.
  - Coding Agent must not use P00 / 06 / 07 / other Pxx to supplement package requirements.

## 3. Package map

| Package | Purpose | Depends on | Entry criterion | Exit criterion | Focused verification |
|---|---|---|---|---|---|
| P01 | Create/centralize Project route parse/serialize/normalization and browser-history behavior. | NONE | Gate entry criteria + preflight PASS | Focused Project route contract tests pass. | focused tests in assigned Pxx |
| P02 | Make Project List and New Project distinct route-backed surfaces. | P01 | Gate entry criteria + preflight PASS + dependency complete: P01 | Project list/create focused tests pass. | focused tests in assigned Pxx |
| P03 | Move selected-Project metadata/lifecycle responsibility to Overview. | P01,P02 | Gate entry criteria + preflight PASS + dependency complete: P01,P02 | Overview ownership and lifecycle regression tests pass. | focused tests in assigned Pxx |
| P04 | Place existing Research Context lifecycle/history/Related Analysis on the Project Context surface. | P01,P03 | Gate entry criteria + preflight PASS + dependency complete: P01,P03 | Research Context focused regression passes. | focused tests in assigned Pxx |
| P05 | Make Data the lifecycle-management authority for Dataset, Dataset Version, Schema/Preview and Analysis View. | P01,P03 | Gate entry criteria + preflight PASS + dependency complete: P01,P03 | Dataset and Analysis View focused regressions pass. | focused tests in assigned Pxx |
| P06 | Make Results / Lineage the Project-local persisted cross-analysis aggregation surface. | P01,P03 | Gate entry criteria + preflight PASS + dependency complete: P01,P03 | Existing Results/Lineage focused regressions pass. | focused tests in assigned Pxx |
| P07 | Integrate G01 Project surfaces and prove browser/history/domain regression before Candidate Assembly. | P02,P03,P04,P05,P06 | Gate entry criteria + preflight PASS + dependency complete: P02,P03,P04,P05,P06 | Gate-wide G01 self-check and one critical browser journey pass. | focused tests in assigned Pxx |

## 4. Execution DAG

```text
P01 (NONE)
P02 (P01)
P03 (P01,P02)
P04 (P01,P03)
P05 (P01,P03)
P06 (P01,P03)
P07 (P02,P03,P04,P05,P06)
```

Dependencies in the package map are normative; execution may be parallel only where all dependencies and source-overlap risks permit it.

## 5. Shared package rules

- stay inside assigned Pxx scope.
- preserve protected contracts.
- do not call package completion Gate PASS.
- if dependency evidence is unavailable, stop rather than infer it.
- Pxx text contains the effective constraints necessary for execution.
- report exact checkpoint identity.

## 6. Package completion semantics

`PACKAGE_COMPLETE` means assigned scope is implemented, focused verification passes, checkpoint full SHA is fixed, and reports are written.

It does not mean `READY_FOR_TEST`, Gate PASS, verified-state promotion or downstream unlock.

## 7. Interruption / restart

Agent interruption, self-check failure, same-package correction and checkpoint-report correction remain within the same Trial. A new Trial requires formal Gate FAIL.

## 8. Candidate Assembly

Required package set: P01, P02, P03, P04, P05, P06, P07.

Candidate Assembly performs package-chain audit, integration self-check, protected regression self-check, candidate-affecting working-tree audit, Fixed Trial Candidate freeze and Completion Report creation.

## 9. Trial completion

All required packages complete + Candidate Assembly complete -> `READY_FOR_TEST`.

## 10. Remediation

After formal FAIL, create distinct remediation package identity (`R01` etc.) or an approved 08 remediation contract. Do not reuse original Pxx identity as if no Trial failure occurred.
