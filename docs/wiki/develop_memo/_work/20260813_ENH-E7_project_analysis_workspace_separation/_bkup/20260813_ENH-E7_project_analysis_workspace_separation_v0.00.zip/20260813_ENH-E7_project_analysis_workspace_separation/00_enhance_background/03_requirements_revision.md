# ENH-E7 Requirements Revision

**Document class:** Planning / Decision Artifact  
**Status:** PROPOSED_PENDING_ARCHITECTURE_REVIEW

## 1. Requirement delta

Before ENH-E7, Project lifecycle navigation and analytical navigation are mixed in one application hierarchy. ENH-E7 establishes explicit Project Management and Analysis Workspace responsibilities.

| Requirement ID | After requirement | Gate |
|---|---|---|
| E7-REQ-001 | `/projects` is the canonical Project List surface. | G01 |
| E7-REQ-002 | `/projects/new` is the canonical Project Register surface. | G01 |
| E7-REQ-003 | `/projects/<project_id>/overview` is the canonical selected-Project default surface. | G01 |
| E7-REQ-004 | Overview / Research Context / Data / Results are Project Management local navigation. | G01 |
| E7-REQ-005 | Project metadata and Dataset / Analysis View lifecycle management are separate responsibilities. | G01 |
| E7-REQ-006 | Project Archive is a selected-Project lifecycle operation owned by Overview. | G01 |
| E7-REQ-007 | Analysis View lifecycle management is owned by Data and usable across Analysis Families. | G01 |
| E7-REQ-008 | Analysis Workspace is a separate surface from Project Management. | G02 |
| E7-REQ-009 | Analysis Context exposes Current Project, Active Research Context, Dataset Version, and Analysis View. | G02 |
| E7-REQ-010 | Current Project is read-only inside Analysis Workspace; project changes go through Projects / Project Management. | G02 |
| E7-REQ-011 | Family and Stage navigation appear only in Analysis Workspace. | G02 |
| E7-REQ-012 | Canonical Analysis route `/projects/<id>/analysis/<family>/<stage>` semantics remain unchanged. | G02 |
| E7-REQ-013 | Family switching uses the existing catalog authority for default Stage selection. | G02 |
| E7-REQ-014 | Existing Causal surfaces remain operable from mapped Causal Stage Contents. | G02 |
| E7-REQ-015 | Existing Exploratory surfaces remain operable from mapped Exploratory Stage Contents. | G02 |
| E7-REQ-016 | Existing Predictive surfaces remain operable from mapped Predictive Stage Contents. | G02 |
| E7-REQ-017 | Predictive Stage navigation does not create a new Predictive Execution model. | G02 |
| E7-REQ-018 | Legacy analytical URLs normalize to canonical Analysis routes. | G02 |
| E7-REQ-019 | Direct-link, reload, Back and Forward work for Project and Analysis routes. | G01/G02 |
| E7-REQ-020 | Results / Lineage owns persisted cross-analysis aggregation, comparison, artifacts, lineage and annotation. | G01 |
| E7-REQ-021 | ENH-E7 UI restructuring alone must not change backend analysis/domain semantics. | G01/G02 |

## 2. Workflow execution requirements

| Workflow Requirement ID | Requirement |
|---|---|
| E7-WF-001 | Enhancement-specific Agent entry prompts are instantiated under this work root. |
| E7-WF-002 | Template-side Agent prompts are not used directly for execution. |
| E7-WF-003 | Enhancement-fixed identity is resolved before Agent execution. |
| E7-WF-004 | Human operator supplies only runtime execution identifiers. |
| E7-WF-005 | Work Package Coding Agent normative workflow context is the assigned Pxx only. |
| E7-WF-006 | Every Pxx is self-contained for scope, constraints, verification, completion and stop rules. |
| E7-WF-007 | Coding Agent is not exposed to Gate 07 as an acceptance answer key. |
| E7-WF-008 | Document compliance and Agent Execution Readiness are separate validations. |
| E7-WF-009 | Readiness validates artifact completeness, content completeness, execution resolvability and information isolation. |
| E7-WF-010 | Readiness failure blocks Coding Agent execution. |

## 3. Removed / deprecated behavior

The following UI behavior is deprecated after G02 PASS:

- global sidebar analytical shortcuts for Explore & Visualize / Causal Discovery / Causal Inference / Predictive.
- Project metadata and Dataset management presented as one `Project / Data` responsibility.
- direct Project switching inside Analysis Workspace, if such a selector is currently present.

Legacy analytical **URLs** are not removed; they remain compatibility entries normalized to the canonical Analysis route.

## 4. Invariants

- Project Management = Project resource management.
- Analysis Workspace = analysis execution/presentation under an explicit Project context.
- Family = analysis paradigm.
- Stage = Family-local workflow/presentation view.
- Operation = executable/displayed function inside Stage.
- Navigation concepts at different abstraction levels must not be reintroduced into one hierarchy.
- Existing Causal / Exploratory / Predictive execution semantics are protected.
- Backend/API/persistence changes are not authorized unless a later approved amendment proves they are required.

## 5. Approval dependency

This revision becomes effective only after Architecture Review confirms source-level feasibility and Human approval moves it from PROPOSED to APPROVED.
