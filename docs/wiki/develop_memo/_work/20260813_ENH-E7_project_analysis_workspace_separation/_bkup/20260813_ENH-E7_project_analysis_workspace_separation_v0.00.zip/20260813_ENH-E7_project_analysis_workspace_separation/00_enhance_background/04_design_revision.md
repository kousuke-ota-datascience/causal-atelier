# ENH-E7 Design Revision

**Document class:** Planning / Decision Artifact  
**Status:** PROPOSED_PENDING_ARCHITECTURE_REVIEW

## 1. Navigation authority delta

```text
Application Navigation
├─ Project Navigation
│  ├─ /projects
│  ├─ /projects/new
│  └─ /projects/<id>/<section>
└─ Analysis Navigation
   └─ /projects/<id>/analysis/<family>/<stage>[/resource/...]
```

Project-route authority must not be folded into the Analysis-specific navigation state merely for convenience.

Existing ENH-E6 Analysis navigation / transition authority is a protected upstream semantic and should be reused rather than generalized unnecessarily.

## 2. UI ownership

```text
Projects Surface
    Project List / New Project entry

Project Management Shell
    Project header
    local vertical navigation
    Overview / Context / Data / Results content

Analysis Workspace Shell
    Analysis Context
    Family horizontal tabs
    Stage vertical navigation
    Stage Contents
```

## 3. Analysis Context

```text
Current Project          read-only; URL project_id authority
Active Research Context selectable existing Project context
Dataset Version          selectable existing Project dataset version
Analysis View            selectable existing view for selected dataset version
```

Project changes are performed through Projects / Project Management.

Changing Research Context / Dataset Version / Analysis View does not rewrite Family / Stage route. An incompatible Analysis View is cleared when Dataset Version changes.

## 4. Resource ownership

- Project metadata / archive -> Overview.
- Research Context lifecycle/history -> Context.
- Dataset / Dataset Version / Schema / Preview / Analysis View lifecycle -> Data.
- persisted cross-analysis results / comparison / artifacts / lineage / annotation -> Results / Lineage.
- Stage-local execution/result presentation -> Analysis Workspace.

## 5. Analysis surface migration

### Causal

- Setup: causal question/design preparation, Direct Graph Registration.
- Discovery: discovery spec, PC/GES, graph candidates, compare/edit/adopt/fix.
- Identification: identification inputs, data eligibility, gate.
- Estimation: estimator selection, override, execution/revision.
- Effects: treatment-effect results and comparison.
- Diagnostics: diagnostics and scientific warnings.
- Sensitivity: refutation and sensitivity analysis.

### Exploratory

- PROFILE -> Profile
- DISTRIBUTION -> Distribution
- ASSOCIATION -> Relationships
- GROUP_SUMMARY -> Comparison
- Saved Exploratory Results -> Findings

Data Quality / TIME_TREND / CHART must be confirmed from current source before G02 freeze. Do not invent backend operations to fill taxonomy gaps.

### Predictive

Predictive Stages are presentation/navigation views over the existing Predictive Execution:

```text
Prediction Task -> Split -> Training -> Evaluation -> Explanation -> Model Card
```

No new `Predict` backend execution is authorized by ENH-E7.

## 6. Legacy compatibility

Legacy analytical UI shortcuts are removed after the new Analysis Workspace is operable. Legacy URLs remain compatibility inputs and normalize to existing canonical Analysis URLs.

## 7. API / persistence policy

```text
Persistence migration: NONE EXPECTED
API contract change: NONE EXPECTED
Backend domain semantic change: NOT AUTHORIZED
```

Any contrary need requires architecture evidence plus approved contract amendment.

## 8. Workflow design delta

Canonical Work Package Coding Agent topology:

```text
Human operator
  -> enhancement-specific instantiated prompt
  -> assigned Pxx
  -> source / tests / config / migrations
```

The Coding Agent must not use Gate 06 / 07 / P00 / other Pxx / 00 / 20 / 30 artifacts to complete package specification.

## 9. Rollback boundary

- G01 rollback must not alter protected ENH-E6 Analysis semantics.
- G02 rollback must preserve G01 PASS if G01 has already passed.
- No rollback step may silently change persistence/domain semantics.
