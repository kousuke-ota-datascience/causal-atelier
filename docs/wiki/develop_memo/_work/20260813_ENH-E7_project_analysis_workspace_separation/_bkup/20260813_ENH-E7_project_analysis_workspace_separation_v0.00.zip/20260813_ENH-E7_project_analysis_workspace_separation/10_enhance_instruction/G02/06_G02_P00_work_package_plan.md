# ENH-E7 G02 P00 Work Package Plan

**Document class:** Planning / Operator Artifact  
**Status:** DRAFT_NOT_FROZEN  
**P00 is not an implementation Work Package.**

## 1. Why Work Package Mode is required

The Gate spans multiple UI ownership/routing boundaries and needs bounded execution, dependency control and failure localization. Gate semantics remain indivisible.

## 2. Effective Gate semantic boundary

- Gate claim: Analysis Workspace becomes a separate analysis surface with Analysis Context, Family/Stage navigation, mapped existing analysis surfaces, cross-surface navigation, legacy compatibility and browser-history semantics usable together.
- Downstream result: ENH-E7 may be considered product-complete; later enhancements may rely on separate Project and Analysis surfaces and Stage-local presentation ownership.
- Shared constraints:
  - existing domain semantics are protected.
  - package completion is not Gate PASS.
  - each Pxx must be self-contained for its Coding Agent.
  - Coding Agent must not use P00 / 06 / 07 / other Pxx to supplement package requirements.

## 3. Package map

| Package | Purpose | Depends on | Entry criterion | Exit criterion | Focused verification |
|---|---|---|---|---|---|
| P01 | Create Analysis Workspace shell and explicit current analysis-input context. | G01 PASS | Gate entry criteria + preflight PASS + dependency complete: G01 PASS | Analysis Context and shell contract tests pass. | focused tests in assigned Pxx |
| P02 | Connect Project Management, Analysis Workspace and Results/Lineage using canonical routes. | P01 | Gate entry criteria + preflight PASS + dependency complete: P01 | Cross-surface routing contract tests pass. | focused tests in assigned Pxx |
| P03 | Relocate existing Causal surfaces into Setup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivity Stage Contents. | P01,P02 | Gate entry criteria + preflight PASS + dependency complete: P01,P02 | Existing Causal operations remain operable from mapped Stage Contents. | focused tests in assigned Pxx |
| P04 | Relocate existing Exploratory operations/results into the Stage hierarchy. | P01,P02 | Gate entry criteria + preflight PASS + dependency complete: P01,P02 | Existing Exploratory operations remain operable from mapped Stage Contents. | focused tests in assigned Pxx |
| P05 | Relocate existing Predictive presentation into Setup/Train/Predict/Metrics/Explainability/Model Management without creating a new execution model. | P01,P02 | Gate entry criteria + preflight PASS + dependency complete: P01,P02 | Existing Predictive execution semantics regressions pass and mapped presentation is operable. | focused tests in assigned Pxx |
| P06 | Remove duplicate legacy analytical UI navigation, retain legacy URL compatibility, integrate browser/history/resource behavior and prepare Trial candidate. | P03,P04,P05 | Gate entry criteria + preflight PASS + dependency complete: P03,P04,P05 | Gate-wide G02 self-check and critical browser journeys pass. | focused tests in assigned Pxx |

## 4. Execution DAG

```text
P01 (G01 PASS)
P02 (P01)
P03 (P01,P02)
P04 (P01,P02)
P05 (P01,P02)
P06 (P03,P04,P05)
```

Dependencies in the package map are normative; execution may be parallel only where all dependencies and source-overlap risks permit it.

## 5. Shared package rules

- stay inside assigned Pxx scope.
- preserve protected contracts.
- do not call package completion Gate PASS.
- if dependency evidence is unavailable, stop rather than infer it.
- Pxx text contains the effective constraints necessary for execution.
- report exact checkpoint identity.

## 6. Package completion semantics

`PACKAGE_COMPLETE` means assigned scope is implemented, focused verification passes, checkpoint full SHA is fixed, and reports are written.

It does not mean `READY_FOR_TEST`, Gate PASS, verified-state promotion or downstream unlock.

## 7. Interruption / restart

Agent interruption, self-check failure, same-package correction and checkpoint-report correction remain within the same Trial. A new Trial requires formal Gate FAIL.

## 8. Candidate Assembly

Required package set: P01, P02, P03, P04, P05, P06.

Candidate Assembly performs package-chain audit, integration self-check, protected regression self-check, candidate-affecting working-tree audit, Fixed Trial Candidate freeze and Completion Report creation.

## 9. Trial completion

All required packages complete + Candidate Assembly complete -> `READY_FOR_TEST`.

## 10. Remediation

After formal FAIL, create distinct remediation package identity (`R01` etc.) or an approved 08 remediation contract. Do not reuse original Pxx identity as if no Trial failure occurred.
