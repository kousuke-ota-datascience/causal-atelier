# Ariadne ENH-E7 G02 Implementation Instruction — Gate Coding Contract

**Document class:** Primary Execution Contract  
**Self-containment:** MUST for Gate implementation semantics  
**Project:** Ariadne  
**Enhancement:** ENH-E7  
**Active Gate:** G02  
**Branch:** feature/ariadne_mvp_e7  
**Baseline:** REQUIRES_LOCAL_VERIFICATION  
**Contract status:** DRAFT_NOT_FROZEN  
**Execution Mode:** WORK_PACKAGE  
**Current State Control Sheet:** `docs/wiki/develop_memo/_work/20260813_ENH-E7_project_analysis_workspace_separation/Current_State_Control_Sheet.md`

## 1. Gate definition / acceptance claim

### Gate objective

Establish the final ENH-E7 Analysis Workspace without changing Analysis domain/execution semantics and remove duplicate analytical navigation only after the replacement surface is operable.

### Contract claim established by PASS

Analysis Workspace becomes a separate analysis surface with Analysis Context, Family/Stage navigation, mapped existing analysis surfaces, cross-surface navigation, legacy compatibility and browser-history semantics usable together.

### Downstream usable result

ENH-E7 may be considered product-complete; later enhancements may rely on separate Project and Analysis surfaces and Stage-local presentation ownership.

### Why this is one Gate

This Gate is one semantic acceptance boundary because its product claim is only downstream-usable when all listed responsibilities operate together. Package boundaries are implementation-localization boundaries and do not split this semantic claim.

## 2. Effective implementation context

- ENH-E7 separates Project resource management and Analysis execution at top-level IA.
- Existing domain semantics are preserved unless this contract explicitly says otherwise.
- G01 establishes Project Management; G02 establishes the replacement Analysis Workspace and functional surface migration.
- Browser history/direct-link are product semantics.
- package completion is not Gate PASS.

## 3. Execution Mode

Selected: `WORK_PACKAGE`.

P00 is Human/operator orchestration traceability. Work Package Coding Agents do not read P00 to complete package specifications.

## 4. Required implementation semantics

- AC-G02-01: Analysis Workspace is a separate surface from Project Management.
- AC-G02-02: Analysis Context exposes Current Project, Research Context, Dataset Version and Analysis View.
- AC-G02-03: Current Project is read-only in Analysis Workspace.
- AC-G02-04: Project changes occur through Projects / Project Management.
- AC-G02-05: Research Context / Dataset Version / Analysis View can be selected as current inputs with valid dependency handling.
- AC-G02-06: Family navigation exists only in Analysis Workspace.
- AC-G02-07: Stage navigation is vertical under the active Family and selected state is observable.
- AC-G02-08: Existing Causal surfaces are operable from the frozen Causal Stage mapping.
- AC-G02-09: Existing Exploratory surfaces are operable from the frozen Exploratory Stage mapping.
- AC-G02-10: Existing Predictive surfaces are operable from the frozen Predictive Stage mapping.
- AC-G02-11: Predictive Execution semantics are unchanged.
- AC-G02-12: Canonical Analysis URL semantics are unchanged.
- AC-G02-13: Family default-Stage semantics remain catalog-authoritative.
- AC-G02-14: Legacy analytical URLs normalize to canonical Analysis routes.
- AC-G02-15: Project -> Analysis -> Project navigation works.
- AC-G02-16: Analysis -> Results / Lineage navigation works.
- AC-G02-17: Deep-link / reload / Back / Forward work for Analysis routes.
- AC-G02-18: Existing resource-route semantics are preserved.
- AC-G02-19: ENH-E6 protected Analysis navigation semantics do not regress.

## 5. Allowed scope

- frontend routing / navigation / DOM / styles / presentation/state code required by this Gate.
- focused automated tests and repository-standard browser E2E needed by frozen 07.
- source discovery necessary to locate existing responsibilities.
- minimal refactoring strictly required to establish the specified ownership without changing domain semantics.

## 6. Explicitly prohibited scope

- new backend analysis semantics solely to fit UI taxonomy.
- persistence/schema redesign.
- unrelated framework migration or design-system rewrite.
- changing Acceptance Criteria to fit implementation.
- next-Gate implementation before its entry criteria.
- bypassing protected upstream contracts.

## 7. Protected passed-Gate contracts

| Gate | Protected semantic | Allowed interaction | Mandatory regression |
|---|---|---|---|
| ENH-E7 G01 + ENH-E6 G01 | G01 final PASS contract plus ENH-E6 Analysis canonical route / Family / Stage navigation semantics. | presentation/routing integration only | frozen 07 protected-regression Test Item |

## 8. Transition Debt

| TD ID | Required action | Exit criterion |
|---|---|---|
| NONE | NONE | No intentional temporary product debt is introduced by this draft. Legacy URL compatibility is a requirement, not temporary debt. |

## 9. Schema / migration / API / runtime policy

```text
Persistence migration: NONE EXPECTED
API contract change: NONE EXPECTED
Backend domain semantic change: NOT AUTHORIZED
```

If source inspection proves an already-required behavior cannot be implemented without one of these changes, the affected package must stop as `PACKAGE_BLOCKED_CONTRACT_CHANGE_REQUIRED`.

## 10. Automated test obligations

- 002: analysis_context_contract (FRONTEND_CONTRACT)
- 003: analysis_navigation_contract (FRONTEND_CONTRACT)
- 004: causal_stage_operability (FRONTEND_CONTRACT/API_INTEGRATION)
- 005: exploratory_stage_operability (FRONTEND_CONTRACT/API_INTEGRATION)
- 006: predictive_stage_semantics (FRONTEND_CONTRACT/API_INTEGRATION)
- 007: legacy_and_cross_surface_routing (FRONTEND_CONTRACT)
- 008: analysis_main_browser_journey (BROWSER_E2E)
- 009: analysis_history_compat_browser (BROWSER_E2E)

Detailed correctness should be tested at the lowest deterministic layer. Browser E2E is limited to critical cross-layer journeys defined in 07.

## 11. Candidate Assembly requirement

Before `READY_FOR_TEST`:

- all required Pxx are `PACKAGE_COMPLETE`.
- Gate-wide integration self-check passes.
- protected regression self-check passes.
- unresolved candidate-affecting changes are NONE.
- Fixed Trial Candidate full SHA is fixed.
- Implementation Completion Report is created.

## 12. Coding-side prohibited work

- Gate PASS/FAIL decision.
- 07 modification to avoid a failure.
- Acceptance Criteria modification.
- unapproved passed-Gate semantic change.
- package-scope convenience changes unrelated to this Gate.

## 13. Required outputs

Per package:

- package execution status report.
- implementation checkpoint report.
- checkpoint full SHA.

At Candidate Assembly:

- Fixed Trial Candidate full SHA.
- implementation completion report.
- Gate-local implementation detail report.

## 14. External reference policy

Gate 06 is Human/operator traceability and semantic authority. Work Package Coding Agents receive a self-contained Pxx and must not read this 06 to complete package specification.

Source/tests/runtime and previous PASS evidence may be inspected as factual implementation substrate.

## 15. Stop condition

Coding side stops at `READY_FOR_TEST` or explicit `BLOCKED_*`. It does not declare Gate PASS.
