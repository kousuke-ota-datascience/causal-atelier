# Ariadne ENH-E7 G01 Implementation Instruction — Gate Coding Contract

**Document class:** Primary Execution Contract  
**Self-containment:** MUST for Gate implementation semantics  
**Project:** Ariadne  
**Enhancement:** ENH-E7  
**Active Gate:** G01  
**Branch:** feature/ariadne_mvp_e7  
**Baseline:** REQUIRES_LOCAL_VERIFICATION  
**Contract status:** DRAFT_NOT_FROZEN  
**Execution Mode:** WORK_PACKAGE  
**Current State Control Sheet:** `docs/wiki/develop_memo/_work/20260813_ENH-E7_project_analysis_workspace_separation/Current_State_Control_Sheet.md`

## 1. Gate definition / acceptance claim

### Gate objective

Establish canonical Project Management routing and relocate existing Project lifecycle, Research Context, Data/Analysis View and Results/Lineage functions to explicit Project-local responsibilities without changing domain semantics.

### Contract claim established by PASS

Project creation, selection and management become an independent URL-authoritative Project Management surface, and downstream work may rely on Project routes, section ownership and analysis-input resource ownership.

### Downstream usable result

G02 may rely on selected-Project routing, Data-owned Analysis View management, Results/Lineage ownership and a stable Project Management return target.

### Why this is one Gate

This Gate is one semantic acceptance boundary because its product claim is only downstream-usable when all listed responsibilities operate together. Package boundaries are implementation-localization boundaries and do not split this semantic claim.

## 2. Effective implementation context

- ENH-E7 separates Project resource management and Analysis execution at top-level IA.
- Existing domain semantics are preserved unless this contract explicitly says otherwise.
- G01 establishes Project Management; G02 establishes the replacement Analysis Workspace and functional surface migration.
- Browser history/direct-link are product semantics.
- package completion is not Gate PASS.

## 3. Execution Mode

Selected: `WORK_PACKAGE`.

P00 is Human/operator orchestration traceability. Work Package Coding Agents do not read P00 to complete package specifications.

## 4. Required implementation semantics

- AC-G01-01: `/projects` is the canonical Project List surface.
- AC-G01-02: `/projects/new` is the canonical Project Register surface.
- AC-G01-03: Successful Project creation transitions to `/projects/<id>/overview`.
- AC-G01-04: `/projects/<id>` normalizes to `/projects/<id>/overview` without duplicate history entry.
- AC-G01-05: Overview / Research Context / Data / Results local navigation works and URL reflects the active section.
- AC-G01-06: Project metadata and Dataset/Analysis View lifecycle management are separate responsibilities.
- AC-G01-07: Project Archive belongs to selected Project / Overview.
- AC-G01-08: Analysis View lifecycle management belongs to Data.
- AC-G01-09: Analysis View remains a Family-crossing analysis input rather than an Exploratory-only object.
- AC-G01-10: Results / Lineage retains existing cross-analysis functions.
- AC-G01-11: Direct link, reload, Back and Forward work for Project routes.
- AC-G01-12: Existing Project/domain semantics and protected ENH-E6 Analysis semantics do not regress.

## 5. Allowed scope

- frontend routing / navigation / DOM / styles / presentation/state code required by this Gate.
- focused automated tests and repository-standard browser E2E needed by frozen 07.
- source discovery necessary to locate existing responsibilities.
- minimal refactoring strictly required to establish the specified ownership without changing domain semantics.

## 6. Explicitly prohibited scope

- new backend analysis semantics solely to fit UI taxonomy.
- persistence/schema redesign.
- unrelated framework migration or design-system rewrite.
- changing Acceptance Criteria to fit implementation.
- next-Gate implementation before its entry criteria.
- bypassing protected upstream contracts.

## 7. Protected passed-Gate contracts

| Gate | Protected semantic | Allowed interaction | Mandatory regression |
|---|---|---|---|
| ENH-E6 G01 | ENH-E6 G01 PASS candidate 575cdd139aea09d4f19b46ab6a6d38545f645c71: canonical Analysis Family/Stage navigation and Analysis transition semantics. | presentation/routing integration only | frozen 07 protected-regression Test Item |

## 8. Transition Debt

| TD ID | Required action | Exit criterion |
|---|---|---|
| NONE | NONE | No intentional temporary product debt is introduced by this draft. Legacy URL compatibility is a requirement, not temporary debt. |

## 9. Schema / migration / API / runtime policy

```text
Persistence migration: NONE EXPECTED
API contract change: NONE EXPECTED
Backend domain semantic change: NOT AUTHORIZED
```

If source inspection proves an already-required behavior cannot be implemented without one of these changes, the affected package must stop as `PACKAGE_BLOCKED_CONTRACT_CHANGE_REQUIRED`.

## 10. Automated test obligations

- 002: project_route_contract (FRONTEND_CONTRACT)
- 003: project_surface_ownership (FRONTEND_CONTRACT)
- 004: project_domain_regression (API_INTEGRATION/UNIT_DOMAIN)
- 005: project_browser_journey (BROWSER_E2E)
- 006: protected_analysis_regression (FRONTEND_CONTRACT)

Detailed correctness should be tested at the lowest deterministic layer. Browser E2E is limited to critical cross-layer journeys defined in 07.

## 11. Candidate Assembly requirement

Before `READY_FOR_TEST`:

- all required Pxx are `PACKAGE_COMPLETE`.
- Gate-wide integration self-check passes.
- protected regression self-check passes.
- unresolved candidate-affecting changes are NONE.
- Fixed Trial Candidate full SHA is fixed.
- Implementation Completion Report is created.

## 12. Coding-side prohibited work

- Gate PASS/FAIL decision.
- 07 modification to avoid a failure.
- Acceptance Criteria modification.
- unapproved passed-Gate semantic change.
- package-scope convenience changes unrelated to this Gate.

## 13. Required outputs

Per package:

- package execution status report.
- implementation checkpoint report.
- checkpoint full SHA.

At Candidate Assembly:

- Fixed Trial Candidate full SHA.
- implementation completion report.
- Gate-local implementation detail report.

## 14. External reference policy

Gate 06 is Human/operator traceability and semantic authority. Work Package Coding Agents receive a self-contained Pxx and must not read this 06 to complete package specification.

Source/tests/runtime and previous PASS evidence may be inspected as factual implementation substrate.

## 15. Stop condition

Coding side stops at `READY_FOR_TEST` or explicit `BLOCKED_*`. It does not declare Gate PASS.
