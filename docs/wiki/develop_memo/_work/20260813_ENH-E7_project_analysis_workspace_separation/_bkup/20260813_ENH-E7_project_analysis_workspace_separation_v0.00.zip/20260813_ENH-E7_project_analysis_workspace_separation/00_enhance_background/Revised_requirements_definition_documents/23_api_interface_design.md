# API Interface Design — ENH-E7 delta

## Decision

No API-interface change is expected or authorized at planning time.

Existing Project, Context, Dataset, Analysis View, Results and Analysis-navigation APIs must be reused where sufficient.

If current APIs cannot express a required already-existing domain operation, the implementing package must stop with a contract/blocker report. UI convenience alone is not sufficient justification for an API change.
