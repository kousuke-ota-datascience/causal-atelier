# ENH-E7 G02 P02 — Project <-> Analysis Routing

**Document class:** Primary Execution Contract  
**Self-containment:** MUST  
**Gate:** G02  
**Trial at first issuance:** 01  
**Package:** P02  
**Depends on:** P01  
**Status at issuance:** DRAFT_NOT_FROZEN

## 1. Purpose

Connect Project Management, Analysis Workspace and Results/Lineage using canonical routes.

## 2. Effective Gate constraints applicable to this package

- Project Management and Analysis Workspace are different navigation scopes.
- Existing domain/execution semantics are protected.
- ENH-E6 Analysis canonical-route / Family / Stage semantics must not regress.
- package completion is not Gate PASS.
- this document is the Coding Agent's normative workflow implementation contract.
- parent 06 / 07 / P00 / other Pxx are traceability only and MUST NOT be read to fill missing package requirements.
- source, tests, config and migration files may be inspected as implementation substrate.
- if this package requires a backend/API/persistence semantic change not explicitly authorized below, stop.

## 3. In scope

- Open Analysis Workspace
- return to Project Management
- Analysis -> Results/Lineage
- existing canonical Analysis route
- catalog-authoritative default Stage

## 4. Explicitly out of scope

- Do not duplicate default-stage mappings in frontend.
- Do not replace existing Analysis transition authority without approved amendment.

Also out of scope:

- Acceptance Criteria changes.
- unrelated cleanup/refactoring.
- next package implementation.
- workflow artifact changes outside required package reports.

## 5. Entry criteria / required evidence

- current checkout is on `feature/ariadne_mvp_e7`.
- local Agent Execution Readiness for `G02/P02/Trial01` is PASS.
- dependency requirement is satisfied: `P01`.
- Architecture Review and Gate contracts are FROZEN before execution.
- no unresolved source fact makes the listed in-scope behavior ambiguous.

If any entry criterion cannot be verified, stop as `PACKAGE_BLOCKED`.

## 6. Required implementation

1. Inspect the current source/tests only as needed to locate the responsibilities listed in §3.
2. Implement the ownership/behavior defined in §3 while preserving §2/§4 constraints.
3. Add or update focused automated tests using repository conventions.
4. Do not create substitute backend semantics to make the UI appear complete.
5. Record any source fact that contradicts this contract; stop rather than silently reinterpret the contract.

## 7. Focused verification

| Check | Command / method | Required result |
|---|---|---|
| focused product test | `uv run pytest -q tests/product/test_enh_e7_g02_p02_project_analysis_routing.py` | PASS after the package creates/updates the focused test |
| existing nearby regressions | run repository tests covering touched responsibility | PASS |
| static/source audit | inspect diff and ownership/navigation references | no out-of-scope semantic change |

If the repository's established test naming/layout makes the proposed focused path inappropriate, the Coding Agent may use the repository-standard equivalent, but must report the exact command and coverage.

## 8. Protected contract constraints

- Protected upstream: G01 final PASS contract plus ENH-E6 Analysis canonical route / Family / Stage navigation semantics.
- No open Transition Debt is intentionally introduced by this package.
- Legacy URL compatibility must not be removed in G01; in G02 it may be normalized but not deleted.

## 9. Checkpoint / reporting rule

On package completion:

1. commit implementation-affecting changes.
2. fix the implementation checkpoint full SHA.
3. create an implementation checkpoint report.
4. create/update the package execution status report.
5. distinguish any report-only commit SHA from the implementation checkpoint SHA.

## 10. Package completion criteria

Cross-surface routing contract tests pass.

Additionally:

- all §7 focused verification is complete.
- no unresolved package blocker remains.
- checkpoint full SHA is fixed.
- reports are written.

## 11. External reference policy

The Coding Agent may inspect source/test/runtime facts. It must not read Gate 06 / Gate 07 / P00 / other Pxx / 00 / 20 / 30 workflow artifacts to complete the package specification.

If this Pxx itself is insufficient or contradicts verified source facts, stop as `PACKAGE_BLOCKED_CONTRACT_AMBIGUITY`.

## 12. Stop rule

- scope complete -> `PACKAGE_COMPLETE`
- cannot continue safely -> `PACKAGE_BLOCKED`
- never declare Gate PASS/FAIL
- never continue automatically into another package
