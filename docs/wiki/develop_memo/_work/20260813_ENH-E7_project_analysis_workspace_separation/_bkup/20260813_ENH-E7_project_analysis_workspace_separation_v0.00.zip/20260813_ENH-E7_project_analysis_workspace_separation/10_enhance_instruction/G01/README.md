# ENH-E7 G01 — Project Management Surface Contract

**Status:** DRAFT_NOT_FROZEN  
**Execution Mode:** WORK_PACKAGE

## Gate claim

Project creation, selection and management become an independent URL-authoritative Project Management surface, and downstream work may rely on Project routes, section ownership and analysis-input resource ownership.

## Package order

- P01 — Project Navigation Authority — depends on NONE
- P02 — Projects / New Project Surface — depends on P01
- P03 — Overview / Project Lifecycle — depends on P01,P02
- P04 — Research Context Surface — depends on P01,P03
- P05 — Data / Analysis View Surface — depends on P01,P03
- P06 — Results / Lineage Surface — depends on P01,P03
- P07 — Project Integration / Regression — depends on P02,P03,P04,P05,P06

## Active-contract rule

- 06/07 become authoritative only after Human/operator changes status to FROZEN following Architecture Review.
- Pxx becomes executable only if its dependency state and preflight are PASS.
- 08 is inactive until a formal FAIL.
- 09 is inactive unless a semantic Gate contract amendment is explicitly approved.
