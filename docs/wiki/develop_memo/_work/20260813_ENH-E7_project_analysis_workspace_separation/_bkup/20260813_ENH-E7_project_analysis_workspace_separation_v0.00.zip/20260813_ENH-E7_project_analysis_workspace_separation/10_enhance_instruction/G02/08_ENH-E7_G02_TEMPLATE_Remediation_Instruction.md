# ENH-E7 G02 Remediation Instruction — TEMPLATE ONLY

**Status:** TEMPLATE_ONLY_DO_NOT_EXECUTE

Create a concrete 08 only after Independent Verification issues a formal FAIL.

A remediation contract must:

- identify the failed Trial and evidence.
- preserve original 06/07 Acceptance semantics.
- choose DELTA or CONSOLIDATED mode.
- define failure-specific implementation scope.
- define re-verification requirements.
- never redefine a mistaken Gate semantic claim; use a 09 amendment for that.
