# ENH-E5 次版改訂サマリ

## 1. 改訂の結論

本版は、レビューで指摘された「文書構造の抽象度不整合」「ENH-E5差分資料化」「ENH-E4設計体系からの逸脱」「Execution Agentへの不要な仕様探索余地」を是正した次版ドラフトである。

主要な方針は次のとおり。

1. Revised requirements/design documentsは、ENH-E4までの章構成・記載粒度をcanonical baselineとして再構成する。
2. ENH-E5固有概念を文書のトップレベルへ突出させず、既存責務体系の適切なsectionへ配置する。
3. Product Concept本文は現在のプロダクト像から開始し、Enhancement履歴は後段へ分離する。
4. `Navigation Stage != Execution Stage`を、具体的な問題シチュエーションと依存方向まで含めて要件・基本設計・詳細設計・Gate ACへ落とす。
5. G00〜G05のExecution Agentは単一normative contractだけを使用する。

## 2. 文書構造の改訂

### 2.1 Product Concept

- 冒頭を`ENH-E5は...`で開始しない。
- Familyタブの表示方法やNavigation/Executionの具体的問題例をmajor chapterへ置かない。
- `Analytical Families`の下にExploratory / Causal / Predictiveを束ねる。
- external analytical engineは「今後の拡張予定」配下へ置く。
- Change scope / historyは本文後段またはCHANGE LOGへ分離する。

### 2.2 Requirements

ENH-E4までの構成を踏襲し、ENH-E4時点のFR-001〜FR-128 / NFR-001〜NFR-020 / AR-001〜AR-020を削らずcurrent effective requirementsとして保持した。その上でENH-E5要件をFR-129〜FR-162 / NFR-021〜NFR-027 / AR-021〜AR-026として追加・整理する。

構成:

```text
0 INTRODUCTION
1 適用範囲
2 Actor
3 業務Capability
4 E2Eシナリオ
5 機能要件
6 非機能要件
7 科学・統計・分析上の要件
8 状態要件
9 権限要件
10 データ保持・監査要件
11 対象外要件
12 総合完了条件
13 CHANGE LOG
```

`Requirement levels`はLegends配下へ置く。

### 2.3 Logical Data Design

```text
1 設計目的
2 基本原則
3 論理モデルの構成要素
  3.1 Domain Resource
  3.2 Domain Resource外の論理概念
  3.3 論理概念の分類原則
4 Domain Resource関係モデル
5 Domain Resource定義
6 Canonicalization
7 Index / Unique Constraint
8 Schema Reader Contract
20 CHANGE LOG
```

current sourceとの照合により、`AnalysisSpecification.analysis_family`が既に存在することを確認した。duplicate Family discriminatorは追加しない。Navigation StageはAnalysisSpecification / ExecutionPlan / Execution / StageExecutionへ保存しない。

### 2.4 Product Basic Design

ENH-E4の全体設計taxonomyへ戻した。

- System Context
- Architecture Principle
- Project Workspace Information Architecture
- Generic Workflow Core
- Family別Workflow / Capability
- Validation Architecture
- Result / Artifact / Lineage
- Comparison
- Frontend State
- Security / Deployment / Failure / Schema Boundary / Test

Family tab / Stage sidebarはWorkspace IAのsubsection、Navigation/Execution分離はGeneric Workflow Coreのsubsectionとして記載する。

### 2.5 API / Interface Design

ENH-E4のresource/interface taxonomyを維持し、Navigation metadataは`Frontend Support API`配下へ配置した。

`GET /api/v1/navigation/analysis`はtarget candidateであり、Human Architecture Review前の確定事項ではない。

Analysis Specification / Execution / Worker / CLI APIへNavigation Stageを必須入力として追加しない。

### 2.6 Detailed Design

ENH-E4のPackage / Value Object / Schema / Planner / Executor / Capability / Result / Frontend / Persistence / Test構造をbaselineとし、Navigation descriptor/catalog/route/UI実装を適切な既存sectionへ統合した。

## 3. Architecture上の重要な照合結果

current codeでは次を確認した。

- `AnalysisFamily = EXPLORATORY | CAUSAL | PREDICTIVE`が存在する。
- `AnalysisSpecification.analysis_family`が存在する。
- `ExecutionPlan.analysis_family`および`Execution.analysis_family`が存在する。
- runtime側には`StageType / StageDefinition / StageExecution`があり、navigation viewとは別のlifecycle semanticsを持つ。

したがって、Navigation model導入で新しいFamily discriminatorやruntime Navigation Stage fieldを追加する必要はない。

## 4. Execution Agent isolation

Execution contractの参照範囲だけでなく、内容密度も見直した。G01〜G04のP01〜P03は、汎用template文ではなく、担当Package固有のrequired behavior / prohibited scope / focused verification / Package Acceptance Checklistを本文へ収束した。

- SINGLE_EXECUTION Coding Agent: 対象Gateの06のみ。
- WORK_PACKAGE Coding Agent: assigned Pxxのみ。
- Test / Audit Agent: 対象Gateの07のみ。
- P00はOperator / Planning用でありPackage Agentの入力ではない。
- repositoryはimplementation fact/evidenceを得るために読んでよいがspec authorityではない。
- ambiguityは`BLOCKED_CONTRACT_AMBIGUITY`で停止する。

> Repositoryから実装方法を発見してよい。Repositoryや上流資料から仕様を発見してはならない。

## 5. Review feedbackへの追加対応

- 全Revised documentでheading hierarchyを再点検し、個別UI論点を不適切なトップレベルchapterへ置かない。
- `AnalysisSpecification.analysis_family`をcurrent sourceと照合し、duplicate Family discriminatorを禁止した。
- Navigation StageをAnalysisSpecification / ExecutionPlan / Execution / StageExecutionへ保存しない。
- G00のsingle 06/07だけでcatalog実装・検証できるよう、DRAFT targetのFamily order / Stage ID / slug / default / descriptor / read-interface contractを本文へ明示した。これらはHuman approval後に一意のFROZEN値へ確定する。
- PxxからParent 06/P00の参照metadataを除き、assigned Pxx単体で実行する境界をさらに強めた。

## 6. 状態

本bundleは`DRAFT_FOR_REVIEW`である。Architecture Review、preflight、exact route/API decision、baseline testを完了するまではGate contractを`FROZEN`にしない。
