# 21 論理データ設計

- 文書状態: `DRAFT_FOR_REVIEW`
- 文書種別: 現行論理データモデルのeffective snapshot
- 上位文書: `10_requirements_definition.md`
- current code照合対象: `src/ariadne/product/domain/`

## 1. 設計目的

本書は、Research Topic、Research Context、Dataset、三つのAnalysis Family、Workflow、ResultおよびLineageを、実装技術に依存しない論理Resourceとして定義する。

論理Resource、Domain Entity、DB Table、API Resource、UI画面は一対一である必要はない。ただし、正本の識別子、version、状態、参照制約および不変性は全層で一致させる。

本書では、persistent Domain Resourceと、Domain Resourceではないapplication/navigation上の論理概念を明確に区別する。Family / Navigation Stage導入に際して、UI上の分類を理由に既存Domain Resourceへ不要なfield/resourceを追加しない。

## 2. 基本原則

1. すべての主要Resourceは一つのProjectに所属する
2. Dataset Version、固定済みContext、固定済みView、固定済みSpecification、Plan、Resultは上書きしない
3. 実行条件は参照IDだけでなくcanonical snapshotとhashを保持する
4. Analysis Family固有payloadは共通Envelopeとversioned Schemaに分離する
5. Lineageは推測ではなく、Command受付・Result作成時に保存する
6. JSONへ外部library object、NaN、Infinity、非決定的表現を保存しない
7. ResultとArtifactを分離する
8. Technical statusとanalytical statusを分離する

9. `AnalysisFamily`は既存domain enum/discriminatorを再利用する。
10. `NavigationStageDescriptor`とCurrent Navigation Stateはpersistent Domain Resourceへ人工的に昇格させない。
11. Navigation Stageを`AnalysisSpecification`、`ExecutionPlan`、`Execution`、`StageExecution`へ追加しない。
12. Navigation Stageとruntime `StageType / StageDefinition / StageExecution`を別概念として扱う。

## 3. 論理モデルの構成要素

### 3.1 Domain Resource

| Resource | Mutability | Primary ID | 責務 |
| --- | --- | --- | --- |
| Project | Mutable aggregate | project_id | Research Topic、status、権限境界 |
| ResearchContextVersion | Immutable after FIXED | research_context_version_id | 問題、問い、仮説、意思決定文脈 |
| DatasetVersion | Immutable | dataset_version_id | 入力データ、schema、hash、profile |
| AnalysisView | Versioned | analysis_view_id | 行・列・加工・時間条件 |
| AnalysisSpecification | Versioned | analysis_specification_id | Family固有の問い・方法・評価基準 |
| ExecutionPlan | Immutable | execution_plan_id | Stage DAG、binding、version |
| Execution | Stateful | execution_id | Planの実行単位、snapshot、status |
| StageExecution | Stateful | stage_execution_id | Stage単位のstatusとattempt |
| Result | Immutable | result_id | Family / Type固有の論理結果 |
| Artifact | Immutable metadata | artifact_id | 物理生成物のdescriptorとhash |
| GraphVersion | Versioned | graph_version_id | Graph semantics、origin、nodes、edges |
| Annotation | Mutable with history | annotation_id | 判断理由、仮定、限界、次Action |
| LineageEdge | Append-only | lineage_edge_id | Resource間の明示的関係 |

### 3.2 Domain Resource外の論理概念

| Concept | 種別 | 永続化 | 責務 |
| --- | --- | --- | --- |
| `AnalysisFamily` | Enum / domain discriminator | Resourceとしては不要 | Exploratory / Causal / Predictiveの分析Family識別 |
| `StageType` | runtime value object | ExecutionPlan / StageExecutionの構成要素 | runtime Stage種別をnamespace / name / versionで識別 |
| `StageDefinition` | runtime value object | ExecutionPlan内 | runtime Stageのinput/output/parameter/resource policyを定義 |
| `StageBinding` | runtime value object | ExecutionPlan内 | runtime Stage間dependency / bindingを定義 |
| `NavigationStageDescriptor` | application metadata / immutable value | DB永続化しない | Family-local Stage ID、label、order等 |
| `FamilyNavigationDescriptor` | application metadata / immutable value | DB永続化しない | FamilyとStage catalog、default Stageの組 |
| Current Family | navigation state | DB永続化しない | 現在のglobal analytical context |
| Current Navigation Stage | navigation state | DB永続化しない | 現在のFamily-local work/view context |
| route representation | serialized navigation state | URL/history | Project / Family / Stageのdeep-link表現 |
| renderer binding | presentation mapping | code/config | `(family, stage)`から既存surface / use caseへのbinding |

#### 3.2.1 AnalysisFamilyの既存Domain Resourceとの関係

current sourceでは`AnalysisSpecification.analysis_family: AnalysisFamily`が既に存在し、Familyに応じてfamily-specific schemaを検証する。`ExecutionPlan`および`Execution`も`analysis_family`を保持する。したがってFamily discriminatorを重複field/enumとして追加しない。

#### 3.2.2 Navigation Stageの位置づけ

Navigation StageはAnalysis Specificationのsemantic inputでもruntime lifecycle fieldでもない。次のようなfieldを追加しない。

```text
AnalysisSpecification.navigation_stage
ExecutionPlan.navigation_stage
Execution.current_navigation_stage
StageExecution.navigation_stage
```

### 3.3 論理概念の分類原則

- 新規概念はまず既存Domain Resourceの属性・関係として自然に表現可能か確認する。
- 独立identity / lifecycle / mutabilityを持つ場合のみ新規Domain Resource候補とする。
- enum / value / descriptor / navigation stateを人工的にDomain Resourceへ昇格させない。
- runtime entityとnavigation metadataを同一型へ統合しない。
- UI表示分類だけを理由にDB schemaを追加しない。

## 4. Domain Resource関係モデル

```text
Project
├── ResearchContextVersion
├── DatasetVersion
│   └── AnalysisView
├── AnalysisSpecification
│   ├── EXPLORATORY
│   ├── CAUSAL
│   └── PREDICTIVE
├── GraphVersion
├── ExecutionPlan
│   └── Execution
│       └── StageExecution
│           ├── Result
│           └── Artifact
├── Annotation
└── LineageEdge
```

主要参照:

```text
AnalysisSpecification → ResearchContextVersion
AnalysisSpecification → DatasetVersion or AnalysisView
ExecutionPlan → AnalysisSpecification
Execution → ExecutionPlan + frozen snapshots
StageExecution → Execution + Stage definition
Result → exactly one canonical Execution; StageResult additionally requires exactly one StageExecution belonging to that Execution
Artifact → one canonical Product metadata ownership authority; optional execution/stage/result association follows the approved workflow contract
Causal AnalysisSpecification → GraphVersion（operationに応じて）
LineageEdge → 任意の同一Project Resource pair
```

### 4.1 AnalysisFamily relation

`AnalysisFamily`はResourceではないが、既存Resourceのdiscriminatorとして現れる。

```text
AnalysisFamily
  ├─ AnalysisSpecification.analysis_family
  ├─ ExecutionPlan.analysis_family
  └─ Execution.analysis_family
```

### 4.2 Supporting Logical Concept relation

Persistent Resource relationとは分離して、navigation側は次の論理関係として扱う。

```text
AnalysisFamily
   │
   ▼
FamilyNavigationDescriptor
   │
   └─ NavigationStageDescriptor*
            │
            └─ presentation / use-case binding
```

この関係をER的なpersistent relationへ変換しない。

## 5. Domain Resource定義

### 5.1 Project

| Field | Type | Required | 制約 |
| --- | --- | --- | --- |
| project_id | UUID | 1 | 不変 |
| name | string(200) | 1 | Project内表示名 |
| topic | string(4000) | 1 | Research Topic |
| objective | string(4000) | 1 | 意思決定または分析目的 |
| decision_context_json | object | 0 | 利用主体、選択肢、期限等 |
| memo | text | 0 | 補足 |
| status | ACTIVE / ARCHIVED | 1 | 新規操作gate |
| created_by / created_at | actor / datetime | 1 | 監査 |
| updated_by / updated_at | actor / datetime | 1 | 監査 |

Project archiveは論理削除であり、子ResourceのLineageを保持する。

### 5.2 ResearchContextVersion

#### 5.2.1 Field

| Field | Type | Required | 説明 |
| --- | --- | --- | --- |
| research_context_version_id | UUID | 1 | Version ID |
| project_id | UUID | 1 | 所属Project |
| context_key | string | 1 | 同一Context系列 |
| version_number | integer | 1 | Project / context_key内で単調増加 |
| status | DRAFT / FIXED | 1 | FIXED後不変 |
| problem_statement | text | 1 | 解決対象 |
| research_questions_json | array | 1 | 一つ以上の問い |
| significance | text | 0 | 重要性 |
| hypotheses_json | array | 0 | 仮説 |
| decision_context_json | object | 0 | 意思決定用途 |
| relation_json | array | 0 | 他Context Versionとの関係 |
| canonical_hash | sha256 | 1 | FIXED時に生成 |

#### 5.2.2 Relation

許可relation:

- `REFINES`
- `DERIVED_FROM`
- `SUPERSEDES`
- `RELATED_TO`

relationは同一Project内のみ許可する。cycleを禁止するrelationと許可するrelationをSchemaで区別する。

### 5.3 DatasetVersion

| Field | Type | Required | 説明 |
| --- | --- | --- | --- |
| dataset_version_id | UUID | 1 | 不変ID |
| project_id | UUID | 1 | 所属Project |
| dataset_key | string | 1 | Dataset系列 |
| version_label | string | 1 | 利用者label |
| content_hash | sha256 | 1 | raw bytesまたはcanonical data hash |
| schema_json | object | 1 | 列名、logical type、nullable等 |
| profile_json | object | 1 | 行列数、欠損、cardinality等 |
| artifact_id | UUID | 1 | 物理データArtifact |
| source_note | text | 0 | 出所 |
| created_by / created_at | actor / datetime | 1 | 監査 |

同一Project、dataset_key、content_hashの重複登録はidempotentに扱える。

### 5.4 AnalysisView

#### 5.4.1 Envelope

```json
{
  "schema_version": "analysis-view/1",
  "source_dataset_version_id": "uuid",
  "row_filter": [],
  "selected_columns": [],
  "derived_columns": [],
  "missing_value_policy": {},
  "time_cutoff": null,
  "sampling": null
}
```

#### 5.4.2 制約

- filter operatorとvalue typeをcolumn logical typeへ整合させる
- selected columnとderived expressionの参照列が存在する
- derived column名が重複しない
- 非決定的関数、外部I/O、任意コードを禁止する
- time cutoffは予測時点・因果time zeroと独立に保存し、Specification側で意味付けする
- 固定時にcanonical JSONとhashを生成する

### 5.5 AnalysisSpecification

#### 5.5.1 共通Envelope

```json
{
  "schema_version": "analysis-specification/1",
  "analysis_family": "EXPLORATORY | CAUSAL | PREDICTIVE",
  "research_context_version_id": "uuid",
  "dataset_version_id": "uuid",
  "analysis_view_id": "uuid-or-null",
  "analysis_mode": "EXPLORATORY | CONFIRMATORY",
  "family_spec_schema_version": "...",
  "family_spec": {},
  "revision_context": null,
  "warnings": []
}
```

共通Envelopeの固定後、family_specを上書きしない。

#### 5.5.2 Exploratory Schema

`exploratory-analysis-spec/1`:

- operation: `PROFILE | DISTRIBUTION | ASSOCIATION | GROUP_SUMMARY | TIME_TREND | CHART`
- columns
- grouping
- aggregation
- chart encoding
- filter / sampling reference
- expected output type

#### 5.5.3 Causal Schema

`causal-analysis-spec/2`を正規Schemaとする。必須構造:

- analysis_mode
- research_context
- causal_question
- causal_design
- operation_spec
- validation_override
- optional revision_context
- optional scientific_warnings

Operationは`DISCOVERY | IDENTIFICATION | ESTIMATION | REFUTATION | SENSITIVITY`である。未知Fieldをrejectする。

#### 5.5.4 Predictive Schema

`predictive-analysis-spec/1`:

- task_type: `BINARY_CLASSIFICATION | REGRESSION`
- prediction_question
  - prediction_unit
  - target
  - prediction_time
  - horizon
  - intended_use
  - deployment_population
- feature_spec
  - feature_columns
  - availability_cutoff
  - excluded_columns
- split_spec
  - strategy
  - train / validation / test ratioまたはcutoff
  - group_column
  - stratify
  - seed
- preprocessing_spec
- model_spec
- tuning_spec
- evaluation_spec
- explanation_spec

#### 5.5.5 Family discriminator / Navigation境界

- `analysis_family`は既存fieldを再利用する。duplicate Family discriminatorを追加しない。
- Navigation StageはAnalysis Specificationの問い・方法・評価基準ではないためfieldへ追加しない。

### 5.6 ExecutionPlan

| Field | Type | Required | 説明 |
| --- | --- | --- | --- |
| execution_plan_id | UUID | 1 | 不変ID |
| project_id | UUID | 1 | 所属Project |
| analysis_specification_id | UUID | 1 | 入力Specification |
| analysis_family | enum | 1 | Family |
| plan_schema_version | string | 1 | `execution-plan/1` |
| planner_id / planner_version | string | 1 | 生成Planner |
| stages_json | array | 1 | Stage定義 |
| dependencies_json | array | 1 | DAG edgeとbinding |
| plan_hash | sha256 | 1 | canonical hash |
| created_at | datetime | 1 | 生成時刻 |

#### 5.6.1 Runtime StageDefinition / StageType

Stage定義:

```json
{
  "stage_key": "train",
  "stage_type": {"namespace":"predictive","name":"train","version":"1"},
  "input_contract": {},
  "output_contract": {},
  "parameters": {},
  "resource_policy": {},
  "enabled": true
}
```

NavigationStageDescriptor、Current Family、Current Navigation Stage、browser routeをExecutionPlanへ含めない。

### 5.7 Execution

| Field | 説明 |
| --- | --- |
| execution_id | 実行ID |
| execution_plan_id | Plan参照 |
| project_id | 所属Project |
| analysis_family | Family |
| snapshot_json / snapshot_hash | Context、Dataset、View、Spec、Plan、runtimeの固定値 |
| status | QUEUED / RUNNING / SUCCEEDED / FAILED / CANCELLED |
| retry_count | technical retry回数 |
| requested_by / timestamps | 監査 |
| base_execution_id | RERUN / REVISEDの起点 |
| revision_kind / changed_dimensions / change_reason | 改訂情報 |

Current Navigation Stageを保持しない。

### 5.8 StageExecution

| Field | 説明 |
| --- | --- |
| stage_execution_id | Stage実行ID |
| execution_id | 親Execution |
| stage_key / stage_type | Plan上のStage識別 |
| ordinal | 表示用順序。依存判定はDAGを正本とする |
| status | PENDING / READY / RUNNING / SUCCEEDED / FAILED / SKIPPED_DUE_TO_PREREQUISITE |
| attempt_count | Attempt回数 |
| input_binding_json | 解決済み入力 |
| output_binding_json | 生成output |
| last_error_json | 技術error |
| timestamps | 開始・終了 |

Attemptを独立TableにするかJSON履歴にするかは物理設計で選択できるが、履歴を失ってはならない。

NavigationStageDescriptorまたはbrowser routeをStageExecutionへ保持しない。

### 5.9 Result

#### 5.9.1 共通Envelope

```json
{
  "result_id": "uuid",
  "project_id": "uuid",
  "execution_id": "uuid",
  "stage_execution_id": "uuid",
  "analysis_family": "CAUSAL",
  "result_type": "TREATMENT_EFFECT_RESULT",
  "schema_version": "causal-treatment-effect-result/1",
  "analytical_status": "ESTIMATED",
  "summary": {},
  "payload": {},
  "diagnostics": {},
  "warnings": [],
  "created_at": "datetime"
}
```

#### 5.9.2 Family別Result Type

| Family | Result Type |
| --- | --- |
| EXPLORATORY | DATA_PROFILE_RESULT、DISTRIBUTION_RESULT、ASSOCIATION_RESULT、GROUP_SUMMARY_RESULT、CHART_RESULT |
| CAUSAL | DISCOVERY_GRAPH_RESULT、IDENTIFICATION_RESULT、DATA_ELIGIBILITY_RESULT、TREATMENT_EFFECT_RESULT、DIAGNOSTICS_RESULT、REFUTATION_RESULT、SENSITIVITY_RESULT |
| PREDICTIVE | SPLIT_RESULT、TRAINING_RESULT、EVALUATION_RESULT、ERROR_ANALYSIS_RESULT、PREDICTIVE_EXPLANATION_RESULT、MODEL_CARD_RESULT |

Result Typeごとに許可analytical statusをSchemaで定義する。

#### 5.9.3 Causal Result Status

| Result Type | Allowed analytical status |
| --- | --- |
| DISCOVERY_GRAPH_RESULT | GENERATED / GENERATED_WITH_WARNINGS / UNRELIABLE |
| IDENTIFICATION_RESULT | IDENTIFIED / NOT_IDENTIFIED / PARTIALLY_IDENTIFIED / REQUIRES_REVIEW |
| DATA_ELIGIBILITY_RESULT | PASS / WARN / FAIL |
| TREATMENT_EFFECT_RESULT | ESTIMATED / INSUFFICIENT_OVERLAP / INSUFFICIENT_SAMPLE / ESTIMATION_UNRELIABLE / REQUIRES_REVIEW |
| DIAGNOSTICS_RESULT | PASS / WARN / FAIL |
| REFUTATION_RESULT | NO_FAILURE_DETECTED / FAILURE_DETECTED / INCONCLUSIVE |
| SENSITIVITY_RESULT | ROBUST / FRAGILE / INCONCLUSIVE |

#### 5.9.4 Predictive Result Status

| Result Type | Allowed analytical status |
| --- | --- |
| SPLIT_RESULT | PASS / WARN / FAIL |
| TRAINING_RESULT | TRAINED / TRAINED_WITH_WARNINGS / FAILED_VALIDATION |
| EVALUATION_RESULT | EVALUATED / EVALUATED_WITH_WARNINGS / INSUFFICIENT_TEST_SAMPLE |
| ERROR_ANALYSIS_RESULT | GENERATED / GENERATED_WITH_WARNINGS |
| PREDICTIVE_EXPLANATION_RESULT | GENERATED / GENERATED_WITH_WARNINGS / NOT_APPLICABLE |
| MODEL_CARD_RESULT | GENERATED |

#### 5.9.5 Exploratory Result Status

Exploratory Resultは`GENERATED | GENERATED_WITH_WARNINGS | INSUFFICIENT_DATA`を許可する。

#### 5.9.6 Result semantic level and logical ownership

Resultは一つのcanonical Result ownership contractの下に属する。Result semantic levelはExecution-levelまたはStage-levelであり、これらは別のResult architectureではない。

- ExecutionResult: exactly one canonical Executionに属する。Stage ownershipはnot applicableであり、特定StageExecutionをrequired ownerとしない。Execution-level outcomeを表す。
- StageResult: exactly one canonical Executionに属し、exactly one StageExecutionをownerとする。参照StageExecutionは同じcanonical Executionに属さなければならない。特定persistent StageExecutionが生成したstage-level outcomeを表す。
- Execution→StageExecution: one Executionからzero-or-more StageExecution children。canonical workflowのlifecycleではrequired stagesが生成されるが、exact stage countはPlan/Workflow contractで定義する。
- Execution→Result: each Result has exactly one parent Execution。ResultのExecution-level/Stage-level multiplicityはworkflow contractで定義し、未承認の最大数を推測しない。
- StageExecution→StageResult: StageResultはexactly one StageExecution ownerを持つ。StageResultの生成可否・個数はstage contractに従う。
- Result→Artifact: Resultはzero-or-more Artifact metadata referencesを持ち得る。artifact-only outputの許可はfamily contractで明示し、同一physical objectのreuseはmetadata ownershipを複製しない。

physical storage locator、object key、URIはsemantic Result/Artifact identityではない。

+
#### 5.9.7 Relation-level lineage authority allowlist

以下はPhase 06 Lineage Relation Target ClassificationとPhase 04 reconstructability evidenceをmaterializeした正式target contractである。Authorityはsemantic relation単位で一意であり、同じstructural relationをtyped authorityとgeneric authorityへindependently dual-writeしてはならない。

| Semantic Relation | Source | Target | Authority | Generic Edge Allowed | Evidence |
|---|---|---|---|---|---|
| Execution owns Result | Execution | Result | TYPED_STRUCTURAL | NO | Phase 06 relation classification; E4-REQ-015 |
| Result owns Artifact | Result | Artifact | TYPED_STRUCTURAL | NO | Phase 03/06 ownership classification; E4-REQ-018〜020 |
| Dataset/View is Execution input | DatasetVersion / AnalysisView | Execution | TYPED_STRUCTURAL | NO | Phase 04 typed-derived input evidence; E4-REQ-021 |
| Result is Execution input | Result | Execution | TYPED_STRUCTURAL | NO | Phase 06 Result→Execution input classification; E4-REQ-021 |
| Result produces GraphVersion | Result | GraphVersion | TYPED_STRUCTURAL | NO | Phase 04/06 source_result_id classification; E4-REQ-021 |
| Artifact derives DatasetVersion | Artifact | DatasetVersion | TYPED_STRUCTURAL | NO | Phase 04/06 source_artifact_id classification; E4-REQ-021 |
| Execution is rerun/revised from base | Execution | Execution | TYPED_STRUCTURAL | NO | Phase 06 mutation semantics; E4-REQ-008〜009 |
| Artifact stage/process derivation | Artifact | Artifact | GENERIC_ONLY | YES — AUTHORITY | Phase 04/06 no typed equivalent confirmed |
| Result summarizes Result | Result | Result | GENERIC_ONLY | YES — AUTHORITY | Phase 04/06 SUMMARIZES is persisted generic-only |
| Result/Artifact documents or evidences another resource | Result / Artifact | Specification / Dataset / View / related resource | GENERIC_ONLY | YES — AUTHORITY | Phase 04/06 DOCUMENTS / EVIDENCE_FOR classification where no typed structural relation exists |
| User-authored semantic link | approved Product resource | approved Product resource | GENERIC_ONLY | YES — AUTHORITY | Phase 04/06 manual/user-authored relation classification |
| Closure/traversal representation | typed and generic authoritative sources | exported/traversed graph | PROJECTION_ONLY | YES — PROJECTION ONLY | Phase 06 closure/export policy |
| Legacy ArtifactLineage | legacy Artifact | legacy Artifact | OUT_OF_SCOPE | NO Product target write | Phase 05/06 legacy boundary; not Product authority |

Relation names such as USED_INPUT, GENERATED, DERIVED_FROM, and REVISED_FROM are not a universal generic allowlist. They are interpreted through the semantic source/target relation above; the structural meanings are TYPED_STRUCTURAL and cannot be independently written as generic authoritative edges.

### 5.10 Artifact

| Field | 説明 |
| --- | --- |
| artifact_id | UUID |
| project_id | 所属Project |
| execution_id / stage_execution_id / result_id | 所有・参照 |
| family / artifact_type / schema_version | 型Descriptor |
| media_type | MIME |
| storage_uri | Portで解決する内部URI |
| content_hash / size_bytes | 完全性 |
| metadata_json | row count、shape、encoding等 |
| created_at | 生成時刻 |
| deleted_at / deletion_reason | 保持policyによる削除記録 |

Artifact Typeは単一巨大Enumに閉じず、family namespaceとversionを持つdescriptorとする。

### 5.11 GraphVersion

- graph_type: DAG / CPDAG / PAG
- origin: DISCOVERED / CONSTRAINT_ADJUSTED / USER_DEFINED / IMPORTED / USER_EDITED
- status: DRAFT / FIXED
- parent_graph_version_id
- source_result_id
- designated_outcome_node
- graph_document_json
- edit_reason
- canonical_hash

FIXED Graphは不変であり、編集はchild DRAFTを作る。

### 5.12 Annotation

Annotation target:

- Project
- ResearchContextVersion
- AnalysisView
- AnalysisSpecification
- Execution
- Result
- GraphVersion

Field:

- statement
- rationale
- assumptions
- limitations
- decision
- next_actions
- version / update history

### 5.13 LineageEdge

| Field | 説明 |
| --- | --- |
| source_type / source_id | 上流Resource |
| relation_type | USED_INPUT、GENERATED、DERIVED_FROM、REVISED_FROM、SUPPORTED_BY、MOTIVATED、SELECTED、REJECTED等 |
| target_type / target_id | 下流Resource |
| evidence_json | 生成Command、Stage、rule等 |
| created_at / created_by | 監査 |

同一Project外edgeを禁止する。DB foreign keyで表現できる主要参照は通常columnを正本とし、LineageEdgeは横断relationとProjectionを補完する。

## 6. Canonicalization

1. Schema versionを検証する
2. 未知Fieldをrejectする
3. UUID、datetime、Enumを標準文字列へ変換する
4. key順を固定する
5. listの順序が意味を持たないFieldは規定順へsortする
6. NaN、Infinity、外部objectをrejectする
7. JSONをUTF-8、compact separatorでserializeする
8. SHA-256を生成する
9. hash対象FieldをSchemaごとに明示する

Navigation descriptorをAPI/cache向けにcanonicalizeする場合はFamily/Stage ID、order、default等のapplication metadataに限定し、execution status/attempt/runner contractを含めない。Analysis Specification / Execution Plan等のcanonical hashへNavigation Stageやactive tabを混入させない。

## 7. Index / Unique Constraint

- Project: `status`, `updated_at`
- ResearchContextVersion: unique `(project_id, context_key, version_number)`
- DatasetVersion: unique `(project_id, dataset_key, version_label)`、index `content_hash`
- AnalysisView: unique `(project_id, view_key, version_number)`
- AnalysisSpecification: index `(project_id, analysis_family, created_at)`
- Execution: index `(project_id, analysis_family, status, requested_at)`
- StageExecution: unique `(execution_id, stage_key)`
- Result: index `(project_id, analysis_family, result_type, created_at)`
- LineageEdge: unique `(source_type, source_id, relation_type, target_type, target_id)`

- Navigation Stage ID / slugはFamily内で一意でなければならないが、DB unique constraintとして実装することは要求しない。
- Family navigation descriptorはsupported `AnalysisFamily`ごとに一意でなければならない。

## 8. Schema Reader Contract

- すべてのAnalysis Specification、Execution Plan、ResultおよびArtifact Descriptorは`schema_version`を持つ。
- Reader Registryは`resource_type + schema_version`でvalidatorおよびdecoderを解決する。
- `causal-analysis-spec/2`はCAUSAL Analysis Specificationの正規Schemaとして扱う。
- 未対応versionは暗黙変換せず、`UNSUPPORTED_SCHEMA_VERSION`として拒否する。
- 破壊的Schema変更は新versionとして追加し、旧versionのreaderを保持する。
- Version間変換を行う場合は、変換元version、変換先version、converter versionおよび変換warningを記録する。

Navigation metadataにschema versionを持たせる場合、unknown versionをsilent fallbackしない。Execution-domain schema readerへNavigation schemaを統合する必要はない。

## 20. CHANGE LOG

### 20.4. ENH-E4 Canonical Execution Architecture

- Canonical Execution、persistent StageExecution、Result semantic level、Artifact ownership、typed/generic lineage authorityを論理データモデルへ統合した。
- Analysis Specification / Execution Plan / Result / Artifact descriptorのversioned schema reader contractを確立した。

### 20.5. ENH-E5 Family × Navigation Stage Application Architecture

- 既存`AnalysisFamily`をFamily discriminatorとして再利用する。
- Navigation StageをAnalysisSpecification / ExecutionPlan / Execution / StageExecutionへ追加しない。
- Navigation descriptor / navigation stateをDomain Resource外の論理概念として定義する。
- runtime `StageType / StageDefinition`をExecutionPlan内value objectとして維持し、Navigation Stageと同一化しない。
