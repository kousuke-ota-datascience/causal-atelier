# 23 API・インターフェース設計

- 文書状態: `DRAFT_FOR_REVIEW`
- 文書種別: 現行API / interface設計のeffective snapshot
- 上位文書: `10_requirements_definition.md`, `21_logical_data_design.md`, `22_product_basic_design.md`
- API base: `/api/v1`
- 重要事項: analytical navigation metadata interfaceのexact endpoint/path/schemaはArchitecture Review承認前のtarget候補であり、Gate freeze時にcurrent router/API conventionと照合して確定する。

## 1. API原則

1. Resource IDとProject境界を明示する。
2. 作成・実行Commandはidempotencyに対応する。
3. persistent payloadはschema versionを持つ。
4. validation errorはfield pathとcodeを返す。
5. async operationは`202 Accepted`とExecution参照を返す。
6. UI専用の推測値を正本Domain APIへ混入しない。
7. Result payloadとArtifact downloadを分離する。
8. Family固有Schemaを共通Envelopeへ埋め込む。
9. `AnalysisFamily`は既存`AnalysisSpecification.analysis_family`等のdiscriminatorを再利用し、duplicate field/taxonomyを作らない。
10. Navigation Stageはpresentation/application metadataであり、Analysis Specification / Execution APIの必須入力にしない。
11. Navigation Stageとruntime Stageを同一schemaへ統合しない。
12. CLI / libraryのheadless executionはbrowser navigation APIを経由しなくても成立する。

## 2. Authentication / Authorization

Request context:

- `Authorization: Bearer <token>`（production）
- `X-User-Subject`（development only）
- `X-Request-ID`
- `Idempotency-Key`（対象Command）

Project role:

- `VIEWER`
- `ANALYST`
- `OPERATOR`

認可はRouterだけでなくApplication Serviceでも検証する。Navigation metadata readもProject visibility/security modelを迂回しない。

## 3. Common Response

### 3.1 Error

```json
{
  "error": {
    "code": "PREDICTIVE_LEAKAGE_DETECTED",
    "message": "Feature availability violates prediction time.",
    "details": [
      {"path":"feature_spec.feature_columns[3]","code":"FUTURE_FEATURE","value":"post_purchase_flag"}
    ],
    "request_id": "uuid"
  }
}
```

代表status:

- 400 schema / semantic validation
- 401 unauthenticated
- 403 unauthorized
- 404 not found or hidden
- 409 state / idempotency conflict
- 413 size limit
- 422 analytical command invalid
- 429 capacity limit
- 500 unexpected failure

Navigation route/catalog errorとruntime execution failureを同一error codeへ畳み込まない。

### 3.2 Pagination

```text
?limit=50&cursor=<opaque>&sort=-created_at
```

Responseは`items`、`next_cursor`を返す。

### 3.3 Read-only metadata response

Presentation用metadataをAPIで返す場合も、persistent Domain Resource responseとは区別する。

Navigation metadataのtarget schema候補:

```json
{
  "schema_version": "analysis-navigation/1",
  "families": [
    {
      "family": "PREDICTIVE",
      "slug": "predictive",
      "label": "Predictive",
      "default_stage_id": "setup",
      "stages": [
        {"stage_id":"setup","slug":"setup","label":"Setup","order":10},
        {"stage_id":"train","slug":"train","label":"Train","order":20}
      ]
    }
  ]
}
```

このpayloadはnavigation metadataであり、`ExecutionPlan` / `StageDefinition` / `StageExecution` schemaではない。

## 4. Project / Research Context API

| Method | Path | 用途 |
| --- | --- | --- |
| POST | `/projects` | Project作成 |
| GET | `/projects` | Project一覧 |
| GET | `/projects/{project_id}` | Project取得 |
| PATCH | `/projects/{project_id}` | ACTIVE Project更新 |
| DELETE | `/projects/{project_id}` | Project archive |
| POST | `/projects/{project_id}/research-contexts` | Context DRAFT作成 |
| GET | `/projects/{project_id}/research-contexts` | Context一覧 |
| GET | `/projects/{project_id}/research-contexts/{context_id}` | Context取得 |
| PATCH | `/projects/{project_id}/research-contexts/{context_id}` | DRAFT更新 |
| POST | `/projects/{project_id}/research-contexts/{context_id}/fix` | FIXED化 |
| GET | `/projects/{project_id}/research-contexts/{context_id}/usage` | 利用Analysis / Result取得 |

Family切替によってProject / Research Context resource identityを暗黙変更しない。

## 5. Dataset / Analysis View API

| Method | Path | 用途 |
| --- | --- | --- |
| POST | `/projects/{project_id}/dataset-versions` | Dataset登録 |
| GET | `/projects/{project_id}/dataset-versions` | Dataset一覧 |
| GET | `/projects/{project_id}/dataset-versions/{dataset_version_id}` | metadata取得 |
| GET | `/projects/{project_id}/dataset-versions/{dataset_version_id}/preview` | 制限付きpreview |
| GET | `/projects/{project_id}/dataset-versions/{dataset_version_id}/profile` | 保存済みprofile |
| POST | `/projects/{project_id}/analysis-views` | Analysis View DRAFT作成 |
| GET | `/projects/{project_id}/analysis-views` | View一覧 |
| GET | `/projects/{project_id}/analysis-views/{analysis_view_id}` | View取得 |
| PATCH | `/projects/{project_id}/analysis-views/{analysis_view_id}` | DRAFT更新 |
| POST | `/projects/{project_id}/analysis-views/{analysis_view_id}/validate` | View検証 |
| POST | `/projects/{project_id}/analysis-views/{analysis_view_id}/fix` | FIXED化 |

Dataset / Analysis Viewは複数Familyから共有可能なProject-global analytical inputである。

## 6. Analysis Specification API

| Method | Path | 用途 |
| --- | --- | --- |
| POST | `/projects/{project_id}/analysis-specifications` | Family Specification DRAFT作成 |
| GET | `/projects/{project_id}/analysis-specifications` | Family / Context / Datasetで検索 |
| GET | `/projects/{project_id}/analysis-specifications/{spec_id}` | Specification取得 |
| PATCH | `/projects/{project_id}/analysis-specifications/{spec_id}` | DRAFT更新 |
| POST | `/projects/{project_id}/analysis-specifications/{spec_id}/validate` | 共通・Family検証 |
| POST | `/projects/{project_id}/analysis-specifications/{spec_id}/fix` | FIXED化 |
| POST | `/projects/{project_id}/analysis-specifications/{spec_id}/revise` | child DRAFT作成 |

Common envelope:

```json
{
  "schema_version": "analysis-specification/1",
  "analysis_family": "PREDICTIVE",
  "research_context_version_id": "uuid",
  "dataset_version_id": "uuid",
  "analysis_view_id": "uuid-or-null",
  "analysis_mode": "CONFIRMATORY",
  "family_spec_schema_version": "predictive-analysis-spec/1",
  "family_spec": {}
}
```

### 6.1 AnalysisFamilyの扱い

`analysis_family`は既存discriminatorとして維持する。Family × Navigation Stage UI導入のために別の`family` / `current_family` fieldを追加しない。

### 6.2 Navigation Stageを保存しない

次のようなfieldをAnalysis Specificationへ追加しない。

```json
{
  "navigation_stage": "train"
}
```

Navigation StageはAnalysis Specificationの科学・実行semanticではなく、presentation/application contextである。

### 6.3 Predictive compatibility

`predictive-analysis-spec/1`の既存field、default、validation、hidden/generated semanticsを保持する。Stage再配置はSpecification schema simplificationの理由にならない。

## 7. Explore API

| Method | Path | 用途 |
| --- | --- | --- |
| POST | `/projects/{project_id}/exploration/preview` | 小規模同期集計 |
| POST | `/projects/{project_id}/exploration/executions` | 保存・非同期探索 |
| GET | `/projects/{project_id}/exploration/capabilities` | 利用可能chart / aggregation |
| POST | `/projects/{project_id}/exploration/results/{result_id}/create-analysis-draft` | Causal / Predictive draft作成 |

同期previewは保存済みResultではなくrow/time上限を設ける。保存・再現対象は必要に応じてExecutionを作成する。

Navigation `Profile / Data Quality / Distribution / Relationships / Comparison / Findings`の各Stageに対応して新しいexecution endpointを1:1で追加することを要求しない。

## 8. Causal API

### 8.1 Graph

| Method | Path | 用途 |
| --- | --- | --- |
| POST | `/projects/{project_id}/graph-versions` | User-defined / Imported Graph作成 |
| GET | `/projects/{project_id}/graph-candidates` | Discovery ResultとGraph Versionの統合一覧 |
| POST | `/projects/{project_id}/graph-candidate-comparisons` | Graph比較 |
| POST | `/projects/{project_id}/graph-versions/{graph_id}/create-child-draft` | 編集DRAFT作成 |
| PATCH | `/projects/{project_id}/graph-versions/{graph_id}` | DRAFT編集 |
| POST | `/projects/{project_id}/graph-versions/{graph_id}/fix` | FIXED化 |

### 8.2 Scientific Capability

```text
GET /projects/{project_id}/causal/capabilities
```

algorithm、estimator、refutation method、sensitivity dimension、対応typeを返す。

Causal実行は共通Execution APIを利用する。Navigation `Identification` / `Estimation`は科学的責務を分けるが、endpoint taxonomyをUI Stageへ機械的に合わせない。

## 9. Predictive API

```text
GET /projects/{project_id}/predictive/capabilities
```

Response:

- task types
- split strategies
- preprocessing steps
- model registry entries
- metrics
- explanation methods
- compatibility matrix

予測実行は共通Execution APIを使用する。

split preview candidate:

```text
POST /projects/{project_id}/predictive/split-validations
```

これはtrainingを行わずpartition overlap、class distribution、group/time boundaryを検証する。

Navigation `Setup / Train / Predict / Metrics / Explainability / Model Management`ごとに独立execution APIを要求しない。

## 10. Plan / Execution API

| Method | Path | 用途 |
| --- | --- | --- |
| POST | `/projects/{project_id}/execution-plans` | FIXED SpecificationからPlan生成 |
| GET | `/projects/{project_id}/execution-plans/{plan_id}` | Plan取得 |
| POST | `/projects/{project_id}/execution-plans/{plan_id}/validate` | DAG / Runner / contract検証 |
| POST | `/projects/{project_id}/executions` | Planをsubmit |
| GET | `/projects/{project_id}/executions` | Execution一覧 |
| GET | `/projects/{project_id}/executions/{execution_id}` | Execution詳細 |
| GET | `/projects/{project_id}/executions/{execution_id}/stages` | runtime Stage一覧 |
| POST | `/projects/{project_id}/executions/{execution_id}/cancel` | cancel |
| POST | `/projects/{project_id}/executions/{execution_id}/retry` | technical retry |
| POST | `/projects/{project_id}/executions/{execution_id}/rerun` | 同一条件の新Execution |
| POST | `/projects/{project_id}/executions/{execution_id}/revise` | 変更条件prefill / child spec |
| GET | `/projects/{project_id}/executions/{execution_id}/prefill` | 再実行用snapshot |

Submit payloadはExecution Plan等のruntime contractを入力とし、`current_navigation_stage`をrequired fieldにしない。

```json
{
  "execution_plan_id": "uuid",
  "requested_reason": "Compare baseline model",
  "client_context": {"route":"predictive"}
}
```

`client_context`のroute情報が存在する場合もoptional diagnostic/audit metadataであり、Execution成立条件にしない。

### 10.1 runtime Stage APIの意味

`/executions/{execution_id}/stages`が返すStageは`StageExecution`であり、sidebarのNavigation Stageではない。

API response名やschemaで両者を同一conceptとして表現しない。

## 11. Result / Comparison / Lineage API

| Method | Path | 用途 |
| --- | --- | --- |
| GET | `/projects/{project_id}/results` | Result一覧 |
| GET | `/projects/{project_id}/results/{result_id}` | Result詳細 |
| POST | `/projects/{project_id}/comparisons` | 同種Result比較 |
| GET | `/projects/{project_id}/results/summary` | Family横断summary |
| GET | `/projects/{project_id}/results/{result_id}/lineage` | Result起点Lineage |
| GET | `/projects/{project_id}/lineage` | Project Lineage query |
| POST | `/projects/{project_id}/lineage-links` | 明示relation作成 |
| POST | `/projects/{project_id}/exports` | Manifest / bundle生成 |

Family横断summaryは異種metricを同一scoreとしてrankしない。Navigation StageをResult identity/ownership fieldとして必須化しない。

## 12. Annotation / Artifact API

| Method | Path | 用途 |
| --- | --- | --- |
| POST | `/projects/{project_id}/annotations` | Annotation作成 |
| GET | `/projects/{project_id}/annotations` | targetで検索 |
| PATCH | `/projects/{project_id}/annotations/{annotation_id}` | Annotation更新 |
| GET | `/projects/{project_id}/annotations/{annotation_id}/history` | 変更履歴 |
| GET | `/projects/{project_id}/artifacts/{artifact_id}` | Artifact metadata |
| GET | `/projects/{project_id}/artifacts/{artifact_id}/download` | 権限付きdownload |

`Findings` / `Model Management` Navigation Stageのために、既存Result / Annotation / Artifactで表現できる情報を重複Resource/APIとして新設しない。

## 13. Frontend Support API

### 13.1 Operation Availability

```text
GET /projects/{project_id}/operation-availability
```

Query:

- resource_type
- resource_id
- route

Response example:

```json
{
  "operations": {
    "RUN": {"allowed": false, "reason_code": "SPEC_NOT_FIXED", "message": "Fix the specification first."},
    "EDIT": {"allowed": true},
    "EXPORT": {"allowed": true}
  }
}
```

Frontendは表示補助に利用するが、Command時にもBackendが再検証する。

Navigation Stageの存在とoperation availabilityを分離する。Stageを表示できることは、そのStage内の全actionが実行可能であることを意味しない。

### 13.2 Analytical Navigation Metadata

Family / Stage catalogをbackendから供給する場合のtarget endpoint候補:

```http
GET /api/v1/navigation/analysis
```

またはProject contextを必要とする場合はProject-scoped read endpointとする。exact pathはcurrent API conventionとArchitecture Reviewで確定する。

責務:

- supported Family identity
- Family display label / slug
- Family-local Navigation Stage ID / label / slug / order
- default Stage
- metadata schema version

責務外:

- Execution Plan生成
- Runner selection
- StageExecution status
- Analysis Specification mutation
- persistent current navigation state
- Family-specific analytical result

### 13.3 Source of truth

concrete Navigation Stage catalogはCapability側が所有する。Frontendはrenderer bindingを持てるが、label/order/defaultのfull catalogを独自に二重管理しない。

ただし、backend metadata API新設が過剰でありcurrent architecture上static capability descriptorの方が一貫する場合は、Architecture Reviewで代替を採用できる。06 freeze前に一つへ確定する。

## 14. Worker Interface

### 14.1 Claim

Workerはcanonical Executionをclaimし、claim token、worker id、lease expiry等の既存lifecycle contractを維持する。

### 14.2 Runner Contract

```python
class StageRunner(Protocol):
    stage_type: StageType
    def validate(self, context: StageContext) -> ValidationReport: ...
    def run(self, context: StageContext) -> StageRunResult: ...
```

`StageRunner.stage_type`はruntime `StageType`でありNavigation Stage IDではない。

`StageRunResult`:

- analytical results
- artifacts
- output bindings
- warnings
- metrics

### 14.3 Event

existing Execution / Stage event schemaを維持する。Navigation route changeをruntime Stage lifecycle eventへ変換しない。

## 15. CLI

```text
ariadne project list
ariadne context create|fix|show
ariadne dataset register|show
ariadne view create|validate|fix
ariadne analysis create|validate|fix
ariadne plan create|show
ariadne execution submit|status|cancel|retry
ariadne result show|compare|export
```

CLI manifestはWeb APIと同じResource/analysis schemaを利用できる。

### 15.1 Navigation independence

CLI / Python libraryはNavigation metadata endpointを呼ばなくてもAnalysis Specification / Plan / Executionを扱える。

次のようなrequired contractを導入しない。

```text
ariadne execution submit --family predictive --navigation-stage train ...
```

`--family`相当がAnalysis Specification discriminatorとして必要になる場合と、`Navigation Stage`をbrowser contextとして要求する場合を区別する。

## 16. Idempotency

対象:

- Project作成
- Dataset Version登録
- Context / View / Specification固定
- Plan生成
- Execution submit
- Graph Version作成
- Export生成

同一Project、同一Idempotency-Key、同一canonical bodyは同一responseを返す。Navigation metadata readはidempotent readである。

## 17. Contract Versioning

- URL major: `/api/v1`
- Resource payload: `schema_version`
- Family spec: `family_spec_schema_version`
- Result: `schema_version`
- runtime Stage: namespace / name / version
- Event: `event_version`
- Navigation metadata: target schema `analysis-navigation/1`候補

破壊的変更は新versionを追加し、既存reader/compatibility policyを定義する。

Navigation Stage label/order変更とruntime Stage version変更を連動させない。

## 20. CHANGE LOG

### 20.4 ENH-E4 Canonical Execution Interface Contract

user-visible Product analysis submissionをcanonical Executionへ収束し、family/type別に第二persistent lifecycle authorityを作らないinterface contractを継承する。

### 20.5 ENH-E5 Family × Navigation Stage Interface Contract

Presentation supportとしてFamily / Navigation Stage metadata interfaceを追加候補とし、Analysis Specification / Execution / Worker / CLI contractへNavigation Stageを必須入力として侵入させない。exact navigation metadata endpointはArchitecture Review承認後にfreezeする。
