# 22 プロダクト基本設計

- 文書状態: `DRAFT_FOR_REVIEW`
- 文書種別: 現行プロダクト基本設計のeffective snapshot
- 上位文書: `00_product_concept_memo.md`, `10_requirements_definition.md`, `21_logical_data_design.md`
- 下位文書: `23_api_interface_design.md`, `30_detailed_design.md`

## 1. 設計目的

本書は、AriadneのProduct Architecture、Project Workspace、Capability、Workflow、状態制御、Persistence、Result / Artifact / Lineage、Security等の基本設計を定義する。

Family / Navigation Stageの導入はWorkspaceのinformation architectureとapplication navigation modelを変更するが、runtime execution lifecycleの責務をpresentation taxonomyへ従属させない。

## 2. System Context

```text
Analyst / Reviewer / Operator
            │
            ▼
        Web Frontend / CLI
            │
            ▼
        Versioned Web API
            │
   ┌────────┼────────┐
   ▼        ▼        ▼
Product  Query     Workflow
Domain   Services  Application
   │        │        │
   └────────┼────────┘
            ▼
Metadata DB / Outbox / Artifact Store
            │
            ▼
           Worker
            │
   ┌────────┼─────────────┐
   ▼        ▼             ▼
Explore  Causal       Predictive
Runners  Runners       Runners
```

Web FrontendはProject-global surfaceとanalytical surfaceを提示する。CLIはheadless interfaceとして同じDomain/Application契約を利用できるが、browser navigation stateへ依存しない。

## 3. Architecture Principle

### 3.1 Layer

- Domain: Resource、state、invariant、value object
- Application: use case、transaction、policy、planner、executor control、navigation coordination
- Port: repository、artifact store、runner、clock、auth、event
- Adapter: SQL、Filesystem / Object Storage、Scientific library、ML library
- Interface: Web API、Worker、CLI、Frontend

DomainはWeb Framework、ORM、plot library、ML library、browser routeおよびlegacy moduleへ依存しない。

### 3.2 Capability分離

```text
Shared Product Core
├── Project / Context
├── Data / Analysis View
├── Workflow Core
├── Result / Artifact / Lineage
└── Security / Audit

Analysis Capabilities
├── Exploratory
├── Causal
└── Predictive
```

各Capabilityは少なくとも次のFamily-specific semanticsを所有する。

- Family Specification Schema
- Planner
- Stage Runner
- Family Validation
- Result Schema
- analytical UI surface / binding
- Navigation Stage catalog
- Benchmark / Acceptance Test

Generic Product/Application codeは、個別FamilyのStage literalや分析意味論を集中所有しない。

### 3.3 Family / Navigation Stage / Execution Stageの責務分離

- `AnalysisFamily`: analytical capability discriminator。
- `Navigation Stage`: Family内のユーザーのwork/view context。
- `Execution Stage`: runtime plan/lifecycle上の処理単位。

`Navigation Stage != Execution Stage`を基本invariantとする。Navigation Stageの追加・名称変更・並び替えだけを理由にExecution Plan、Stage dependency、retry、attempt、status等を変更しない。

## 4. Project Workspace Information Architecture

### 4.1 Workspace全体

Project WorkspaceはProject-global contextとanalytical contextを分離する。

Target layout:

```text
Project header / global context

[ Exploratory ] [ Predictive ] [ Causal ]
-----------------------------------------------------------
Stage sidebar             | Main content
(selected Family only)    | selected Navigation Stage
                          |
-----------------------------------------------------------
Project-global surfaces: Research Context / Data / Results-Lineage etc.
```

Family navigationとStage sidebarは異なるnavigation dimensionである。

### 4.2 Project-global surface

Project headerおよびglobal surfaceでは次を扱う。

- Project name / status
- active Research Context Version
- selected Dataset Version
- selected Analysis View
- current user role
- unsaved draft indicator
- Research Context
- Data / Dataset
- Results / Lineage / Annotation / Export

Project Management、Research Context、Data、Results / Lineage、将来のOverview等をExploratory / Predictive / Causalと同列のanalytical Familyとして扱わない。

### 4.3 Analytical navigation

#### 4.3.1 Family navigation

Exploratory / Predictive / Causalをanalytical Familyとして常時認識可能にする。Current Familyをactive stateで明示する。

Family切替はanalytical perspectiveの切替であり、Project / Research Context / Dataset等のglobal contextを不必要に失わせない。

Family切替時は対象Familyのdefault Navigation Stageへ遷移することをtargetとする。Familyごとのlast-stage memoryは必須要件としない。

#### 4.3.2 Family-local Navigation Stage

selected FamilyのNavigation Stageのみをsidebarへ表示する。

Exploratory:

- Profile
- Data Quality
- Distribution
- Relationships
- Comparison
- Findings

Predictive:

- Setup
- Train
- Predict
- Metrics
- Explainability
- Model Management

Causal:

- Setup
- Discovery
- Identification
- Estimation
- Effects
- Diagnostics
- Sensitivity

Family間でStage数を揃えるためのdummy Stageは作らない。

#### 4.3.3 Navigation Stageはworkflow progressではない

sidebarの表示順はUI上の整理順であり、必須progressionやExecution Plan dependencyを意味しない。

operation prerequisiteが未成立の場合、Stageそのものをruntime lifecycleとしてSKIP扱いにするのではなく、そのStage内のaction availability / validationとして表現することを基本とする。

### 4.4 Route / deep link / history

Current Family / Navigation Stageはrouteから復元可能にする。

Target canonical route候補:

```text
/projects/{project_id}/analysis/{family_slug}/{stage_slug}
```

exact routeはcurrent routerとの整合およびArchitecture Review承認後にfreezeする。

- direct deep linkでFamily / Stageを復元する。
- reloadで同一contextを復元する。
- browser back / forwardでactive Family / Stageとmain contentを同期する。
- legacy analytical routeはcompatibility mappingを定義し、必要に応じてcanonical routeへnormalizeする。

### 4.5 Family-specific screen responsibility

#### 4.5.1 Exploratory

Navigation Stageは探索観点を表す。Visualizationは各Stage内の表現手段であり独立Stageにしない。

#### 4.5.2 Predictive

既存Predictive form、validation、generated specification、execution request、result renderingを再利用する。既存設定項目は削除しない。

`Metrics`と`Explainability`は目的が異なるため別Navigation Stageとする。

#### 4.5.3 Causal

IdentificationとEstimationを別Navigation Stageとして提示し、「何が識別可能か」と「どう推定するか」をUI上でも混同しない。

### 4.6 Loading / Error / Accessibility

- navigation metadata loadingを明示する。
- unknown Family / Stageをsilent fallbackしない。
- renderer binding欠落はunsupported stateとして検出する。
- active Family / Stageは色だけでなくsemantic stateでも識別可能にする。
- small viewportでもFamily dimensionとStage dimensionを混同させない。

## 5. Generic Workflow Core

### 5.1 Planner

`PlannerRegistry`はAnalysis FamilyとSpecification Schema VersionからPlannerを解決する。

```text
AnalysisSpecification
  ↓
PlannerRegistry.resolve(family, schema_version)
  ↓
Family Planner
  ↓
ExecutionPlan
```

PlannerはDomain上のruntime planを生成し、browser navigation stateを入力として要求しない。

### 5.2 Plan

Execution Planはruntime Stage DAGである。

- Stage keyはPlan内一意。
- Stage Typeはruntime operation identityを表す。
- Edgeはoutput / input bindingを表す。
- cycle禁止。
- required input未解決禁止。
- Runner未登録禁止。

Navigation Stageのsidebar orderをExecution Plan dependencyへ変換しない。

### 5.3 Executor

Generic Executorはcanonical lifecycle/application serviceが所有するworkflow execution context内で、Analysis内容を知らずにruntime Stageを実行する。

1. dependency解決
2. runtime Stage sequencing
3. Runner解決・invocation
4. workflow-level validation
5. temporary output binding

canonical Executionのclaim、lease、state、cancel、retry/rerun/revise、transaction、Result/Artifact persistenceは既存canonical lifecycle責務を維持する。

### 5.4 Runner Registry

runtime Runner Registryは`StageType`によりrunnerを解決する。

Navigation Stage IDを`StageType`として登録しない。巨大な`if navigation_stage == ...`をExecutorへ追加しない。

### 5.5 Navigation Stageとの境界

次を禁止する。

- `NavigationStageDescriptor`を`StageDefinition` / `StageExecution`のsubtypeにする。
- Navigation Stage IDをruntime `StageType`へ流用する。
- `AnalysisSpecification.navigation_stage`をexecution prerequisiteとして追加する。
- runtime moduleからbrowser route / Navigation Stage moduleへ依存する。

#### 5.5.1 Distribution

`Exploratory / Distribution`がDataset/profile/resultのreadだけで成立する場合、対応するruntime Execution Stageを作らない。

#### 5.5.2 Metrics

`Predictive / Metrics`は既存evaluation Resultを読むだけで成立してよい。Navigation taxonomyを理由に`METRICS` runtime Stageを新設しない。

#### 5.5.3 Explainability

1 Navigation Stageから複数read/compute use caseを呼び出してよい。Navigation StageとExecution Stageのcardinalityを1:1へ固定しない。

### 5.6 CLI / Library independence

CLI / Python library / backend use caseは、Analysis Specificationまたは既存use-case inputだけでexecutionを開始できる。

`Current Navigation Stage`、browser route、sidebar stateをrequired inputへ追加しない。

## 6. Family別Workflow / Capability

この章で扱う`Workflow`はruntime execution semanticsであり、4章のNavigation Stage一覧とは別概念である。

### 6.1 Exploratory

既存Exploratory runtime operationはProfile / aggregate / visualization等、実際に必要なexecution単位として定義する。軽量read operationに不要なpersistent Stageを追加しない。

Navigation Stage:

```text
Profile / Data Quality / Distribution / Relationships / Comparison / Findings
```

は、existing read/query/runtime capabilitiesへのpresentation bindingとして扱う。

### 6.2 Causal

既存Causal runtime semanticsを保持する。

```text
DISCOVERY
または
IDENTIFICATION → ELIGIBILITY → ESTIMATION → DIAGNOSTICS
                                 ├→ REFUTATION
                                 └→ SENSITIVITY
```

Navigation側の`Effects`等を理由に同名runtime Stageを要求しない。Identification / Estimationの科学的責務は維持する。

### 6.3 Predictive

既存runtime semanticsを保持する。

```text
PREPARE → SPLIT → TRAIN → EVALUATE → EXPLAIN
```

- PREPARE: feature frameとpreprocessing definition
- SPLIT: immutable partition artifact
- TRAIN: train / validationを使用
- EVALUATE: frozen modelをtestへ適用
- EXPLAIN: frozen modelと明示datasetを使用

Navigation側の`Setup / Train / Predict / Metrics / Explainability / Model Management`は、これらruntime stageと1:1対応させない。

Predictiveの既存設定項目、default、validation、generated `predictive-analysis-spec/1` semanticsは全量保持する。

## 7. Validation Architecture

### 7.1 Generic Validation

- Project / Resource ownership
- Schema version
- status gate
- Plan cycle
- Runner availability
- input/output contract
- idempotency
- size / resource limit
- Navigation descriptor uniqueness / default validity

### 7.2 Exploratory Validation

- column typeとchart encoding
- aggregation compatibility
- empty population
- sampling disclosure
- exploratory findingをcausal claimへ変換しない

### 7.3 Causal Validation

- Graph semantics
- Causal Question completeness
- identification strategy
- adjustment set
- inferred type
- eligibility
- estimator compatibility
- post-discovery warning

### 7.4 Predictive Validation

- target existence / type
- feature availability
- target / future / group leakage
- split overlap
- preprocessing fit boundary
- metric / task compatibility
- test isolation
- existing setting/spec parity

### 7.5 Navigation Validation

- supported Familyのみ。
- Stage ID / slugはFamily内一意。
- default Stageはcatalog内に存在する。
- Family / Stage orderingはdeterministic。
- renderer binding欠落を検出する。
- Navigation descriptorにruntime input/output、status、retry semanticsを持たせない。

## 8. Result / Artifact / Lineage

### 8.1 Result

共通EnvelopeとFamily Schemaを分離する。Family-specific analytical meaningを保持する。

Navigation StageをResult ownership keyとして必須化しない。

### 8.2 Artifact Commit

既存canonical Artifact commit / compensation semanticsを維持する。

### 8.3 Lineage

Lineage Query Serviceはtyped structural authorityとgeneric-only authorityを統合してprojectionを返す。Navigation Stageを新たなpersistent lineage resourceとして追加しない。

## 9. Comparison Design

### 9.1 Same-family Comparison

既存comparison semanticsを維持する。

### 9.2 Cross-family Summary

Cross-familyでは単位・意味の異なるmetricを同一scoreとしてrankしない。

- shared Research Context
- shared Dataset / Analysis View
- exploratory findingと後続analysisの関係
- predictive resultとcausal analysisの関係
- selected / rejected Result and rationale

をevidence relationとして扱う。

## 10. Frontend State Design

- server state: API query cache
- route state: Project / Family / Navigation Stage / selected IDs / filters
- draft state: unsaved form
- authoritative state: backend Resource status

Current Family / Navigation StageはDB/workspace persistent stateではなくroute/application stateをtargetとする。

Predictive等のdraft inputをStage切替で不必要に破棄しない。

Button enablementはclient local stateだけで決定せず、backend validation / operation availabilityを利用する。

## 11. Security Design

- Authentication: development header / production OIDC
- Authorization: Project role
- Audit: write / execute / export
- Artifact: controlled download
- Preview: row / column limit、masking option
- Prediction / local explanation: sensitive output policy
- Secret: environment / secret manager

Navigation metadata readもProject visibility/security modelを逸脱しない。

## 12. Deployment

既存Control Plane / Worker / Metadata DB / Artifact Store topologyを維持する。Family / Navigation Stage導入のために別runtime serviceを新設しない。

## 13. Failure Model

| Failure | 扱い |
| --- | --- |
| Navigation descriptor invalid | startup/query validation error。runtime execution failureへ変換しない |
| Unknown Family / Stage route | explicit 4xx / unsupported state。silent fallbackしない |
| Renderer binding missing | presentation/configuration defectとして検出 |
| Validation rejection | Executionを作成せず4xxまたはREJECTED Command Result |
| Technical runtime stage failure | Stage FAILED、Execution FAILED、既存retry policy |
| Analytical prerequisite unmet | Result/operation availabilityとして表現。Navigation Stage存在自体とは分離 |
| Artifact commit failure | 既存compensation対象 |
| Client disconnect | server-side Execution継続。cancelは明示Command |

## 14. Schema / Dependency Boundary

- `analysis-specification/1`の既存`analysis_family`を再利用する。
- Navigation Stage fieldをAnalysisSpecificationへ追加しない。
- ExecutionPlan / Execution / StageExecutionへNavigation Stage fieldを追加しない。
- Product Domainはbrowser route/navigation implementationへ依存しない。
- Scientific / ML / visualization libraryはPort / Adapter背後へ隔離する。
- Capability固有Adapterはcanonical runtime lifecycleを制御しない。
- DB migrationは原則不要とするtarget design。

## 15. Test Architecture

- Domain invariant unit test
- Schema contract test
- Planner golden / Plan DAG test
- Runner contract / worker lifecycle regression
- API authorization / idempotency test
- Frontend route / state / deep-link test
- Family / Navigation Stage descriptor contract test
- Navigation-to-runtime dependency audit
- CLI / library direct execution regression
- Predictive existing setting/spec parity test
- Causal scientific benchmark
- Predictive leakage / split benchmark
- Family横断browser E2E

## 20. CHANGE LOG

### 20.4 ENH-E4 Canonical Execution Architecture

canonical Product runtime Execution authority、generic workflow core、persistent StageExecution、Result / Artifact / Lineage authority等の設計を継承する。

### 20.5 ENH-E5 Family × Navigation Stage Application Architecture

Project Workspaceのanalytical navigationをFamily / Family-local Navigation Stageへ再構成する。Navigation taxonomyはPresentation / Application / Capabilityの責務として追加し、Generic Workflow Coreおよびruntime Execution Stageへ依存を逆流させない。
