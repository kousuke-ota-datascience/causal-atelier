# 30 詳細設計

- 文書状態: `DRAFT_FOR_REVIEW`
- 文書種別: 現行詳細設計のeffective snapshot
- 上位文書: `10_requirements_definition.md`, `21_logical_data_design.md`, `22_product_basic_design.md`, `23_api_interface_design.md`
- 基準Runtime: Python 3.12
- current source照合対象: `src/ariadne/product/`, `src/ariadne/capabilities/`, frontend/router関連実装

## 1. 実装原則

- DomainはFramework / ORM / external analytical object / browser navigationへ依存しない。
- Application ServiceはUnit of WorkとPortを利用する。
- Scientific / ML libraryはAdapterへ隔離する。
- persistent snapshotはstrict schema、canonical JSON、hashを持つ。
- Runnerはpure input/output contractへ近付け、DB transactionを直接操作しない。
- Worker / canonical lifecycle serviceがtransaction、status、Artifact commitを制御する。
- Product packageからlegacy migration moduleや外部分析libraryへの不要な直接importを禁止する。
- `AnalysisFamily`は既存domain enum/discriminatorを再利用する。
- `Navigation Stage`はapplication/presentation metadataであり、Analysis Specification / Execution Plan / StageExecutionへ保存しない。
- Navigation taxonomyの変更だけを理由にruntime Stage semanticsを変更しない。
- CLI / Python library / backend use caseはNavigation Stageなしでexecution可能であることを維持する。

## 2. Package構成

current package責務を維持し、Navigation関連実装は既存layer boundaryに従って追加する。

```text
src/ariadne/
├── product/
│   ├── domain/
│   │   ├── project.py
│   │   ├── research_context.py
│   │   ├── dataset_version.py
│   │   ├── analysis_view.py
│   │   ├── analysis_specification.py
│   │   ├── execution_plan.py
│   │   ├── execution.py
│   │   ├── stage_execution.py
│   │   ├── result.py
│   │   ├── artifact.py
│   │   ├── graph_version.py
│   │   ├── annotation.py
│   │   ├── lineage.py
│   │   ├── schemas.py
│   │   └── errors.py
│   ├── application/
│   │   ├── project_service.py
│   │   ├── context_service.py
│   │   ├── dataset_service.py
│   │   ├── analysis_view_service.py
│   │   ├── analysis_spec_service.py
│   │   ├── planning_service.py
│   │   ├── execution_service.py
│   │   ├── comparison_service.py
│   │   ├── lineage_service.py
│   │   ├── annotation_service.py
│   │   └── export_service.py
│   ├── workflow/
│   │   ├── planner_registry.py
│   │   ├── runner_registry.py
│   │   ├── plan_validator.py
│   │   ├── executor.py
│   │   ├── bindings.py
│   │   └── contracts.py
│   ├── ports/
│   └── persistence/
├── capabilities/
│   ├── exploratory/
│   ├── causal/
│   └── predictive/
├── interfaces/
│   ├── web_api/
│   ├── worker/
│   └── cli/
└── adapters/
```

### 2.1 Navigation関連module配置原則

exact module/class nameはcurrent repository構造とGate freeze時に確定する。次の責務分離を満たすことを優先する。

- Family-specific Navigation Stage catalog: `capabilities/<family>/...`
- generic catalog aggregation/validation: product/applicationまたはinterface-support層
- route parser / browser history / renderer binding: frontend/interface層
- runtime planner/executor: Navigation Stageをimportしない

新しいpersistent `navigation` domain packageを作ることを前提としない。

## 3. Domain Value Objects

### 3.1 AnalysisFamily

current product domainの既存enumを再利用する。

```python
class AnalysisFamily(str, Enum):
    EXPLORATORY = "EXPLORATORY"
    CAUSAL = "CAUSAL"
    PREDICTIVE = "PREDICTIVE"
```

`AnalysisSpecification.analysis_family`、`ExecutionPlan.analysis_family`、`Execution.analysis_family`等の既存discriminatorと整合させる。

新たに`CurrentFamily`をpersistent Domain Value Objectとして追加しない。

### 3.2 StageType

```python
@dataclass(frozen=True)
class StageType:
    namespace: str
    name: str
    version: str
```

`StageType`はruntime operation identityでありNavigation Stageではない。

### 3.3 ResourceRef

既存ResourceRef contractを維持する。Navigation StageをResourceRef対象として扱わない。

### 3.4 Navigation descriptorのclassification

`NavigationStageDescriptor` / `FamilyNavigationDescriptor`を実装する場合、それらはDomain Resourceではなくimmutable application metadata/valueとして扱う。

conceptual shape:

```python
@dataclass(frozen=True)
class NavigationStageDescriptor:
    stage_id: str
    slug: str
    label: str
    order: int

@dataclass(frozen=True)
class FamilyNavigationDescriptor:
    family: AnalysisFamily
    slug: str
    label: str
    default_stage_id: str
    stages: tuple[NavigationStageDescriptor, ...]
```

exact class/module/field namingはfreeze前にcurrent coding conventionへ合わせる。

Invariant:

- supported `AnalysisFamily`のみ。
- Family descriptorは一意。
- Stage listは空でない。
- Stage ID / slugはFamily内一意。
- default StageはStage list内に存在。
- orderはdeterministic。
- runtime input/output/status/retry/attempt semanticsを持たない。

## 4. Schema Registry

既存persistent/analytical schemaを維持する。

- `research-context/1`
- `analysis-view/1`
- `analysis-specification/1`
- `exploratory-analysis-spec/1`
- `causal-analysis-spec/2`
- `predictive-analysis-spec/1`
- `execution-plan/1`
- Family別Result Schema
- `artifact-descriptor/1`
- `lineage-edge/1`

Navigation metadataをAPI化する場合は`analysis-navigation/1`等のread-model schemaを追加候補とするが、persistent analysis schemaへ混入しない。

### 4.1 Analysis Specification schema

current `AnalysisSpecification`が保持する`analysis_family`をcanonical Family discriminatorとして使用する。

次を追加しない。

```text
navigation_stage
current_stage
current_family（analysis_familyと重複するUI stateとして）
```

Family切替とAnalysis Specification identity/versionを混同しない。

## 5. Canonicalization Algorithm

既存canonicalization contractを維持する。

```python
def canonical_bytes(schema, payload):
    schema.validate(payload, reject_unknown=True)
    normalized = schema.normalize(payload)
    reject_non_finite_float(normalized)
    reject_external_objects(normalized)
    return json.dumps(
        normalized,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
```

persistent Domain snapshot hashへbrowser route / Current Navigation Stageを含めない。

Navigation catalog read-modelにhash/etagが必要な場合はpersistent scientific snapshot hashとは別contractとする。

## 6. Research Context Design

### 6.1 Fix

既存DRAFT/FIXED lifecycleを維持する。

1. DRAFT取得
2. Project ACTIVE確認
3. required field検証
4. relation ownership / cycle検証
5. canonical hash生成
6. status FIXED
7. audit / outbox保存

Family / Stage navigation切替によってResearch Context Versionを暗黙変更しない。

### 6.2 Execution Snapshot

Execution作成時の既存snapshot identityを保持する。

- research_context_version_id
- context canonical hash
- question IDsまたは全文
- decision context
- specification ID / hash
- dataset / view ID / hash
- plan ID / hash
- code / runtime versions

browser Navigation Stageをexecution reproducibility snapshotの必須fieldに追加しない。

## 7. Analysis View Compiler

既存Analysis View validation/materialization contractを維持する。

Exploratory / Predictive / Causalは同一Dataset / Analysis Viewを共有できる。Family tab切替だけを理由に別Analysis Viewを生成しない。

### 7.1 Empty Result

row count 0等のanalysis-view semantic validationをNavigation Stage availabilityと混同しない。

## 8. Planner Protocol

```python
class AnalysisPlanner(Protocol):
    family: AnalysisFamily
    spec_versions: frozenset[str]
    def build_plan(self, context: PlanningContext) -> ExecutionPlan: ...
```

PlannerはFIXED Analysis Specification、Resource metadata、Capability Registry、PolicyからExecution Planを生成する。

### 8.1 Navigation independence

Planner required inputへNavigation Stageを追加しない。

禁止例:

```python
def build_plan(context, navigation_stage): ...
```

Navigation `Train`等をruntime Plan Stageへ機械変換しない。

### 8.2 Family discriminator

Familyの解決は既存`analysis_family`等のdomain discriminatorを使用する。browser active tabからFamilyを推測してPlanを生成しない。

## 9. Plan Validator

既存検証順序を維持する。

1. Plan schema
2. Stage key uniqueness
3. Stage Type syntax
4. Runner registration
5. dependency node existence
6. cycle detection
7. output/input name existence
8. schema compatibility
9. enabled stage dependency
10. resource policy upper bound
11. Family-specific plan policy

Navigation Stage order/defaultはPlan Validatorのdependency ruleへ追加しない。

## 10. Runner Registry

```python
class StageRunnerRegistry:
    def register(self, stage_type: StageType, runner: StageRunner) -> None: ...
    def resolve(self, stage_type: StageType) -> StageRunner: ...
```

- duplicate登録をstartup errorとする。
- runner lookup失敗を実行時まで遅延させない。
- Navigation Stage IDをRunner Registry keyにしない。

### 10.1 Capability-owned Navigation Catalog

Navigation catalogはRunner Registryとは別registry/providerとして扱う。

conceptual dependency:

```text
exploratory capability -> exploratory navigation catalog
causal capability      -> causal navigation catalog
predictive capability  -> predictive navigation catalog
           │
           ▼
generic navigation catalog aggregator
```

Catalog:

Exploratory:

```text
profile
data-quality
distribution
relationships
comparison
findings
```

Predictive:

```text
setup
train
predict
metrics
explainability
model-management
```

Causal:

```text
setup
discovery
identification
estimation
effects
diagnostics
sensitivity
```

Default Stageはroute compatibilityとHuman approval後にfreezeする。

## 11. Generic Executor Sequence

existing canonical execution sequenceを維持する。

```text
canonical lifecycle/application service claims Execution
  ↓
load immutable Plan and snapshots
  ↓
validate runner capability
  ↓
mark Execution RUNNING
  ↓
for each ready runtime Stage:
    resolve input bindings
    create / increment attempt
    mark RUNNING
    runner.validate
    runner.run
    validate Result / Artifact
    persist/commit under canonical lifecycle authority
```

### 11.1 Navigation Stageとのdependency prohibition

runtime `executor.py`、planning/lifecycle service、StageExecution persistenceからNavigation descriptor/routerへ依存しない。

望ましいdependency:

```text
Presentation / Navigation
        ↓
Application / Capability
        ↓
Runtime Execution
```

禁止:

```text
Runtime Execution
        ↓
Browser route / Navigation Stage
```

### 11.2 Cardinalityを固定しない

次を許容する。

- Navigation 1 : Execution 0
- Navigation 1 : Execution N
- Execution 1 : Navigation N consumers

具体例:

- `Distribution`: Dataset/profile/result readだけで表示可能。
- `Metrics`: 既存evaluation Result readだけで表示可能。
- `Explainability`: 1 Navigation Stageから複数compute/read use caseを呼べる。

## 12. Exploratory Capability

既存Explore capabilityのscientific semanticsを維持し、Navigation Stageを探索観点としてbindingする。

### 12.1 Profile / Data Quality

Dataset metadata/profile/quality情報を既存read modelまたは既存operationから提示する。

### 12.2 Distribution / Relationships / Comparison

- Distribution: univariate distribution
- Relationships: variable relation
- Comparison: segment/group/cohort comparison

chart typeはNavigation Stage identityではない。

### 12.3 Findings

既存Result / Annotation / Lineageを優先利用する。専用persistent `Finding` aggregateを新設しない。

### 12.4 Chart Specification

mark、encoding、aggregation、binning、sorting、sampling disclosure等の既存chart semanticsを維持する。

Visualizationは`Distribution`等のrepresentationであり、独立Navigation Stageにしない。

## 13. Causal Capability

### 13.1 Causal Specification

既存`causal-analysis-spec/2`等のscientific contractを維持する。

### 13.2 Input Matrix

runtime operation間のscientific prerequisiteをNavigation sidebar orderとは別に扱う。

例:

| Runtime Operation | Graph | Upstream Result |
| --- | --- | --- |
| DISCOVERY | なし | なし |
| IDENTIFICATION | 必須 | なし |
| ESTIMATION | 必須 | Identification Result必須 |
| REFUTATION | 必須 | Treatment Effect Result必須 |
| SENSITIVITY | 必須 | Treatment Effect Result必須 |

### 13.3 Identification

Navigation `Identification`では次を提示・編集・検証する。

- estimand / causal question
- adjustment set
- identification strategy
- exchangeability / positivity / consistency等のassumption
- identification status / reason

IdentificationとEstimationを同一surface/controlへ戻さない。

### 13.4 Estimation

Navigation `Estimation`ではestimator / nuisance model / estimation runを扱う。Identification成立条件と推定手法選択を区別する。

### 13.5 Effects / Diagnostics / Sensitivity

- Effects: 保存済みcausal effect Resultの閲覧・比較
- Diagnostics: balance / overlap / effective sample size等
- Sensitivity: unmeasured confounding / alternate spec等

これらNavigation Stageを理由に同名runtime Stageを必須化しない。

### 13.6 Revised Execution / Post-discovery Warning

ENH-E4までのRERUN / REVISED、post-discovery warning等のcanonical semanticsを維持する。

## 14. Predictive Capability

### 14.1 Existing configuration inventory

実装前にcurrent Predictive UI control、frontend state、generated request、`predictive-analysis-spec/1` field、validation/defaultを全量inventoryする。

trace tableを作る。

| Current control | semantic | generated field | Navigation Stage | parity test |
| --- | --- | --- | --- | --- |
| actual current control | current meaning | current field | Setup等 | exact parity |

設定を推測で削除・追加しない。

### 14.2 Prediction Question / Setup

既存Prediction Task、target、feature/input、split/training/evaluation/explanation関連設定を`Setup`等へ再配置する。

Stage構造のために`predictive-analysis-spec/1`をsimplifyしない。

### 14.3 Split Runner

既存partition semanticsを維持する。

- train / validation / test intersection = empty
- group strategyではgroup intersection = empty
- time strategyではtemporal boundaryを守る
- stratifyはclassification等既存compatibilityに従う

### 14.4 Leakage Validator

既存target / future / group leakage、preprocessing fit boundary、test isolationを保持する。

### 14.5 Prepare / Train Runner

既存PREPARE / TRAIN runtime semanticsを維持する。Navigation `Train`をruntime `TRAIN` Stageと同一概念として扱わない。Navigation `Train` surfaceから複数existing runtime operationsを起動してよい。

### 14.6 Predict Navigation Stage

既存model/result/operation capabilitiesの範囲でprediction surfaceを構成する。新しいstandalone scoring engineをこの改修の必須scopeとしない。

### 14.7 Metrics Navigation Stage

保存済みEvaluation Resultをread/compareして表示できる。`Metrics` runtime Stage新設を要求しない。

### 14.8 Explainability Navigation Stage

既存Explanation Result / compute mechanismへbindingする。新しいSHAP等のexternal library導入を必須化しない。

### 14.9 Model Management Navigation Stage

既存model Artifact / Result / Model Card / Lineageのread-oriented surfaceとして構成する。general-purpose model registryを新設しない。

### 14.10 Draft state preservation

Navigation Stage切替によるcomponent remount等で既存Predictive form valueを不必要に破棄しない。current state ownershipと一致する保存方法を採用する。

## 15. Result Status Mapping

既存Family-specific Result status semanticsを維持する。

Navigation StageをResult status/typeへ自動変換しない。

### 15.1 Causal

Causal Resultのscientific status contractを既存schemaで検証する。

### 15.2 Predictive

TRAINING_RESULT、EVALUATION_RESULT、PREDICTIVE_EXPLANATION_RESULT、MODEL_CARD_RESULT等の既存意味論を保持する。

### 15.3 Exploratory

Exploratory Result statusを保持し、finding表示をcausal conclusionへ変換しない。

## 16. Comparison Algorithm

既存comparison algorithmを維持する。

1. Result Type / Schema compatibility検証
2. Research Context、Dataset/View、Task/Estimand key抽出
3. invariant / changed field canonical diff
4. metric unit検証
5. result / warning delta生成
6. explanation生成
7. projection返却

Cross-familyでPredictive metricとCausal effect等を同一numeric scoreへ平坦化しない。

## 17. Lineage Projection

既存Lineage projection contractを維持する。

- typed structural relationとgeneric-only relationのauthorityを分ける。
- Project境界を越えない。
- synthetic export relationをpersistence authorityへ昇格させない。

Navigation Stageをpersistent Lineage node/edgeの必須identityへ追加しない。

必要なpresentation contextはFamily、Result type、route binding等からderiveする。

## 18. Frontend / Navigation Components

### 18.1 ProjectShell

Project-global surfaceとanalytical surfaceを分離する。

```text
ProjectShell
├── Project/Context/Data global surfaces
├── AnalyticalNavigation
│   ├── FamilyTabs
│   └── FamilyStageSidebar
├── AnalyticalStageSurface
└── Results/Lineage global surface
```

実際のcomponent名はcurrent frontend conventionに合わせる。

### 18.2 Navigation model loading

backend metadata APIまたはapproved capability descriptor sourceからcatalogを取得/構築し、validated in-memory modelへnormalizeする。

state:

```text
loading
ready(catalog)
error
```

### 18.3 FamilyTabs

- supported Familyをrenderする。
- routeからCurrent Familyをresolveする。
- active stateをsemanticに表現する。
- click時はtarget Family + default Stageへnavigateする。
- Familyごとのlast-stage memoryを必須化しない。

### 18.4 FamilyStageSidebar

- Current FamilyのStageだけをrenderする。
- routeからCurrent Stageをresolveする。
- Stage clickでFamilyを維持しStageだけ変更する。
- sidebar orderをworkflow dependencyとして扱わない。

### 18.5 Renderer binding

conceptual registry:

```text
(family, navigation_stage_id) -> existing surface adapter / render binding
```

renderer registryへlabel/order/default catalogを重複定義しない。

### 18.6 Route / History

Target route候補:

```text
/projects/{project_id}/analysis/{family_slug}/{stage_slug}
```

実装要件:

- parse/serialize round-trip
- direct deep link
- reload restore
- back/forward synchronization
- legacy route normalization
- invalid Family/Stage explicit error

exact canonical routeはGate freeze前にcurrent routerとArchitecture Reviewで確定する。

### 18.7 Navigation metadata API candidate

backend canonical catalog interfaceを採用する場合のtarget候補:

```http
GET /api/v1/navigation/analysis
```

Response candidate: `analysis-navigation/1`。

ただしexact endpointは未承認targetであり、current architecture上static capability descriptorの方が妥当ならArchitecture Reviewで差し替える。Execution Agentへ選択を委ねない。

### 18.8 Operation availability

Stage existenceとaction availabilityを分離する。

例: `Causal / Estimation` Stageは表示されていてもIdentification prerequisite未成立ならRun actionをblockできる。

### 18.9 Error states

- unknown Family: unsupported/not-found
- unknown Stage: unsupported/not-found
- invalid catalog: fail-fast
- catalog load failure: navigation error
- renderer missing: configuration defect

silent fallbackで別Stageへ飛ばさない。

### 18.10 Terminology Guard

- Predictive画面で`effect`を一般結果名として使わない。
- Causal画面でfeature importanceを因果説明として表示しない。
- Exploratory findingにcausal断定語を自動生成しない。

## 19. Persistence Mapping

既存Product table/resource mappingを維持する。

主要対象:

- research context
- dataset version
- analysis view
- analysis specification
- execution plan
- execution
- stage execution
- result
- artifact
- graph version
- annotation
- lineage edge

Persistence rule:

1. immutable resourceは新Version/Resourceで変更する。
2. lifecycle status transitionを直列化する。
3. Execution / StageExecution / Result / Artifact metadata / Lineageのcommit boundaryをUnit of Workで管理する。
4. JSON payloadは保存前にschema validation / canonicalization / hash生成を行う。
5. typed structural relationとgeneric-only relation authorityを分ける。
6. Projectを跨ぐrelationを拒否する。

### 19.1 Navigation persistence

次を新規table/columnとして追加しないことをtargetとする。

- current_family
- current_navigation_stage
- navigation_stage descriptor table
- AnalysisSpecification.navigation_stage
- Execution.navigation_stage
- StageExecution.navigation_stage

Current Family / StageはURL/application stateとして扱う。

## 20. Test Design

### 20.1 Domain / Schema

- immutable state
- status transition
- canonical hash golden
- unknown field rejection
- cross-project reference rejection
- existing `analysis_family` discriminator reuse
- no Navigation Stage persistent field

### 20.2 Workflow

- planner deterministic output
- cycle rejection
- runner registry duplicate / missing
- artifact binding
- retry / cancellation
- worker crash recovery
- runtime module -> navigation module prohibited dependency audit
- direct CLI/library/backend execution without Navigation Stage

### 20.3 Navigation

- Family descriptor uniqueness
- Stage uniqueness / order / default
- Family switch
- Stage switch
- direct deep link
- reload
- browser back/forward
- legacy route normalization
- invalid Family / Stage
- missing renderer
- no 1:1 Navigation/Execution assumption

### 20.4 Causal

- Identification / Estimation semantic separation
- existing scientific validation/regression
- Effects / Diagnostics / Sensitivity binding
- Navigation Stage additionによるruntime plan semantic regressionなし

### 20.5 Predictive

- current setting inventory coverage 100%
- generated `predictive-analysis-spec/1` parity
- validation/default parity
- target/future/group leakage
- split/test isolation
- draft state preservation
- Metrics can read existing evaluation result
- Explainability binding
- Model Management existing artifact/result reuse

### 20.6 Exploratory

- Profile / Data Quality / Distribution / Relationships / Comparison / Findings binding
- Visualization is representation, not independent Stage
- Distribution read-only path without required new runtime Stage
- finding does not imply causal claim

### 20.7 E2E

- Web API + Worker + DB + Artifact Store
- Family tabs + Stage sidebar
- direct route / deep link
- authorization
- Result / Lineage continuity
- cross-family context preservation

## 21. Definition of Done

- Domain、API、DB、UIの用語・Enum・Schema Versionが一致する。
- `AnalysisFamily`のduplicate discriminatorを導入していない。
- AnalysisSpecification / ExecutionPlan / Execution / StageExecutionへNavigation Stageを追加していない。
- Navigation StageとExecution Stageの1:1 mappingを要求していない。
- CLI / library / backend use caseがNavigation Stageなしで実行できる。
- Predictive既存設定項目、generated spec、validation/defaultが保持される。
- Identification / Estimation等のFamily-specific semanticsが保持される。
- route / deep-link / historyがFamily / Stageと整合する。
- DB/runtime schema migrationが必要な場合は事前にarchitecture amendmentが承認されている。targetはmigrationなし。
- mandatory testおよびprotected regressionが成功する。

## 30. CHANGE LOG

### 30.4 ENH-E4 Canonical Execution Detailed Contract

one canonical persistent Execution identity、generic workflow core、persistent StageExecution、one Result / Artifact / Lineage authority、standalone low-level CLI independence等の設計を継承する。

### 30.5 ENH-E5 Family × Navigation Stage Detailed Contract

Capability-owned Navigation Stage catalog、Family/Stage route/history、presentation bindingを追加する。一方、`AnalysisSpecification.analysis_family`を既存Family discriminatorとして再利用し、Navigation Stageをpersistent analysis/runtime contractへ追加しない。runtime planner/executor/CLI/libraryはNavigation Stageから独立させる。
