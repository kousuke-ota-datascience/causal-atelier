# G04 — Exploratory Family Recomposition

- Semantic claim: current Explore & Visualize capabilityをProfile/Data Quality/Distribution/Relationships/Comparison/Findingsへ再配置し、visualizationをanalytical Stageではなく各Stageの表現手段として位置づける。
- Execution mode: `WORK_PACKAGE`
- Contract status: `DRAFT_FOR_REVIEW` until approval + baseline resolution.
