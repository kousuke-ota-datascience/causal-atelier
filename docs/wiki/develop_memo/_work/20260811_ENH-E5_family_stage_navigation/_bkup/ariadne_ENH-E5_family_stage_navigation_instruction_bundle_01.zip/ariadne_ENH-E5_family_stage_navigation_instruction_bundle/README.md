# Ariadne ENH-E5 — Family × Stage Navigation Enhancement

Document class: Authoring / Orchestration Guide  
Template compatibility: `agentic_enhancement_workflow_template` schema v11  
Branch: `feature/ariadne_mvp_e5`  
Bundle status: **DRAFT_FOR_REVIEW**  
Prepared at: `2026-08-11T11:12:00+09:00`

## 0. 結論

本bundleは、Ariadneのanalytical capabilitiesを **Family × Family-owned Navigation Stage** で再構成する ENH-E5 の初版指示書一式である。

今回の中心契約は次のとおり。

1. `Family = global analytical context`、`Navigation Stage = Family-local work/view context` とする。
2. UIは **上部横タブ=Family、左サイド=selected FamilyのStage** とする。
3. `Navigation Stage != Execution Stage` をarchitecture invariantとする。
4. concrete Navigation Stage catalogは各Capabilityが所有する。
5. Current Family / Stageのcanonical stateはURLとし、E5ではDB/workspace-stateへ永続化しない。
6. Predictive既存設定・実行semanticsは100%保持する。
7. LightGBM / DoWhy / EconML等の新規analytical engineはscope外とする。
8. Overview/Flagship、専用Findings/Evidence domain、AnalysisResult再設計はE5では導入しない。

## 1. Workflow status

このbundleはschema v11のdocument authority modelに従う。

- 00: Background / requirement / design revision
- 10: Gate Coding Contract / Gate Verification Contract / Work Package
- 20: Implementation evidence — **execution開始前なので未生成**
- 30: Independent verification evidence — **verification開始前なので未生成**
- 40: Architecture review / operator prompts / preflight
- Current State Control Sheet: verified current stateのみを保持

**重要:** 未実行のimplementation/test evidenceを捏造しないため、20/30にはREADMEのみを配置している。Trial開始時にtemplate規約どおり生成すること。

## 2. Freeze preconditions

Planning baselineはremote branch HEAD `46122c68333df03680b97c253a7b5d32bf9393e7` にpinした。

06/07を`FROZEN`へ昇格する前に、local repositoryでpreflightを実行し、local checkoutがこのpinと一致すること、およびtest baselineが成立することを確認する。

```bash
git branch --show-current
git rev-parse HEAD
git status --short
```

期待branch: `feature/ariadne_mvp_e5`  
期待SHA: `46122c68333df03680b97c253a7b5d32bf9393e7`

Human approvalとpreflight成立前にCoding Agentを起動してはならない。

## 3. Gate map

| Gate | Semantic acceptance boundary | Execution mode |
|---|---|---|
| G00 | Family / Navigation Stage domain contractとcapability-owned catalogが成立 | SINGLE_EXECUTION |
| G01 | URL-driven Family/Stage navigation shellとlegacy navigation compatibilityが成立 | WORK_PACKAGE |
| G02 | Predictiveを6 Stageへ再配置し、既存設定・実行semanticsの完全互換が成立 | WORK_PACKAGE |
| G03 | Causalを7 Stageへ再配置し、Identification/Estimation分離と既存操作互換が成立 | WORK_PACKAGE |
| G04 | Exploratoryを6 Stageへ再配置し、探索観点ベースnavigationと既存操作互換が成立 | WORK_PACKAGE |
| G05 | 3 Family横断のcontext/result continuityとproduct-wide regression contractが成立 | SINGLE_EXECUTION |

## 4. Source hierarchy

Planning時のsource hierarchyは以下とする。

1. 本bundleのapproved 00層 / 06 / 07（approval後）
2. `feature/ariadne_mvp_e5` のcurrent code
3. ENH-E5 handoff memo
4. template schema v11

Factとtarget decisionが衝突する場合、実装Agentは勝手に解釈して進めず`BLOCKED_CONTRACT_AMBIGUITY`とする。

## 5. Directory entry points

- Background: `00_enhance_background/`
- Gate contracts: `10_enhance_instruction/`
- Architecture review: `40_operator_workflows/architecture_review/`
- Preflight: `40_operator_workflows/preflight/ENH-E5_preflight_instruction.md`
- Current state: `ENH-E5_Current_State_Control_Sheet.md`
- Manifest: `MANIFEST.json`
