# Ariadne ENH-E5 G03 実装指示書 — Gate Coding Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G03
- Gate title: Causal Family Recomposition
- Branch: `feature/ariadne_mvp_e5`
- Baseline: `46122c68333df03680b97c253a7b5d32bf9393e7`
- Contract status: **DRAFT_FOR_REVIEW**
- Execution Mode: `WORK_PACKAGE`
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Gate definition / acceptance claim

### Objective
current Causal Discovery/Inference surfacesをSetup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityへ再配置し、IdentificationとEstimationの責務分離を明示する。

### Downstream usable result after PASS
ユーザーとG05が、causal design/execution/resultsをdistinct Stage contextで利用しつつ既存causal semanticsへ依存できる。

### Why this is one Gate
This boundary is a single semantic claim that can be independently accepted and protected. Implementation volume is handled by Work Packages when mode is WORK_PACKAGE.

## 2. Effective implementation context

- Family is an analytical capability context.
- Navigation Stage is a UI/application work or view context.
- `Navigation Stage != Execution Stage`.
- Stage names/counts can differ by Family.
- Stage navigation is not a mandatory sequential workflow.
- Existing analytical execution/persistence semantics are protected unless this Gate explicitly says otherwise.
- External analytical engines are outside ENH-E5.

Acceptance targets associated with this Gate:
- AC-G03-001: All seven Causal Navigation Stages are reachable and use canonical routes.
- AC-G03-002: Discovery retains current graph discovery/candidate/direct-registration operations.
- AC-G03-003: Identification has its own route/surface and contains identification strategy/adjustment/eligibility result context separate from Estimation.
- AC-G03-004: Estimation retains current estimator selection, warning/revision rules and execution semantics without new estimators.
- AC-G03-005: Effects presents treatment-effect result/compare semantics without being conflated with estimation configuration.
- AC-G03-006: Diagnostics preserves existing eligibility/estimation diagnostics.
- AC-G03-007: Sensitivity preserves current Refutation and Sensitivity operations/methods.
- AC-G03-008: Navigation is non-sequential; operation prerequisites may block an action but not Stage navigation itself.
- AC-G03-009: Existing causal regression tests pass.

## 3. Execution Mode decision

Mode: `WORK_PACKAGE`.

Use `06_G03_P00_work_package_plan.md` and all planned Pxx instructions. Package completion does not mean Gate PASS.

## 4. Required implementation semantics

The implementation MUST make the Gate objective true without changing the meaning of protected upstream contracts. Favor additive/refactoring changes that preserve current analysis specs, execution plans, result schemas, and current algorithms unless explicitly required in this Gate.

## 5. Allowed scope

- seven Causal stage surfaces
- current discovery graph operations
- current identification/data eligibility
- current estimation methods/execution
- effects comparison
- diagnostics
- refutation/sensitivity

## 6. Explicit prohibited scope

- DoWhy/EconML
- new estimator library
- Analysis Management stage
- automatic causal identification proof
- strict stage wizard

Global prohibitions:
- no assertion weakening/test deletion/skip/xfail solely to obtain green tests;
- no silent requirement/AC change;
- no next-Gate work bundled into this Gate;
- no unapproved schema/dependency/engine expansion.

## 7. Protected passed-Gate contracts

All final-PASS contracts from preceding ENH-E5 Gates; exact SHA/evidence must be read from Current State Control Sheet before execution.

Before coding, read the Current State Control Sheet and record the exact protected Gate evidence identities in the implementation report.

## 8. Transition Debt

NONE planned. Deferred scope is not Transition Debt.

If temporary exceptional behavior becomes unavoidable, stop and request explicit architecture/Human decision; do not invent undocumented debt.

## 9. Schema / migration / API / runtime policy

- DB schema migration: `PROHIBITED unless explicitly amended`.
- AnalysisSpecification/Execution/Result schema change: `PROHIBITED unless explicitly stated by this Gate`.
- Execution lifecycle: preserve existing semantics.
- API changes: additive only where this Gate explicitly requires them.
- Legacy analytical routes: preserve or explicitly normalize; do not silently remove.

## 10. Automated test obligations

- Implement automated evidence for AC-G03-001: All seven Causal Navigation Stages are reachable and use canonical routes.
- Implement automated evidence for AC-G03-002: Discovery retains current graph discovery/candidate/direct-registration operations.
- Implement automated evidence for AC-G03-003: Identification has its own route/surface and contains identification strategy/adjustment/eligibility result context separate from Estimation.
- Implement automated evidence for AC-G03-004: Estimation retains current estimator selection, warning/revision rules and execution semantics without new estimators.
- Implement automated evidence for AC-G03-005: Effects presents treatment-effect result/compare semantics without being conflated with estimation configuration.
- Implement automated evidence for AC-G03-006: Diagnostics preserves existing eligibility/estimation diagnostics.
- Implement automated evidence for AC-G03-007: Sensitivity preserves current Refutation and Sensitivity operations/methods.
- Implement automated evidence for AC-G03-008: Navigation is non-sequential; operation prerequisites may block an action but not Stage navigation itself.
- Implement automated evidence for AC-G03-009: Existing causal regression tests pass.

Also run focused existing tests for modified modules and regression tests covering all protected upstream contracts impacted by the diff.

## 11. Candidate Assembly

Before `READY_FOR_TEST`:
1. all required implementation scope is complete;
2. all packages, if any, have valid checkpoint reports;
3. unresolved blockers are `NONE`;
4. focused and Gate-wide self-verification is recorded;
5. production/test/migration/dependency diff is reviewed;
6. one Fixed Trial Candidate SHA is recorded in the implementation completion report.

## 12. Coding Agent prohibited work

Coding Agent MUST NOT:
- decide Gate PASS;
- alter 07 Acceptance Criteria;
- treat package completion as partial PASS;
- modify passed-Gate semantics without amendment;
- implement excluded downstream features.

## 13. Required outputs

- implementation completion report for Trial01 (or current Trial)
- Gate-local implementation ledger/detail as required
- package checkpoint/status reports when WORK_PACKAGE
- exact Fixed Trial Candidate SHA
- commands and test evidence
- explicit blocker status

## 14. External reference policy

Source code paths and observed runtime/test output may be referenced as evidence. Normative rules needed for execution are contained in this contract and, in Work Package mode, the assigned Pxx contract.
