# G02 — Predictive Family Recomposition and Compatibility

- Semantic claim: current Predictive workspaceをSetup/Train/Predict/Metrics/Explainability/Model Managementへ再配置し、既存設定項目とgenerated spec/execution semanticsの完全互換を成立させる。
- Execution mode: `WORK_PACKAGE`
- Contract status: `DRAFT_FOR_REVIEW` until approval + baseline resolution.
