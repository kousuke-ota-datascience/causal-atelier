# ENH-E5 Target Architecture Decision Record

Document class: Architecture Decision Artifact  
Status: **DRAFT_FOR_HUMAN_APPROVAL**

## ADR-1 Decision

Establish a separate, thin application navigation model:

```text
AnalysisFamily
  -> FamilyNavigationDescriptor
       -> NavigationStageDescriptor*
```

Concrete descriptor instances are owned by each analytical capability. Generic product/application code validates/aggregates. Frontend consumes a read-only descriptor API and binds stage IDs to presentation surfaces.

## ADR-2 Invariants

1. Navigation Stage is not Execution Stage.
2. Navigation descriptors never carry runner/lifecycle/dependency/input-output-contract semantics.
3. Concrete stage semantics are capability-owned.
4. Existing `AnalysisFamily` is reused as Family identity.
5. Backend descriptor API is canonical stage catalog source.
6. Current Family/Stage is URL state in E5, not persisted state.
7. Global project workspaces remain outside Family.
8. Predictive existing configuration/spec semantics are protected.
9. No new analytical engine or persistent result model is introduced.

## ADR-3 API / route

- descriptor: `GET /api/v1/navigation/analysis`
- canonical page route: `/projects/{project_id}/analysis/{family_slug}/{stage_slug}`

## ADR-4 Capability catalog

Exploratory: Profile, Data Quality, Distribution, Relationships, Comparison, Findings.  
Predictive: Setup, Train, Predict, Metrics, Explainability, Model Management.  
Causal: Setup, Discovery, Identification, Estimation, Effects, Diagnostics, Sensitivity.

## ADR-5 Alternatives considered

### A. Frontend-static full catalog
Rejected: duplicates capability semantics and weakens ownership contract.

### B. Reuse Execution StageType for navigation
Rejected: execution stages carry pipeline/runtime semantics and do not map 1:1 to UI contexts.

### C. Persist current Family/Stage in workspace-state
Rejected for E5: URL already provides shareable/history-aware state; persistence adds cross-device/session semantics that are not a stated requirement.

### D. Add Overview as fourth top tab
Rejected for E5: Overview is not an analytical Family and would mix navigation dimensions. Reconsider in a later enhancement as global workspace if needed.

## ADR-6 Migration

DB migration: `N/A`.  
API change: additive.  
Route change: additive canonical routes + legacy normalization.  
Execution/result schema migration: `N/A`.

## ADR-7 Approval

Human architecture owner: `PENDING`  
Approved at: `PENDING`  
Baseline SHA reviewed: `46122c68333df03680b97c253a7b5d32bf9393e7`
