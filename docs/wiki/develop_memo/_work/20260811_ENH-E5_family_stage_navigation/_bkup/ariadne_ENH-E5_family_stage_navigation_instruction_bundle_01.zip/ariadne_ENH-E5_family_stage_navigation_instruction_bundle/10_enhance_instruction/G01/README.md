# G01 — URL-driven Family / Stage Navigation Shell

- Semantic claim: canonical catalogを利用してtop Family tabs + Family-local Stage sidebarを成立させ、URL/deep link/history/legacy route compatibilityを確立する。
- Execution mode: `WORK_PACKAGE`
- Contract status: `DRAFT_FOR_REVIEW` until approval + baseline resolution.
