# Ariadne ENH-E5 G00 実装指示書 — Gate Coding Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G00
- Gate title: Family / Navigation Stage Domain Contract
- Branch: `feature/ariadne_mvp_e5`
- Baseline: `46122c68333df03680b97c253a7b5d32bf9393e7`
- Contract status: **DRAFT_FOR_REVIEW**
- Execution Mode: `SINGLE_EXECUTION`
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Gate definition / acceptance claim

### Objective
FamilyとNavigation Stageのapplication contractをExecution Stageから独立して成立させ、capability-owned canonical stage catalogとread APIを提供する。

### Downstream usable result after PASS
G01以降が、stable Family ID / stage ID / order / default Stage / catalog APIへ依存できる。

### Why this is one Gate
This boundary is a single semantic claim that can be independently accepted and protected. Implementation volume is handled by Work Packages when mode is WORK_PACKAGE.

## 2. Effective implementation context

- Family is an analytical capability context.
- Navigation Stage is a UI/application work or view context.
- `Navigation Stage != Execution Stage`.
- Stage names/counts can differ by Family.
- Stage navigation is not a mandatory sequential workflow.
- Existing analytical execution/persistence semantics are protected unless this Gate explicitly says otherwise.
- External analytical engines are outside ENH-E5.

Acceptance targets associated with this Gate:
- AC-G00-001: Family identity is the existing AnalysisFamily values EXPLORATORY/CAUSAL/PREDICTIVE.
- AC-G00-002: Navigation descriptor types are structurally and semantically independent from execution StageType/StageDefinition/StageExecution.
- AC-G00-003: Each capability owns its exact Stage IDs, labels, order, and default Stage.
- AC-G00-004: Generic aggregation rejects duplicate families/stages, empty stage list, or invalid default Stage.
- AC-G00-005: GET /api/v1/navigation/analysis returns deterministic schema analysis-navigation/1 for all 3 Families.
- AC-G00-006: No DB migration or navigation-state persistence is introduced.
- AC-G00-007: Existing workflow/execution tests remain green.

## 3. Execution Mode decision

Mode: `SINGLE_EXECUTION`.

Implement as one bounded candidate and perform Gate-wide self-check before candidate freeze.

## 4. Required implementation semantics

The implementation MUST make the Gate objective true without changing the meaning of protected upstream contracts. Favor additive/refactoring changes that preserve current analysis specs, execution plans, result schemas, and current algorithms unless explicitly required in this Gate.

## 5. Allowed scope

- generic navigation descriptor types
- capability-owned stage catalogs for all 3 Families
- catalog aggregation/validation
- GET /api/v1/navigation/analysis
- unit/API tests

## 6. Explicit prohibited scope

- Execution StageType/StageDefinition/StageExecutionの変更またはalias利用
- frontend navigation shell implementation
- DB migration
- analytical engine changes

Global prohibitions:
- no assertion weakening/test deletion/skip/xfail solely to obtain green tests;
- no silent requirement/AC change;
- no next-Gate work bundled into this Gate;
- no unapproved schema/dependency/engine expansion.

## 7. Protected passed-Gate contracts

NONE — first Gate.

Before coding, read the Current State Control Sheet and record the exact protected Gate evidence identities in the implementation report.

## 8. Transition Debt

NONE planned. Deferred scope is not Transition Debt.

If temporary exceptional behavior becomes unavoidable, stop and request explicit architecture/Human decision; do not invent undocumented debt.

## 9. Schema / migration / API / runtime policy

- DB schema migration: `PROHIBITED unless explicitly amended`.
- AnalysisSpecification/Execution/Result schema change: `PROHIBITED unless explicitly stated by this Gate`.
- Execution lifecycle: preserve existing semantics.
- API changes: additive only where this Gate explicitly requires them.
- Legacy analytical routes: preserve or explicitly normalize; do not silently remove.

## 10. Automated test obligations

- Implement automated evidence for AC-G00-001: Family identity is the existing AnalysisFamily values EXPLORATORY/CAUSAL/PREDICTIVE.
- Implement automated evidence for AC-G00-002: Navigation descriptor types are structurally and semantically independent from execution StageType/StageDefinition/StageExecution.
- Implement automated evidence for AC-G00-003: Each capability owns its exact Stage IDs, labels, order, and default Stage.
- Implement automated evidence for AC-G00-004: Generic aggregation rejects duplicate families/stages, empty stage list, or invalid default Stage.
- Implement automated evidence for AC-G00-005: GET /api/v1/navigation/analysis returns deterministic schema analysis-navigation/1 for all 3 Families.
- Implement automated evidence for AC-G00-006: No DB migration or navigation-state persistence is introduced.
- Implement automated evidence for AC-G00-007: Existing workflow/execution tests remain green.

Also run focused existing tests for modified modules and regression tests covering all protected upstream contracts impacted by the diff.

## 11. Candidate Assembly

Before `READY_FOR_TEST`:
1. all required implementation scope is complete;
2. all packages, if any, have valid checkpoint reports;
3. unresolved blockers are `NONE`;
4. focused and Gate-wide self-verification is recorded;
5. production/test/migration/dependency diff is reviewed;
6. one Fixed Trial Candidate SHA is recorded in the implementation completion report.

## 12. Coding Agent prohibited work

Coding Agent MUST NOT:
- decide Gate PASS;
- alter 07 Acceptance Criteria;
- treat package completion as partial PASS;
- modify passed-Gate semantics without amendment;
- implement excluded downstream features.

## 13. Required outputs

- implementation completion report for Trial01 (or current Trial)
- Gate-local implementation ledger/detail as required
- package checkpoint/status reports when WORK_PACKAGE
- exact Fixed Trial Candidate SHA
- commands and test evidence
- explicit blocker status

## 14. External reference policy

Source code paths and observed runtime/test output may be referenced as evidence. Normative rules needed for execution are contained in this contract and, in Work Package mode, the assigned Pxx contract.
