# Ariadne ENH-E5 G04 実装指示書 — Gate Coding Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G04
- Gate title: Exploratory Family Recomposition
- Branch: `feature/ariadne_mvp_e5`
- Baseline: `46122c68333df03680b97c253a7b5d32bf9393e7`
- Contract status: **DRAFT_FOR_REVIEW**
- Execution Mode: `WORK_PACKAGE`
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Gate definition / acceptance claim

### Objective
current Explore & Visualize capabilityをProfile/Data Quality/Distribution/Relationships/Comparison/Findingsへ再配置し、visualizationをanalytical Stageではなく各Stageの表現手段として位置づける。

### Downstream usable result after PASS
ユーザーとG05が、EDAを探索観点別にnavigationしつつ既存exploratory resultsを失わず利用できる。

### Why this is one Gate
This boundary is a single semantic claim that can be independently accepted and protected. Implementation volume is handled by Work Packages when mode is WORK_PACKAGE.

## 2. Effective implementation context

- Family is an analytical capability context.
- Navigation Stage is a UI/application work or view context.
- `Navigation Stage != Execution Stage`.
- Stage names/counts can differ by Family.
- Stage navigation is not a mandatory sequential workflow.
- Existing analytical execution/persistence semantics are protected unless this Gate explicitly says otherwise.
- External analytical engines are outside ENH-E5.

Acceptance targets associated with this Gate:
- AC-G04-001: All six Exploratory Navigation Stages are reachable and use canonical routes.
- AC-G04-002: Profile exposes existing dataset/profile context and preserves Analysis View access required for exploration.
- AC-G04-003: Data Quality displays only quality facts derivable from existing data/profile capability; no unsupported metric is invented.
- AC-G04-004: Distribution, Relationships, Comparison map existing exploratory operations without changing their analytical semantics.
- AC-G04-005: Visualization/Chart controls are embedded in relevant stages and no Visualization navigation stage exists.
- AC-G04-006: Findings reuses existing saved exploratory Result/annotation/linkage semantics; no new persistent Findings model is created.
- AC-G04-007: Exploratory outputs retain non-causal interpretation warnings where applicable.
- AC-G04-008: Existing exploratory regression tests pass.

## 3. Execution Mode decision

Mode: `WORK_PACKAGE`.

Use `06_G04_P00_work_package_plan.md` and all planned Pxx instructions. Package completion does not mean Gate PASS.

## 4. Required implementation semantics

The implementation MUST make the Gate objective true without changing the meaning of protected upstream contracts. Favor additive/refactoring changes that preserve current analysis specs, execution plans, result schemas, and current algorithms unless explicitly required in this Gate.

## 5. Allowed scope

- six Exploratory stage surfaces
- current profile/quality views
- distribution/association/group/time operations
- chart controls inside analytical stages
- saved result/findings projection

## 6. Explicit prohibited scope

- standalone Visualization stage
- new EDA engine/statistical method
- new Findings persistent entity
- causal interpretation of exploratory association

Global prohibitions:
- no assertion weakening/test deletion/skip/xfail solely to obtain green tests;
- no silent requirement/AC change;
- no next-Gate work bundled into this Gate;
- no unapproved schema/dependency/engine expansion.

## 7. Protected passed-Gate contracts

All final-PASS contracts from preceding ENH-E5 Gates; exact SHA/evidence must be read from Current State Control Sheet before execution.

Before coding, read the Current State Control Sheet and record the exact protected Gate evidence identities in the implementation report.

## 8. Transition Debt

NONE planned. Deferred scope is not Transition Debt.

If temporary exceptional behavior becomes unavoidable, stop and request explicit architecture/Human decision; do not invent undocumented debt.

## 9. Schema / migration / API / runtime policy

- DB schema migration: `PROHIBITED unless explicitly amended`.
- AnalysisSpecification/Execution/Result schema change: `PROHIBITED unless explicitly stated by this Gate`.
- Execution lifecycle: preserve existing semantics.
- API changes: additive only where this Gate explicitly requires them.
- Legacy analytical routes: preserve or explicitly normalize; do not silently remove.

## 10. Automated test obligations

- Implement automated evidence for AC-G04-001: All six Exploratory Navigation Stages are reachable and use canonical routes.
- Implement automated evidence for AC-G04-002: Profile exposes existing dataset/profile context and preserves Analysis View access required for exploration.
- Implement automated evidence for AC-G04-003: Data Quality displays only quality facts derivable from existing data/profile capability; no unsupported metric is invented.
- Implement automated evidence for AC-G04-004: Distribution, Relationships, Comparison map existing exploratory operations without changing their analytical semantics.
- Implement automated evidence for AC-G04-005: Visualization/Chart controls are embedded in relevant stages and no Visualization navigation stage exists.
- Implement automated evidence for AC-G04-006: Findings reuses existing saved exploratory Result/annotation/linkage semantics; no new persistent Findings model is created.
- Implement automated evidence for AC-G04-007: Exploratory outputs retain non-causal interpretation warnings where applicable.
- Implement automated evidence for AC-G04-008: Existing exploratory regression tests pass.

Also run focused existing tests for modified modules and regression tests covering all protected upstream contracts impacted by the diff.

## 11. Candidate Assembly

Before `READY_FOR_TEST`:
1. all required implementation scope is complete;
2. all packages, if any, have valid checkpoint reports;
3. unresolved blockers are `NONE`;
4. focused and Gate-wide self-verification is recorded;
5. production/test/migration/dependency diff is reviewed;
6. one Fixed Trial Candidate SHA is recorded in the implementation completion report.

## 12. Coding Agent prohibited work

Coding Agent MUST NOT:
- decide Gate PASS;
- alter 07 Acceptance Criteria;
- treat package completion as partial PASS;
- modify passed-Gate semantics without amendment;
- implement excluded downstream features.

## 13. Required outputs

- implementation completion report for Trial01 (or current Trial)
- Gate-local implementation ledger/detail as required
- package checkpoint/status reports when WORK_PACKAGE
- exact Fixed Trial Candidate SHA
- commands and test evidence
- explicit blocker status

## 14. External reference policy

Source code paths and observed runtime/test output may be referenced as evidence. Normative rules needed for execution are contained in this contract and, in Work Package mode, the assigned Pxx contract.
