# Ariadne ENH-E5 G02 テスト指示書 — Gate Verification Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G02
- Gate title: Predictive Family Recomposition and Compatibility
- Verification contract status: **DRAFT_FOR_REVIEW**
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Acceptance authority

This 07 is the Acceptance Criteria authority after freeze. Package completion, Coding self-check, or `READY_FOR_TEST` is not acceptance evidence.

## 2. Gate objective / acceptance claim

current Predictive workspaceをSetup/Train/Predict/Metrics/Explainability/Model Managementへ再配置し、既存設定項目とgenerated spec/execution semanticsの完全互換を成立させる。

PASS後にdownstreamが依存可能になるcontract:
ユーザーとG05が、新navigation下でもcurrent Predictive capabilityがsemantically unchangedで利用できることへ依存できる。

## 3. Effective verification context

- Test target is the exact Fixed Trial Candidate.
- Navigation Stage and Execution Stage are distinct concepts.
- Existing analytical algorithms/persistence are regression-protected unless this Gate explicitly changes them.
- Deferred/out-of-scope features must not appear as accidental implementation.
- If environment/prerequisite prevents observation, use BLOCKED; do not convert preflight failure into product FAIL automatically.

## 4. Verification inputs

Required:
- current Trial implementation completion report
- Fixed Trial Candidate SHA
- repository status/diff
- package checkpoint chain when applicable
- Current State Control Sheet
- previous passed-Gate evidence for protected regression

If any identity is missing or ambiguous: `BLOCKED_CANDIDATE_IDENTITY`.

## 5. Candidate identity audit — MUST execute first

1. checkout/observe intended candidate;
2. record `git rev-parse HEAD`;
3. record `git status --short`;
4. compare tested repository state to Fixed Trial Candidate SHA;
5. if different, audit diff and prove it is documentation-only/non-semantic or block/fail accordingly.

## 6. Acceptance Criteria

| AC | Criterion | Level | Required evidence |
|---|---|---|---|
| AC-G02-001 | All six Predictive Navigation Stages are reachable and use canonical routes. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G02-002 | Every current visible Predictive control is preserved with same input semantics/defaults unless only relocated. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G02-003 | Generated predictive-analysis-spec/1 hidden/default semantics remain unchanged for equivalent inputs. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G02-004 | Train action still invokes the existing split/prepare/train/evaluate/(explain) workflow; navigation Stage is not mapped 1:1 to execution Stage. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G02-005 | Predict Stage does not introduce standalone scoring; it exposes only existing prediction-bearing outputs/artifacts/results where available and states absence deterministically. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G02-006 | Metrics exposes existing evaluation/error-analysis semantics; Explainability preserves predictive-not-causal warning/meaning. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G02-007 | Model Management is read-only fitted-model/model-card/artifact/lineage scope in E5. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G02-008 | Family/Stage switching does not discard protected unsaved Predictive form values during the active page session. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G02-009 | Existing Predictive regression tests and full relevant suite pass. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |

All Mandatory ACs must PASS for Gate PASS.

## 7. Test Item plan

- `001_candidate_identity` — candidate/repository-state audit
- one or more focused items covering each AC cluster
- protected regression item(s)
- transition-debt audit item
- `999_gate_decision` — reserved final Gate Decision

Each test item records command/input, observed output, evidence path, and PASS/FAIL/BLOCKED result.

## 8. Protected regression

Verify all prior final-PASS Gate contracts that the current diff can affect. Absence of an explicit regression item when affected is a verification defect.

## 9. Transition Debt audit

Expected OPEN debt for this Gate: `NONE`. Confirm no undocumented temporary authority/exception was introduced.

## 10. Test / Audit Agent prohibited work

MUST NOT modify:
- production code
- automated test code
- migration/dependency definitions
- package implementation
- Acceptance Criteria

## 11. Evidence requirements

Evidence must be reproducible and tied to exact candidate identity. Screenshots/manual observation may supplement, not replace, automation where an automated assertion is practical.

## 12. PASS semantics

PASS means this Gate's semantic claim is established for the Fixed Trial Candidate, all mandatory ACs pass, protected regressions pass, no unapproved scope/migration/debt is present, and evidence identities are auditable.

FAIL means product/contract behavior violates a valid AC. BLOCKED means acceptance cannot be determined because prerequisite/candidate/contract ambiguity remains.
