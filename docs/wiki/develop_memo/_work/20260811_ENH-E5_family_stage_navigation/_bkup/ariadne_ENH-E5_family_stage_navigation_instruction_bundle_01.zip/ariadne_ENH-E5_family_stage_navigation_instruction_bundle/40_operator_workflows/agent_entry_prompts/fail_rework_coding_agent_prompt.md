# FAIL Rework Coding Agent Prompt — ENH-E5

Use only after formal Gate FAIL.

1. Preserve original frozen 06/07 and failed candidate evidence.
2. Determine whether Gate contract remains valid.
3. If valid, use approved 08 Remediation Contract and Rxx if present.
4. If Gate claim/AC is wrong, stop for Human-approved 09 Amendment; do not repair by silently changing criteria.
5. Produce a new Trial candidate identity; do not overwrite failed evidence.
