# Logical Data Design — ENH-E5 revised scope

## 1. Persistent data

No new persistent entity is required for navigation.

Existing persisted entities such as AnalysisSpecification, Execution, StageExecution, Result, Artifact, Research Context, Dataset Version and Analysis View retain their current schemas.

## 2. Non-persistent navigation data

```text
FamilyNavigationDescriptor
  family: AnalysisFamily
  label: str
  default_stage_id: str
  stages: ordered tuple[NavigationStageDescriptor]

NavigationStageDescriptor
  stage_id: str
  label: str
  order: int
```

Constraints:
- family unique
- stage_id unique inside family
- exactly one valid default_stage_id per family
- non-empty stages
- deterministic ordering
- no execution-stage lifecycle fields

## 3. Current navigation state

Current Family/Stage is encoded in URL. It is not a DB row and is not added to workspace-state in E5.
