# ENH-E5 Requirements Revision

Document class: Requirement Revision Artifact  
Status: DRAFT_FOR_REVIEW

## 1. Before / After summary

### Before
- analytical workspaces are mixed in a single left navigation axis.
- UI navigation does not expose Family as an independent global context.
- causal discovery/inference and predictive/exploratory workspaces are page/workspace-centric rather than Family-owned Stage-centric.

### After
- analytical navigation has two dimensions: global Family and Family-local Navigation Stage.
- concrete Stage set is capability-owned.
- current Family/Stage is addressable by URL.
- existing analytical behavior remains, but is recomposed into Stage surfaces.

## 2. Revised requirements

| ID | Requirement | Acceptance implication | Primary Gate |
|---|---|---|---|
| E5-REQ-001 | Familyをglobal analytical navigation dimensionとして明示する。 | Top navigationにExploratory/Predictive/Causalが表示され、current Familyが識別できる。 | G01 |
| E5-REQ-002 | StageをFamily-local navigation/work contextとして扱う。 | selected Familyに対応するStageだけがleft sidebarに表示される。 | G01 |
| E5-REQ-003 | Navigation StageをExecution Stageから分離する。 | Navigation descriptorがExecution StageType/StageDefinition/StageExecutionを再利用・継承しない。 | G00 |
| E5-REQ-004 | concrete Stage catalogはCapabilityが所有する。 | 各capability moduleが自Familyのstage set/default/orderを定義し、product layerはgeneric aggregation/validationのみ行う。 | G00 |
| E5-REQ-005 | Family/Stage catalogのcanonical sourceを一つにする。 | backend descriptor APIからcatalogを取得し、frontendに別の完全catalogを重複定義しない。 | G00 |
| E5-REQ-006 | Current Family/Stageをdeep-linkableにする。 | URL `/projects/{project_id}/analysis/{family}/{stage}` でdirect load/back/forwardが成立する。 | G01 |
| E5-REQ-007 | navigation stateをE5では永続化しない。 | Family/Stageをworkspace-state/DB schemaへ追加しない。 | G01 |
| E5-REQ-008 | Predictive既存設定を100%保持する。 | 全visible fieldとspec defaultがinventoryでBefore/After対応し、欠落/semantic changeがない。 | G02 |
| E5-REQ-009 | Predictiveを6 Navigation Stageへ再配置する。 | Setup/Train/Predict/Metrics/Explainability/Model Managementが表示される。 | G02 |
| E5-REQ-010 | Causalを7 Navigation Stageへ再配置する。 | Setup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityが表示される。 | G03 |
| E5-REQ-011 | IdentificationとEstimationを明確に分離する。 | UI/route上で別Stageとなり、識別結果と推定実行が混同されない。 | G03 |
| E5-REQ-012 | Exploratoryを6 analytical-view Stageへ再配置する。 | Profile/Data Quality/Distribution/Relationships/Comparison/Findingsが表示される。 | G04 |
| E5-REQ-013 | Visualizationを独立Stageにしない。 | Chart controls/outputはDistribution/Relationships/Comparison等の内部表現として配置される。 | G04 |
| E5-REQ-014 | Results/Lineageをcross-family global surfaceとして保持する。 | Family切替後も既存cross-analysis result/lineage機能へ到達できる。 | G05 |
| E5-REQ-015 | 既存analytical engineとresult persistence semanticsを変更しない。 | 新engine/dependency/schema migrationなしで既存testが通る。 | G05 |
| E5-REQ-016 | Family/Stage navigationはwizard化しない。 | 任意Stageへ移動でき、operation prerequisiteとnavigation progressionを同一視しない。 | G01 |
| E5-REQ-017 | legacy analytical URLsを互換維持する。 | `/explore`, `/causal`, `/predictive`がdocumented targetへredirect/normalizeされる。 | G01 |

## 3. New invariants

1. `Navigation Stage != Execution Stage`.
2. Family IDs reuse the existing `AnalysisFamily` semantics; UI labels may differ from internal IDs.
3. abstract navigation layer must not encode domain-specific meanings such as Discovery/Train/Estimation.
4. capability owns concrete Stage semantics; product/application layer aggregates generically.
5. Stage count/name may differ by Family.
6. navigation order is not scientific/operational completion order.
7. Predictive existing settings and generated spec semantics are protected compatibility contracts.

## 4. Removed / superseded requirement assumptions

- single sidebar item list as the primary analytical navigation taxonomy — superseded.
- a UI Stage must correspond one-to-one to execution pipeline stage — explicitly rejected.
- all Families should share a common Stage taxonomy — explicitly rejected.

## 5. Deferred requirements

- Overview/Flagship surface
- dedicated Findings/Evidence persistence model
- standalone Predict execution service
- model registry/deployment lifecycle
- external analytical engine adapters
