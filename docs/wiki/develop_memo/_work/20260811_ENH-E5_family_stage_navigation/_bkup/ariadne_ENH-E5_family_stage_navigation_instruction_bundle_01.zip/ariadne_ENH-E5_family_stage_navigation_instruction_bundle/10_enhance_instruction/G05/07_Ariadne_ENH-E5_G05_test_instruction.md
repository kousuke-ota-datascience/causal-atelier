# Ariadne ENH-E5 G05 テスト指示書 — Gate Verification Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G05
- Gate title: Cross-family Convergence and Product Regression
- Verification contract status: **DRAFT_FOR_REVIEW**
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Acceptance authority

This 07 is the Acceptance Criteria authority after freeze. Package completion, Coding self-check, or `READY_FOR_TEST` is not acceptance evidence.

## 2. Gate objective / acceptance claim

3 Familyのnavigation/Stage recomposition後に、project context・Results/Lineage・routing・existing analytical execution/persistenceがcross-familyで一貫することを確立する。

PASS後にdownstreamが依存可能になるcontract:
ENH-E5全体をproduct-level verified contractとして利用・release判断できる。

## 3. Effective verification context

- Test target is the exact Fixed Trial Candidate.
- Navigation Stage and Execution Stage are distinct concepts.
- Existing analytical algorithms/persistence are regression-protected unless this Gate explicitly changes them.
- Deferred/out-of-scope features must not appear as accidental implementation.
- If environment/prerequisite prevents observation, use BLOCKED; do not convert preflight failure into product FAIL automatically.

## 4. Verification inputs

Required:
- current Trial implementation completion report
- Fixed Trial Candidate SHA
- repository status/diff
- package checkpoint chain when applicable
- Current State Control Sheet
- previous passed-Gate evidence for protected regression

If any identity is missing or ambiguous: `BLOCKED_CANDIDATE_IDENTITY`.

## 5. Candidate identity audit — MUST execute first

1. checkout/observe intended candidate;
2. record `git rev-parse HEAD`;
3. record `git status --short`;
4. compare tested repository state to Fixed Trial Candidate SHA;
5. if different, audit diff and prove it is documentation-only/non-semantic or block/fail accordingly.

## 6. Acceptance Criteria

| AC | Criterion | Level | Required evidence |
|---|---|---|---|
| AC-G05-001 | Research Context/Dataset/Analysis View project context remains coherent across Family switching and global workspaces. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G05-002 | Global Results/Lineage still aggregates/navigates existing cross-family results and lineage. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G05-003 | All canonical Family/Stage deep links and legacy mappings work together after G02-G04 changes. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G05-004 | No passed G00-G04 protected contract is silently changed. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G05-005 | No DB schema migration, new analytical engine dependency, Result schema redesign, or navigation persistence was introduced. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G05-006 | Full `uv run pytest -q` passes on the Fixed Trial Candidate. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G05-007 | Available browser/e2e regression suite passes for Family tabs, Stage navigation, direct routes, back/forward, and representative family operations. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G05-008 | Requirements/design/traceability docs match the implemented/verified contract and contain no unresolved placeholders except explicitly permitted evidence identities before PASS. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |

All Mandatory ACs must PASS for Gate PASS.

## 7. Test Item plan

- `001_candidate_identity` — candidate/repository-state audit
- one or more focused items covering each AC cluster
- protected regression item(s)
- transition-debt audit item
- `999_gate_decision` — reserved final Gate Decision

Each test item records command/input, observed output, evidence path, and PASS/FAIL/BLOCKED result.

## 8. Protected regression

Verify all prior final-PASS Gate contracts that the current diff can affect. Absence of an explicit regression item when affected is a verification defect.

## 9. Transition Debt audit

Expected OPEN debt for this Gate: `NONE`. Confirm no undocumented temporary authority/exception was introduced.

## 10. Test / Audit Agent prohibited work

MUST NOT modify:
- production code
- automated test code
- migration/dependency definitions
- package implementation
- Acceptance Criteria

## 11. Evidence requirements

Evidence must be reproducible and tied to exact candidate identity. Screenshots/manual observation may supplement, not replace, automation where an automated assertion is practical.

## 12. PASS semantics

PASS means this Gate's semantic claim is established for the Fixed Trial Candidate, all mandatory ACs pass, protected regressions pass, no unapproved scope/migration/debt is present, and evidence identities are auditable.

FAIL means product/contract behavior violates a valid AC. BLOCKED means acceptance cannot be determined because prerequisite/candidate/contract ambiguity remains.
