# Agent entry prompts — ENH-E5

Use these prompts only after the target Gate 06/07 are FROZEN and all identity variables are resolved. No unresolved template variable is allowed at execution.
