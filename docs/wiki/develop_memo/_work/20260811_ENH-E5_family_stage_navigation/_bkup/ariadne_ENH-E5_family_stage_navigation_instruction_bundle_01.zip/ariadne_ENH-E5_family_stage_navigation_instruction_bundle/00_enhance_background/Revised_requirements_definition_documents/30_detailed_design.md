# Detailed Design — ENH-E5 revised scope

## Proposed code placement

### Domain / application
- `src/ariadne/product/domain/navigation.py` — generic immutable descriptor types and validation primitives.
- `src/ariadne/product/application/navigation_service.py` — aggregate capability descriptors; no Family-specific stage literals.

### Capability ownership
- `src/ariadne/capabilities/exploratory/navigation.py`
- `src/ariadne/capabilities/predictive/navigation.py`
- `src/ariadne/capabilities/causal/navigation.py`

### Web API
- `src/ariadne/interfaces/web_api/routers/navigation.py`
- `src/ariadne/interfaces/web_api/schemas/navigation.py`
- register router in existing web API app/router composition.

### Frontend
- `frontend/index.html` — global Family tabs, Family-local stage sidebar/panels.
- `frontend/app.js` — descriptor loading, route parser/serializer, history handling, stage rendering activation, legacy normalization.
- `frontend/styles.css` — top tab + stage sidebar layout and active states.

## Frontend renderer registry

Frontend may contain a sparse implementation binding such as:

```text
(EXPLORATORY, profile) -> existing explore profile surface
(PREDICTIVE, setup) -> existing predictive form surface
(CAUSAL, identification) -> existing identification surface
```

This binding is allowed because it maps semantic IDs to frontend implementation. It MUST NOT duplicate labels/order/default-stage catalog.

## Route parser

Canonical route:
`/projects/{project_id}/analysis/{family_slug}/{stage_slug}`

Legacy mapping is explicit and one-way. Unknown new routes do not get heuristic fallback.

## Test layers

- domain unit tests for descriptor invariants
- application/API tests for catalog response
- frontend/browser tests for navigation state/history/deep link
- family-specific regression tests
- full `uv run pytest -q`
- existing browser e2e suite where available
