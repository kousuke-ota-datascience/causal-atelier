# G03 — Causal Family Recomposition

- Semantic claim: current Causal Discovery/Inference surfacesをSetup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityへ再配置し、IdentificationとEstimationの責務分離を明示する。
- Execution mode: `WORK_PACKAGE`
- Contract status: `DRAFT_FOR_REVIEW` until approval + baseline resolution.
