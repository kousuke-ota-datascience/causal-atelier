# ENH-E5 Gate Decomposition Record

Document class: Architecture / Planning Artifact  
Status: DRAFT_FOR_REVIEW

## Decomposition principle

Gate = independent acceptance boundary with a downstream-usable semantic result. Coding size is handled by Work Packages.

## Gates

| Gate | What becomes true on PASS | Why downstream can depend on it |
|---|---|---|
| G00 | FamilyとNavigation Stageのapplication contractをExecution Stageから独立して成立させ、capability-owned canonical stage catalogとread APIを提供する。 | G01以降が、stable Family ID / stage ID / order / default Stage / catalog APIへ依存できる。 |
| G01 | canonical catalogを利用してtop Family tabs + Family-local Stage sidebarを成立させ、URL/deep link/history/legacy route compatibilityを確立する。 | Family-specific G02-G04が同一navigation shell上へStage contentを安全に配置できる。 |
| G02 | current Predictive workspaceをSetup/Train/Predict/Metrics/Explainability/Model Managementへ再配置し、既存設定項目とgenerated spec/execution semanticsの完全互換を成立させる。 | ユーザーとG05が、新navigation下でもcurrent Predictive capabilityがsemantically unchangedで利用できることへ依存できる。 |
| G03 | current Causal Discovery/Inference surfacesをSetup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityへ再配置し、IdentificationとEstimationの責務分離を明示する。 | ユーザーとG05が、causal design/execution/resultsをdistinct Stage contextで利用しつつ既存causal semanticsへ依存できる。 |
| G04 | current Explore & Visualize capabilityをProfile/Data Quality/Distribution/Relationships/Comparison/Findingsへ再配置し、visualizationをanalytical Stageではなく各Stageの表現手段として位置づける。 | ユーザーとG05が、EDAを探索観点別にnavigationしつつ既存exploratory resultsを失わず利用できる。 |
| G05 | 3 Familyのnavigation/Stage recomposition後に、project context・Results/Lineage・routing・existing analytical execution/persistenceがcross-familyで一貫することを確立する。 | ENH-E5全体をproduct-level verified contractとして利用・release判断できる。 |

## Dependency DAG

```text
G00 -> G01 -> G02 ----\
             G03 -----+-> G05
             G04 ----/
```

G02/G03/G04 all depend on G01. After G01 PASS they are semantically independent family recomposition contracts; execution order may be G02 -> G03 -> G04 for operational simplicity. G05 depends on all three.

## Work Package rationale

- G00: bounded domain/API contract; SINGLE_EXECUTION.
- G01: route/state/UI/history spans separable coding units; WORK_PACKAGE.
- G02: compatibility inventory, UI recomposition, regression are execution units under one semantic claim; WORK_PACKAGE.
- G03: mapping, Identification/Estimation separation, regression; WORK_PACKAGE.
- G04: mapping, visualization/findings composition, regression; WORK_PACKAGE.
- G05: convergence/regression acceptance over already-implemented contracts; SINGLE_EXECUTION.

## Non-gates

- "backend work" and "frontend work" are not Gates because they do not independently establish product semantics.
- individual Stage implementation is not a Gate because a Family is not downstream-usable until the complete Family contract is coherent.
