# ENH-E5 Enhancement Concept Approval Record

Document class: Planning / Approval Artifact  
Decision status: **PENDING_HUMAN_APPROVAL**  
Prepared: `2026-08-11T11:12:00+09:00`

## 1. Proposed approved scope

- Family × Navigation Stage application model
- top Family tabs + Family-local left Stage navigation
- capability-owned concrete stage catalog
- Navigation Stage / Execution Stage separation
- backend descriptor API
- URL canonical current Family/Stage
- legacy route compatibility
- Family-specific UI recomposition for Exploratory/Predictive/Causal
- Predictive existing settings and semantics 100% preservation
- cross-family Results/Lineage compatibility

## 2. Proposed approval conditions

1. `BASELINE_FULL_SHA` must be resolved before G00 freeze.
2. Predictive inventory must cover visible form fields **and** generated `predictive-analysis-spec/1` defaults.
3. No DB migration may be introduced unless architecture contract is explicitly amended by Human approval.
4. No new analytical engine/library may be added.
5. No Navigation Stage may be implemented as an alias/subclass of Execution `StageType`.

## 3. Explicitly not approved in this enhancement

- LightGBM / DoWhy / EconML
- standalone batch/online scoring API
- Model Management write lifecycle/deployment
- Overview/Flagship
- Analysis Management
- new common Evidence/Findings domain
- Result schema flattening/replacement

## 4. Human owner decision

`PENDING_HUMAN_APPROVAL`

To approve, Human owner should change this section to:

- Decision: `APPROVED`
- Approved by: `<identity>`
- Approved at: `<ISO8601>`
- Conditions/additional exclusions: `NONE` or explicit text

Draft creation instruction alone is not interpreted as Gate PASS or architecture approval.
