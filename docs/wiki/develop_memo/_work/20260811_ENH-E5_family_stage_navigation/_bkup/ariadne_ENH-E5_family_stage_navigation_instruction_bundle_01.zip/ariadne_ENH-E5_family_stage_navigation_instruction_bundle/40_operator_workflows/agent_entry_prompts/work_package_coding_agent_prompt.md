# Work Package Coding Agent Prompt — ENH-E5

Input variables: `GATE_ID`, `TRIAL_NO`, `PACKAGE_ID`.

1. Verify target Gate is WORK_PACKAGE and frozen P00 exists.
2. Select exactly one frozen `06_<GATE_ID>_<PACKAGE_ID>_*.md`.
3. Verify package dependencies/checkpoint identities.
4. Execute only package scope and focused verification.
5. Create/update package checkpoint/status report and record checkpoint SHA.
6. Do not assemble Fixed Trial Candidate unless explicitly acting as candidate assembly step after all packages.
7. Package complete != Gate PASS.
