# ENH-E5 Preflight Instruction

Document class: Operator Artifact

## Purpose

Resolve planning UNKNOWNs and prove the repository/test baseline before G00 contract freeze.

## Commands

```bash
set -euo pipefail

git branch --show-current
git rev-parse HEAD
git status --short

git log -1 --oneline
uv run pytest -q
```

If the full suite is too environment-dependent, record exact blocker and run the repository's documented focused smoke/readiness path; do not claim PASS without evidence.

## Required checks

1. branch equals `feature/ariadne_mvp_e5`.
2. local full SHA equals pinned planning baseline `46122c68333df03680b97c253a7b5d32bf9393e7`.
3. unexpected uncommitted production/test/migration changes are absent or explicitly accounted for.
4. current test baseline is known.
5. architecture discovery observations are reconfirmed against that exact SHA.
6. no existing navigation descriptor/API makes the proposed G00 design duplicative.

## Result handling

- all prerequisites established -> update Control Sheet with observed local/test/migration/runtime facts; Human may freeze G00.
- branch/SHA ambiguity -> `BLOCKED_BASELINE_IDENTITY`.
- architecture contradiction -> `BLOCKED_ARCHITECTURE_REVIEW`.
- environment prevents baseline test -> `BLOCKED_PREFLIGHT_ENVIRONMENT`; do not label product FAIL.
