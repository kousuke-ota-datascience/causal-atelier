# Ariadne ENH-E5 G01 テスト指示書 — Gate Verification Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G01
- Gate title: URL-driven Family / Stage Navigation Shell
- Verification contract status: **DRAFT_FOR_REVIEW**
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Acceptance authority

This 07 is the Acceptance Criteria authority after freeze. Package completion, Coding self-check, or `READY_FOR_TEST` is not acceptance evidence.

## 2. Gate objective / acceptance claim

canonical catalogを利用してtop Family tabs + Family-local Stage sidebarを成立させ、URL/deep link/history/legacy route compatibilityを確立する。

PASS後にdownstreamが依存可能になるcontract:
Family-specific G02-G04が同一navigation shell上へStage contentを安全に配置できる。

## 3. Effective verification context

- Test target is the exact Fixed Trial Candidate.
- Navigation Stage and Execution Stage are distinct concepts.
- Existing analytical algorithms/persistence are regression-protected unless this Gate explicitly changes them.
- Deferred/out-of-scope features must not appear as accidental implementation.
- If environment/prerequisite prevents observation, use BLOCKED; do not convert preflight failure into product FAIL automatically.

## 4. Verification inputs

Required:
- current Trial implementation completion report
- Fixed Trial Candidate SHA
- repository status/diff
- package checkpoint chain when applicable
- Current State Control Sheet
- previous passed-Gate evidence for protected regression

If any identity is missing or ambiguous: `BLOCKED_CANDIDATE_IDENTITY`.

## 5. Candidate identity audit — MUST execute first

1. checkout/observe intended candidate;
2. record `git rev-parse HEAD`;
3. record `git status --short`;
4. compare tested repository state to Fixed Trial Candidate SHA;
5. if different, audit diff and prove it is documentation-only/non-semantic or block/fail accordingly.

## 6. Acceptance Criteria

| AC | Criterion | Level | Required evidence |
|---|---|---|---|
| AC-G01-001 | Top tabs show exactly Exploratory/Predictive/Causal from backend catalog and visually identify current Family. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G01-002 | Left sidebar shows only stages owned by current Family and identifies current Stage. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G01-003 | Canonical URL is /projects/{id}/analysis/{family}/{stage}; direct load and browser back/forward restore state. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G01-004 | Family switch navigates to the target Family declared default Stage; no last-stage persistence is used. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G01-005 | Legacy /explore, /causal, /predictive routes normalize to documented canonical targets. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G01-006 | Management, Context, Data, Results/Lineage remain global project surfaces outside Family tabs. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G01-007 | Unknown Family/Stage is not silently reinterpreted; explicit navigation error/valid alternatives are provided. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G01-008 | Stage navigation itself is non-sequential and does not enforce wizard completion. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |

All Mandatory ACs must PASS for Gate PASS.

## 7. Test Item plan

- `001_candidate_identity` — candidate/repository-state audit
- one or more focused items covering each AC cluster
- protected regression item(s)
- transition-debt audit item
- `999_gate_decision` — reserved final Gate Decision

Each test item records command/input, observed output, evidence path, and PASS/FAIL/BLOCKED result.

## 8. Protected regression

Verify all prior final-PASS Gate contracts that the current diff can affect. Absence of an explicit regression item when affected is a verification defect.

## 9. Transition Debt audit

Expected OPEN debt for this Gate: `NONE`. Confirm no undocumented temporary authority/exception was introduced.

## 10. Test / Audit Agent prohibited work

MUST NOT modify:
- production code
- automated test code
- migration/dependency definitions
- package implementation
- Acceptance Criteria

## 11. Evidence requirements

Evidence must be reproducible and tied to exact candidate identity. Screenshots/manual observation may supplement, not replace, automation where an automated assertion is practical.

## 12. PASS semantics

PASS means this Gate's semantic claim is established for the Fixed Trial Candidate, all mandatory ACs pass, protected regressions pass, no unapproved scope/migration/debt is present, and evidence identities are auditable.

FAIL means product/contract behavior violates a valid AC. BLOCKED means acceptance cannot be determined because prerequisite/candidate/contract ambiguity remains.
