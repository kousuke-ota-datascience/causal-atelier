# ENH-E5 Design Revision

Document class: Design Revision Artifact  
Status: DRAFT_FOR_REVIEW

## 1. Architecture decisions

### DR-01 — Reuse `AnalysisFamily` as Family identity

**Decision:** existing product-domain `AnalysisFamily` values `EXPLORATORY`, `CAUSAL`, `PREDICTIVE` are the internal Family IDs.

**Reason:** current code already binds planners/specifications/results to these analytical families. Creating a second Family identity would introduce unnecessary translation.

**Alternative rejected:** frontend-only string catalog disconnected from product domain.

### DR-02 — Introduce a distinct Navigation descriptor model

Target generic types:

```text
NavigationStageDescriptor
- stage_id
- label
- order

FamilyNavigationDescriptor
- family: AnalysisFamily
- label
- default_stage_id
- stages: tuple[NavigationStageDescriptor, ...]
```

The model MUST NOT contain execution dependencies, input/output contracts, runner IDs, execution status or attempt lifecycle.

### DR-03 — Capability-owned concrete catalog

Proposed ownership:

```text
src/ariadne/capabilities/exploratory/navigation.py
src/ariadne/capabilities/predictive/navigation.py
src/ariadne/capabilities/causal/navigation.py
```

Each capability exports one immutable `FamilyNavigationDescriptor`. Product/application code only validates and aggregates them.

### DR-04 — Backend descriptor API is canonical catalog source

Target endpoint:

```http
GET /api/v1/navigation/analysis
```

Response schema version: `analysis-navigation/1`.

Frontend may maintain a renderer registry keyed by `(family_id, stage_id)` to bind semantic IDs to DOM/rendering code, but MUST NOT maintain a second complete stage order/label/default catalog.

### DR-05 — URL is canonical current Family/Stage state

Target canonical route:

```text
/projects/{project_id}/analysis/{family_slug}/{stage_slug}
```

Canonical family slugs:
- `exploratory`
- `predictive`
- `causal`

E5 does not persist last Family/Stage in DB or `/workspace-state`.

### DR-06 — Global project surfaces stay outside Family

The following remain global project-level surfaces:
- Project Management
- Research Context
- Project / Data
- Results / Lineage

Top Family tabs contain analytical Families only. `Overview` is not introduced in E5.

### DR-07 — Legacy analytical routes normalize to new routes

- `/projects/{id}/explore` -> `/projects/{id}/analysis/exploratory/profile`
- `/projects/{id}/causal` -> `/projects/{id}/analysis/causal/discovery`
- `/projects/{id}/predictive` -> `/projects/{id}/analysis/predictive/setup`

`context`, `data`, `results` remain global routes.

### DR-08 — No persistence/schema migration

Navigation catalog is code-defined and read-only. Current Family/Stage is URL state. Existing AnalysisSpecification/Execution/Result/Artifact persistence remains unchanged.

If implementation discovers a genuine need for schema migration, stop as `BLOCKED_CONTRACT_AMBIGUITY`; do not add migration without architecture amendment.

## 2. Family stage mapping

### Exploratory

| Stage | Current capability mapping | E5 semantic rule |
|---|---|---|
| Profile | dataset/profile/explore profile | dataset overview; can host Analysis View context creation/selection where needed |
| Data Quality | existing profile/quality observations | render only facts already supported; no new quality engine |
| Distribution | DISTRIBUTION + relevant chart controls | visualization is an expression mechanism |
| Relationships | ASSOCIATION + relevant charts | no causal interpretation |
| Comparison | GROUP_SUMMARY / TIME_TREND + relevant charts | group/segment/cohort comparison |
| Findings | saved exploratory Results and existing annotation/linkage | no new Findings entity |

### Predictive

| Stage | Current capability mapping | E5 semantic rule |
|---|---|---|
| Setup | all current Predictive form fields/specification | **all existing fields retained** |
| Train | split validation + current full workflow launch/status | execution pipeline remains existing split/prepare/train/evaluate/(explain) |
| Predict | existing prediction-bearing output/artifact inspection if available | no standalone scoring execution added |
| Metrics | Evaluation + Error Analysis result surfaces | no metric engine change |
| Explainability | existing Explanation result surfaces | predictive explanation remains non-causal |
| Model Management | fitted model/model card/artifact/lineage read-only surface | no registry CRUD/deployment lifecycle |

### Causal

| Stage | Current capability mapping | E5 semantic rule |
|---|---|---|
| Setup | dataset/view/population/comparator/treatment/outcome/unit/time/window/estimand/assumptions | design context |
| Discovery | current causal discovery/graph candidate/direct graph registration | optional/non-sequential |
| Identification | fixed graph/strategy/adjustment/identification/data eligibility | separate from estimation |
| Estimation | estimator selection + allowed estimation execution/revision | current estimators only |
| Effects | treatment-effect result / comparison | result consumption |
| Diagnostics | eligibility + estimation diagnostics | validity checks |
| Sensitivity | refutation + sensitivity | current methods only |

## 3. Predictive compatibility inventory — protected target

Visible current controls that MUST remain representable:

- Active Research Context
- Dataset Version
- Analysis View
- Task Type
- Prediction unit
- Target column
- Prediction time
- Horizon
- Intended use
- Deployment population
- Feature columns
- Excluded columns
- Split strategy
- Seed
- Train ratio
- Validation ratio
- Test ratio
- Explanation method
- Explanation sample size
- Local explanations flag

Generated `predictive-analysis-spec/1` semantics that MUST NOT silently change:

- feature availability cutoff = `PREDICTION_TIME`
- split strategy semantics and ratios/seed
- preprocessing: TRAIN fit, MEAN numeric imputation, numeric scaling, ONE_HOT categorical encoding
- model IDs: logistic_regression.v1 / linear_regression.v1 with current parameters
- tuning partitions: TRAIN + VALIDATION
- primary metric: ROC_AUC or RMSE according to current task type
- explanation dataset = TEST, sampling = FIRST_N, existing explanation method/local flag

## 4. UI state handling

Family/Stage navigation MUST change visibility/routing without discarding unsaved field values in the current analytical workspace. Preferred implementation is to keep stage DOM/forms mounted and switch presentation; if refactoring renders/unmounts panels, an explicit frontend draft state must preserve all protected fields.

## 5. Result model decision

Current generic Result envelope is retained. E5 does not introduce a new `AnalysisResult` hierarchy or flatten predictive metrics/causal effects/exploratory findings into one scalar schema.

## 6. Migration / compatibility

- DB migration: `N/A` for target design.
- API migration: additive read endpoint only.
- route compatibility: legacy analytical routes normalized/redirected.
- result/analysis spec schema: unchanged.
- execution stage contracts: unchanged.
