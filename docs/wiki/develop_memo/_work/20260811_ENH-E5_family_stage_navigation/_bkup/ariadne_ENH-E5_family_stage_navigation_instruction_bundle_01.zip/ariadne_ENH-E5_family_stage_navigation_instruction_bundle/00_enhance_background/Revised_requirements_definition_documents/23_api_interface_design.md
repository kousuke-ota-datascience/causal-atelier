# API Interface Design — ENH-E5 revised scope

## GET /api/v1/navigation/analysis

Purpose: frontendへcanonical analytical Family/Navigation Stage catalogを提供するread-only endpoint。

### Response 200

```json
{
  "schema_version": "analysis-navigation/1",
  "families": [
    {
      "id": "EXPLORATORY",
      "slug": "exploratory",
      "label": "Exploratory",
      "default_stage_id": "profile",
      "stages": [
        {"id": "profile", "label": "Profile", "order": 10}
      ]
    }
  ]
}
```

### Contract

- order is deterministic.
- all three supported AnalysisFamily values are returned.
- response is read-only and project-independent in E5.
- endpoint does not expose Execution `StageType`, dependency DAG, input/output contracts, runtime status or runner IDs.
- no write endpoint is introduced.

### Compatibility

Additive endpoint. Existing APIs remain unchanged.
