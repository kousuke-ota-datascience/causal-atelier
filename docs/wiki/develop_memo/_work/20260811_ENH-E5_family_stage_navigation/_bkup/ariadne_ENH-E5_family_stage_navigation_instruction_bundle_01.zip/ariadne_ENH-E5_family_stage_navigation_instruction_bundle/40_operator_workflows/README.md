# 40_operator_workflows — ENH-E5

This enhancement changes authority/ownership of navigation semantics and canonical source of Family/Stage catalog, so architecture review is mandatory before implementation contract freeze.

Subdirectories:
- `architecture_review/`
- `preflight/`
- `agent_entry_prompts/`
- `controlled_runbook/`
