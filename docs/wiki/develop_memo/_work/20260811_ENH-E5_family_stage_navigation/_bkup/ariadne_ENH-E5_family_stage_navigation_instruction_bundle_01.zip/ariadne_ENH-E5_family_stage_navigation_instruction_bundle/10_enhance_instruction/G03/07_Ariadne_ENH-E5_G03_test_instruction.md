# Ariadne ENH-E5 G03 テスト指示書 — Gate Verification Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G03
- Gate title: Causal Family Recomposition
- Verification contract status: **DRAFT_FOR_REVIEW**
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Acceptance authority

This 07 is the Acceptance Criteria authority after freeze. Package completion, Coding self-check, or `READY_FOR_TEST` is not acceptance evidence.

## 2. Gate objective / acceptance claim

current Causal Discovery/Inference surfacesをSetup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityへ再配置し、IdentificationとEstimationの責務分離を明示する。

PASS後にdownstreamが依存可能になるcontract:
ユーザーとG05が、causal design/execution/resultsをdistinct Stage contextで利用しつつ既存causal semanticsへ依存できる。

## 3. Effective verification context

- Test target is the exact Fixed Trial Candidate.
- Navigation Stage and Execution Stage are distinct concepts.
- Existing analytical algorithms/persistence are regression-protected unless this Gate explicitly changes them.
- Deferred/out-of-scope features must not appear as accidental implementation.
- If environment/prerequisite prevents observation, use BLOCKED; do not convert preflight failure into product FAIL automatically.

## 4. Verification inputs

Required:
- current Trial implementation completion report
- Fixed Trial Candidate SHA
- repository status/diff
- package checkpoint chain when applicable
- Current State Control Sheet
- previous passed-Gate evidence for protected regression

If any identity is missing or ambiguous: `BLOCKED_CANDIDATE_IDENTITY`.

## 5. Candidate identity audit — MUST execute first

1. checkout/observe intended candidate;
2. record `git rev-parse HEAD`;
3. record `git status --short`;
4. compare tested repository state to Fixed Trial Candidate SHA;
5. if different, audit diff and prove it is documentation-only/non-semantic or block/fail accordingly.

## 6. Acceptance Criteria

| AC | Criterion | Level | Required evidence |
|---|---|---|---|
| AC-G03-001 | All seven Causal Navigation Stages are reachable and use canonical routes. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G03-002 | Discovery retains current graph discovery/candidate/direct-registration operations. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G03-003 | Identification has its own route/surface and contains identification strategy/adjustment/eligibility result context separate from Estimation. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G03-004 | Estimation retains current estimator selection, warning/revision rules and execution semantics without new estimators. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G03-005 | Effects presents treatment-effect result/compare semantics without being conflated with estimation configuration. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G03-006 | Diagnostics preserves existing eligibility/estimation diagnostics. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G03-007 | Sensitivity preserves current Refutation and Sensitivity operations/methods. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G03-008 | Navigation is non-sequential; operation prerequisites may block an action but not Stage navigation itself. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G03-009 | Existing causal regression tests pass. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |

All Mandatory ACs must PASS for Gate PASS.

## 7. Test Item plan

- `001_candidate_identity` — candidate/repository-state audit
- one or more focused items covering each AC cluster
- protected regression item(s)
- transition-debt audit item
- `999_gate_decision` — reserved final Gate Decision

Each test item records command/input, observed output, evidence path, and PASS/FAIL/BLOCKED result.

## 8. Protected regression

Verify all prior final-PASS Gate contracts that the current diff can affect. Absence of an explicit regression item when affected is a verification defect.

## 9. Transition Debt audit

Expected OPEN debt for this Gate: `NONE`. Confirm no undocumented temporary authority/exception was introduced.

## 10. Test / Audit Agent prohibited work

MUST NOT modify:
- production code
- automated test code
- migration/dependency definitions
- package implementation
- Acceptance Criteria

## 11. Evidence requirements

Evidence must be reproducible and tied to exact candidate identity. Screenshots/manual observation may supplement, not replace, automation where an automated assertion is practical.

## 12. PASS semantics

PASS means this Gate's semantic claim is established for the Fixed Trial Candidate, all mandatory ACs pass, protected regressions pass, no unapproved scope/migration/debt is present, and evidence identities are auditable.

FAIL means product/contract behavior violates a valid AC. BLOCKED means acceptance cannot be determined because prerequisite/candidate/contract ambiguity remains.
