# ENH-E5 Architecture Discovery Prompt

Document class: Operator Artifact

## Objective

Confirm the current `feature/ariadne_mvp_e5` implementation surfaces relevant to Family/Navigation Stage ownership before G00 freeze.

## Required observations

### Domain / workflow
Inspect:
- `src/ariadne/product/domain/enums.py` — AnalysisFamily
- `src/ariadne/product/domain/execution_plan.py` — StageType / StageDefinition
- `src/ariadne/product/domain/stage_execution.py` — StageExecution lifecycle
- `src/ariadne/product/workflow/` — planner/runner abstractions
- `src/ariadne/capabilities/{exploratory,predictive,causal}/`

Questions:
1. Is `AnalysisFamily` still exactly EXPLORATORY/CAUSAL/PREDICTIVE?
2. Are execution Stage abstractions generic and lifecycle-oriented?
3. Do capability planners own concrete execution plan stage definitions?
4. Is there any existing navigation descriptor model that would make the target design duplicative?

### Frontend
Inspect:
- `frontend/index.html`
- `frontend/app.js`
- `frontend/styles.css`

Inventory:
- all current sidebar workspaces/routes;
- current analytical route parsing/history behavior;
- workspace-state fields;
- all Predictive visible controls;
- all Causal Discovery/Inference/Refutation/Sensitivity controls/results;
- all Explore operations/chart/saved-result surfaces.

### Persistence/API
Confirm whether Family/Stage navigation is currently persisted anywhere and whether a descriptor endpoint already exists.

## Known planning observations to verify, not blindly trust

- AnalysisFamily values exist.
- Execution `StageType`/`StageDefinition`/`StageExecution` exist separately.
- frontend currently mixes global and analytical navigation in one sidebar.
- `/workspace-state` appears to persist research context/dataset/view, not Family/Stage.
- Predictive full plan uses execution stages split/prepare/train/evaluate/(explain), demonstrating non-1:1 mapping to desired Navigation Stages.

## Required output

Record:
- confirm exact local baseline SHA equals `46122c68333df03680b97c253a7b5d32bf9393e7`;
- file/path inventory;
- contradictions vs known observations;
- architecture blockers;
- whether target ADR can be approved unchanged.

If any ownership/persistence fact differs materially, mark `BLOCKED_ARCHITECTURE_REVIEW` and revise ADR before G00 freeze.
