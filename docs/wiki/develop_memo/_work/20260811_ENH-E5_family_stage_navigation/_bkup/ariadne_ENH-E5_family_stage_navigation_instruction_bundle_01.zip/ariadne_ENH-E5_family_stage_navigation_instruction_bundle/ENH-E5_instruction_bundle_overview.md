# ENH-E5 Enhancement Concept and Requirement Revision Plan

Document class: Planning / Background Artifact  
Status: DRAFT_FOR_REVIEW

## 1. Problem

現行UIではanalytical Familyとworkflow/view contextに相当するnavigation itemが同じleft sidebarへ混在しており、Ariadneの分析能力を「複数のanalytical perspective」として扱うapplication modelがUI/route/capability ownershipに明示されていない。

またbackendにはgeneric Execution Stage abstractionがあるため、UI上のStageをそのままExecution Stageへ流用すると、navigation concernとruntime execution lifecycleが混線するリスクがある。

## 2. Objective

Ariadneのanalytical capabilityを `Family -> Navigation Stage*` として再構成し、Exploratory / Predictive / Causalをfirst-classなanalytical contextとして横断できるnavigation architectureを確立する。

## 3. Target outcome

- 上部横タブに`Exploratory / Predictive / Causal`を常時表示する。
- 左sidebarはcurrent Familyが提供するNavigation Stageだけを表示する。
- capabilityがconcrete Stage catalogを所有する。
- URLでCurrent Family / Stageを表現し、deep link / browser historyを成立させる。
- current predictive configuration/semanticsを完全保持する。
- current causal/exploratory operationsをStageへ再配置し、機能欠落を発生させない。

## 4. In scope

### Application / architecture
- Family/Navigation Stage descriptor model
- capability-owned stage definition
- descriptor read API
- frontend Family/Stage navigation
- URL route / deep link / browser history
- legacy analytical routes compatibility

### Family stage set

Exploratory:
`Profile`, `Data Quality`, `Distribution`, `Relationships`, `Comparison`, `Findings`

Predictive:
`Setup`, `Train`, `Predict`, `Metrics`, `Explainability`, `Model Management`

Causal:
`Setup`, `Discovery`, `Identification`, `Estimation`, `Effects`, `Diagnostics`, `Sensitivity`

### Compatibility
- Predictive existing configuration fields 100% preservation
- current execution spec defaults/semantics preservation
- current Results / Lineage cross-family behavior preservation
- current Research Context / Dataset / Analysis View semantics preservation

## 5. Explicit out of scope

- LightGBM adapter
- DoWhy adapter
- EconML estimator
- new standalone Predict execution engine/scoring service
- model registry/deployment lifecycle CRUD
- Causal Analysis Management Stage
- Overview/Flagship top-level workspace
- new Findings/Evidence persistent domain model
- AnalysisResult/Result schema redesign
- navigation state DB persistence
- forced common Stage taxonomy across Families
- strict wizard/sequential navigation

## 6. Expected requirement/design impact

High impact:
- information architecture
- frontend route/state model
- capability ownership contract
- API descriptor contract

Medium impact:
- family-specific UI composition
- test/e2e matrix

Expected no-change:
- analytical algorithms
- execution lifecycle semantics
- persistent analysis/result schemas
- migration schema

## 7. Initial Gate decomposition

| Gate | PASS semantic claim |
|---|---|
| G00 | Family/Navigation Stage contract and capability-owned catalog can be relied on independently from Execution Stage. |
| G01 | Product navigation can be driven by Family/Stage URL and catalog while preserving global workspaces and legacy links. |
| G02 | Predictive capability is usable through six Navigation Stages with full existing configuration/execution compatibility. |
| G03 | Causal capability is usable through seven Navigation Stages with Identification and Estimation explicitly separated. |
| G04 | Exploratory capability is usable through six analytical-view Stages without a standalone Visualization Stage. |
| G05 | Cross-family context/results continuity and full regression protection are established for the completed navigation model. |

## 8. Main risks

1. **Semantic collision:** Navigation Stage accidentally reuses Execution `StageType`.
2. **Predictive regression:** visible fields are retained but hidden spec defaults change.
3. **State regression:** stage switching loses draft form values/context.
4. **Routing regression:** browser back/forward or direct URL bypasses expected workspace state.
5. **Scope creep:** new analytical engines or result-domain redesign get mixed into navigation enhancement.

## 9. Required decision before coding

- Human approval of scope and target architecture.
- full branch baseline SHA resolution.
- G00 06/07 freeze.


---

# ENH-E5 Requirements Revision

Document class: Requirement Revision Artifact  
Status: DRAFT_FOR_REVIEW

## 1. Before / After summary

### Before
- analytical workspaces are mixed in a single left navigation axis.
- UI navigation does not expose Family as an independent global context.
- causal discovery/inference and predictive/exploratory workspaces are page/workspace-centric rather than Family-owned Stage-centric.

### After
- analytical navigation has two dimensions: global Family and Family-local Navigation Stage.
- concrete Stage set is capability-owned.
- current Family/Stage is addressable by URL.
- existing analytical behavior remains, but is recomposed into Stage surfaces.

## 2. Revised requirements

| ID | Requirement | Acceptance implication | Primary Gate |
|---|---|---|---|
| E5-REQ-001 | Familyをglobal analytical navigation dimensionとして明示する。 | Top navigationにExploratory/Predictive/Causalが表示され、current Familyが識別できる。 | G01 |
| E5-REQ-002 | StageをFamily-local navigation/work contextとして扱う。 | selected Familyに対応するStageだけがleft sidebarに表示される。 | G01 |
| E5-REQ-003 | Navigation StageをExecution Stageから分離する。 | Navigation descriptorがExecution StageType/StageDefinition/StageExecutionを再利用・継承しない。 | G00 |
| E5-REQ-004 | concrete Stage catalogはCapabilityが所有する。 | 各capability moduleが自Familyのstage set/default/orderを定義し、product layerはgeneric aggregation/validationのみ行う。 | G00 |
| E5-REQ-005 | Family/Stage catalogのcanonical sourceを一つにする。 | backend descriptor APIからcatalogを取得し、frontendに別の完全catalogを重複定義しない。 | G00 |
| E5-REQ-006 | Current Family/Stageをdeep-linkableにする。 | URL `/projects/{project_id}/analysis/{family}/{stage}` でdirect load/back/forwardが成立する。 | G01 |
| E5-REQ-007 | navigation stateをE5では永続化しない。 | Family/Stageをworkspace-state/DB schemaへ追加しない。 | G01 |
| E5-REQ-008 | Predictive既存設定を100%保持する。 | 全visible fieldとspec defaultがinventoryでBefore/After対応し、欠落/semantic changeがない。 | G02 |
| E5-REQ-009 | Predictiveを6 Navigation Stageへ再配置する。 | Setup/Train/Predict/Metrics/Explainability/Model Managementが表示される。 | G02 |
| E5-REQ-010 | Causalを7 Navigation Stageへ再配置する。 | Setup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityが表示される。 | G03 |
| E5-REQ-011 | IdentificationとEstimationを明確に分離する。 | UI/route上で別Stageとなり、識別結果と推定実行が混同されない。 | G03 |
| E5-REQ-012 | Exploratoryを6 analytical-view Stageへ再配置する。 | Profile/Data Quality/Distribution/Relationships/Comparison/Findingsが表示される。 | G04 |
| E5-REQ-013 | Visualizationを独立Stageにしない。 | Chart controls/outputはDistribution/Relationships/Comparison等の内部表現として配置される。 | G04 |
| E5-REQ-014 | Results/Lineageをcross-family global surfaceとして保持する。 | Family切替後も既存cross-analysis result/lineage機能へ到達できる。 | G05 |
| E5-REQ-015 | 既存analytical engineとresult persistence semanticsを変更しない。 | 新engine/dependency/schema migrationなしで既存testが通る。 | G05 |
| E5-REQ-016 | Family/Stage navigationはwizard化しない。 | 任意Stageへ移動でき、operation prerequisiteとnavigation progressionを同一視しない。 | G01 |
| E5-REQ-017 | legacy analytical URLsを互換維持する。 | `/explore`, `/causal`, `/predictive`がdocumented targetへredirect/normalizeされる。 | G01 |

## 3. New invariants

1. `Navigation Stage != Execution Stage`.
2. Family IDs reuse the existing `AnalysisFamily` semantics; UI labels may differ from internal IDs.
3. abstract navigation layer must not encode domain-specific meanings such as Discovery/Train/Estimation.
4. capability owns concrete Stage semantics; product/application layer aggregates generically.
5. Stage count/name may differ by Family.
6. navigation order is not scientific/operational completion order.
7. Predictive existing settings and generated spec semantics are protected compatibility contracts.

## 4. Removed / superseded requirement assumptions

- single sidebar item list as the primary analytical navigation taxonomy — superseded.
- a UI Stage must correspond one-to-one to execution pipeline stage — explicitly rejected.
- all Families should share a common Stage taxonomy — explicitly rejected.

## 5. Deferred requirements

- Overview/Flagship surface
- dedicated Findings/Evidence persistence model
- standalone Predict execution service
- model registry/deployment lifecycle
- external analytical engine adapters


---

# ENH-E5 Design Revision

Document class: Design Revision Artifact  
Status: DRAFT_FOR_REVIEW

## 1. Architecture decisions

### DR-01 — Reuse `AnalysisFamily` as Family identity

**Decision:** existing product-domain `AnalysisFamily` values `EXPLORATORY`, `CAUSAL`, `PREDICTIVE` are the internal Family IDs.

**Reason:** current code already binds planners/specifications/results to these analytical families. Creating a second Family identity would introduce unnecessary translation.

**Alternative rejected:** frontend-only string catalog disconnected from product domain.

### DR-02 — Introduce a distinct Navigation descriptor model

Target generic types:

```text
NavigationStageDescriptor
- stage_id
- label
- order

FamilyNavigationDescriptor
- family: AnalysisFamily
- label
- default_stage_id
- stages: tuple[NavigationStageDescriptor, ...]
```

The model MUST NOT contain execution dependencies, input/output contracts, runner IDs, execution status or attempt lifecycle.

### DR-03 — Capability-owned concrete catalog

Proposed ownership:

```text
src/ariadne/capabilities/exploratory/navigation.py
src/ariadne/capabilities/predictive/navigation.py
src/ariadne/capabilities/causal/navigation.py
```

Each capability exports one immutable `FamilyNavigationDescriptor`. Product/application code only validates and aggregates them.

### DR-04 — Backend descriptor API is canonical catalog source

Target endpoint:

```http
GET /api/v1/navigation/analysis
```

Response schema version: `analysis-navigation/1`.

Frontend may maintain a renderer registry keyed by `(family_id, stage_id)` to bind semantic IDs to DOM/rendering code, but MUST NOT maintain a second complete stage order/label/default catalog.

### DR-05 — URL is canonical current Family/Stage state

Target canonical route:

```text
/projects/{project_id}/analysis/{family_slug}/{stage_slug}
```

Canonical family slugs:
- `exploratory`
- `predictive`
- `causal`

E5 does not persist last Family/Stage in DB or `/workspace-state`.

### DR-06 — Global project surfaces stay outside Family

The following remain global project-level surfaces:
- Project Management
- Research Context
- Project / Data
- Results / Lineage

Top Family tabs contain analytical Families only. `Overview` is not introduced in E5.

### DR-07 — Legacy analytical routes normalize to new routes

- `/projects/{id}/explore` -> `/projects/{id}/analysis/exploratory/profile`
- `/projects/{id}/causal` -> `/projects/{id}/analysis/causal/discovery`
- `/projects/{id}/predictive` -> `/projects/{id}/analysis/predictive/setup`

`context`, `data`, `results` remain global routes.

### DR-08 — No persistence/schema migration

Navigation catalog is code-defined and read-only. Current Family/Stage is URL state. Existing AnalysisSpecification/Execution/Result/Artifact persistence remains unchanged.

If implementation discovers a genuine need for schema migration, stop as `BLOCKED_CONTRACT_AMBIGUITY`; do not add migration without architecture amendment.

## 2. Family stage mapping

### Exploratory

| Stage | Current capability mapping | E5 semantic rule |
|---|---|---|
| Profile | dataset/profile/explore profile | dataset overview; can host Analysis View context creation/selection where needed |
| Data Quality | existing profile/quality observations | render only facts already supported; no new quality engine |
| Distribution | DISTRIBUTION + relevant chart controls | visualization is an expression mechanism |
| Relationships | ASSOCIATION + relevant charts | no causal interpretation |
| Comparison | GROUP_SUMMARY / TIME_TREND + relevant charts | group/segment/cohort comparison |
| Findings | saved exploratory Results and existing annotation/linkage | no new Findings entity |

### Predictive

| Stage | Current capability mapping | E5 semantic rule |
|---|---|---|
| Setup | all current Predictive form fields/specification | **all existing fields retained** |
| Train | split validation + current full workflow launch/status | execution pipeline remains existing split/prepare/train/evaluate/(explain) |
| Predict | existing prediction-bearing output/artifact inspection if available | no standalone scoring execution added |
| Metrics | Evaluation + Error Analysis result surfaces | no metric engine change |
| Explainability | existing Explanation result surfaces | predictive explanation remains non-causal |
| Model Management | fitted model/model card/artifact/lineage read-only surface | no registry CRUD/deployment lifecycle |

### Causal

| Stage | Current capability mapping | E5 semantic rule |
|---|---|---|
| Setup | dataset/view/population/comparator/treatment/outcome/unit/time/window/estimand/assumptions | design context |
| Discovery | current causal discovery/graph candidate/direct graph registration | optional/non-sequential |
| Identification | fixed graph/strategy/adjustment/identification/data eligibility | separate from estimation |
| Estimation | estimator selection + allowed estimation execution/revision | current estimators only |
| Effects | treatment-effect result / comparison | result consumption |
| Diagnostics | eligibility + estimation diagnostics | validity checks |
| Sensitivity | refutation + sensitivity | current methods only |

## 3. Predictive compatibility inventory — protected target

Visible current controls that MUST remain representable:

- Active Research Context
- Dataset Version
- Analysis View
- Task Type
- Prediction unit
- Target column
- Prediction time
- Horizon
- Intended use
- Deployment population
- Feature columns
- Excluded columns
- Split strategy
- Seed
- Train ratio
- Validation ratio
- Test ratio
- Explanation method
- Explanation sample size
- Local explanations flag

Generated `predictive-analysis-spec/1` semantics that MUST NOT silently change:

- feature availability cutoff = `PREDICTION_TIME`
- split strategy semantics and ratios/seed
- preprocessing: TRAIN fit, MEAN numeric imputation, numeric scaling, ONE_HOT categorical encoding
- model IDs: logistic_regression.v1 / linear_regression.v1 with current parameters
- tuning partitions: TRAIN + VALIDATION
- primary metric: ROC_AUC or RMSE according to current task type
- explanation dataset = TEST, sampling = FIRST_N, existing explanation method/local flag

## 4. UI state handling

Family/Stage navigation MUST change visibility/routing without discarding unsaved field values in the current analytical workspace. Preferred implementation is to keep stage DOM/forms mounted and switch presentation; if refactoring renders/unmounts panels, an explicit frontend draft state must preserve all protected fields.

## 5. Result model decision

Current generic Result envelope is retained. E5 does not introduce a new `AnalysisResult` hierarchy or flatten predictive metrics/causal effects/exploratory findings into one scalar schema.

## 6. Migration / compatibility

- DB migration: `N/A` for target design.
- API migration: additive read endpoint only.
- route compatibility: legacy analytical routes normalized/redirected.
- result/analysis spec schema: unchanged.
- execution stage contracts: unchanged.


---

# ENH-E5 Target Architecture Decision Record

Document class: Architecture Decision Artifact  
Status: **DRAFT_FOR_HUMAN_APPROVAL**

## ADR-1 Decision

Establish a separate, thin application navigation model:

```text
AnalysisFamily
  -> FamilyNavigationDescriptor
       -> NavigationStageDescriptor*
```

Concrete descriptor instances are owned by each analytical capability. Generic product/application code validates/aggregates. Frontend consumes a read-only descriptor API and binds stage IDs to presentation surfaces.

## ADR-2 Invariants

1. Navigation Stage is not Execution Stage.
2. Navigation descriptors never carry runner/lifecycle/dependency/input-output-contract semantics.
3. Concrete stage semantics are capability-owned.
4. Existing `AnalysisFamily` is reused as Family identity.
5. Backend descriptor API is canonical stage catalog source.
6. Current Family/Stage is URL state in E5, not persisted state.
7. Global project workspaces remain outside Family.
8. Predictive existing configuration/spec semantics are protected.
9. No new analytical engine or persistent result model is introduced.

## ADR-3 API / route

- descriptor: `GET /api/v1/navigation/analysis`
- canonical page route: `/projects/{project_id}/analysis/{family_slug}/{stage_slug}`

## ADR-4 Capability catalog

Exploratory: Profile, Data Quality, Distribution, Relationships, Comparison, Findings.  
Predictive: Setup, Train, Predict, Metrics, Explainability, Model Management.  
Causal: Setup, Discovery, Identification, Estimation, Effects, Diagnostics, Sensitivity.

## ADR-5 Alternatives considered

### A. Frontend-static full catalog
Rejected: duplicates capability semantics and weakens ownership contract.

### B. Reuse Execution StageType for navigation
Rejected: execution stages carry pipeline/runtime semantics and do not map 1:1 to UI contexts.

### C. Persist current Family/Stage in workspace-state
Rejected for E5: URL already provides shareable/history-aware state; persistence adds cross-device/session semantics that are not a stated requirement.

### D. Add Overview as fourth top tab
Rejected for E5: Overview is not an analytical Family and would mix navigation dimensions. Reconsider in a later enhancement as global workspace if needed.

## ADR-6 Migration

DB migration: `N/A`.  
API change: additive.  
Route change: additive canonical routes + legacy normalization.  
Execution/result schema migration: `N/A`.

## ADR-7 Approval

Human architecture owner: `PENDING`  
Approved at: `PENDING`  
Baseline SHA reviewed: `46122c68333df03680b97c253a7b5d32bf9393e7`


---

# ENH-E5 Gate Decomposition Record

Document class: Architecture / Planning Artifact  
Status: DRAFT_FOR_REVIEW

## Decomposition principle

Gate = independent acceptance boundary with a downstream-usable semantic result. Coding size is handled by Work Packages.

## Gates

| Gate | What becomes true on PASS | Why downstream can depend on it |
|---|---|---|
| G00 | FamilyとNavigation Stageのapplication contractをExecution Stageから独立して成立させ、capability-owned canonical stage catalogとread APIを提供する。 | G01以降が、stable Family ID / stage ID / order / default Stage / catalog APIへ依存できる。 |
| G01 | canonical catalogを利用してtop Family tabs + Family-local Stage sidebarを成立させ、URL/deep link/history/legacy route compatibilityを確立する。 | Family-specific G02-G04が同一navigation shell上へStage contentを安全に配置できる。 |
| G02 | current Predictive workspaceをSetup/Train/Predict/Metrics/Explainability/Model Managementへ再配置し、既存設定項目とgenerated spec/execution semanticsの完全互換を成立させる。 | ユーザーとG05が、新navigation下でもcurrent Predictive capabilityがsemantically unchangedで利用できることへ依存できる。 |
| G03 | current Causal Discovery/Inference surfacesをSetup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityへ再配置し、IdentificationとEstimationの責務分離を明示する。 | ユーザーとG05が、causal design/execution/resultsをdistinct Stage contextで利用しつつ既存causal semanticsへ依存できる。 |
| G04 | current Explore & Visualize capabilityをProfile/Data Quality/Distribution/Relationships/Comparison/Findingsへ再配置し、visualizationをanalytical Stageではなく各Stageの表現手段として位置づける。 | ユーザーとG05が、EDAを探索観点別にnavigationしつつ既存exploratory resultsを失わず利用できる。 |
| G05 | 3 Familyのnavigation/Stage recomposition後に、project context・Results/Lineage・routing・existing analytical execution/persistenceがcross-familyで一貫することを確立する。 | ENH-E5全体をproduct-level verified contractとして利用・release判断できる。 |

## Dependency DAG

```text
G00 -> G01 -> G02 ----\
             G03 -----+-> G05
             G04 ----/
```

G02/G03/G04 all depend on G01. After G01 PASS they are semantically independent family recomposition contracts; execution order may be G02 -> G03 -> G04 for operational simplicity. G05 depends on all three.

## Work Package rationale

- G00: bounded domain/API contract; SINGLE_EXECUTION.
- G01: route/state/UI/history spans separable coding units; WORK_PACKAGE.
- G02: compatibility inventory, UI recomposition, regression are execution units under one semantic claim; WORK_PACKAGE.
- G03: mapping, Identification/Estimation separation, regression; WORK_PACKAGE.
- G04: mapping, visualization/findings composition, regression; WORK_PACKAGE.
- G05: convergence/regression acceptance over already-implemented contracts; SINGLE_EXECUTION.

## Non-gates

- "backend work" and "frontend work" are not Gates because they do not independently establish product semantics.
- individual Stage implementation is not a Gate because a Family is not downstream-usable until the complete Family contract is coherent.
