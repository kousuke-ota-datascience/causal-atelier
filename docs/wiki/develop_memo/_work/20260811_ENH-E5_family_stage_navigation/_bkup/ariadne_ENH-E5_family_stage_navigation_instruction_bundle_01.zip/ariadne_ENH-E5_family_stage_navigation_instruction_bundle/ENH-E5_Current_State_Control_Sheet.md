# ENH-E5 Current State Control Sheet

> Document class: Planning / Evidence / State Artifact  
> State self-containment: このControl Sheetだけでverified current state、protected contracts、OPEN Transition Debt、active orchestration pointerを理解できること。

- Project: Ariadne
- Enhancement: ENH-E5
- Branch: `feature/ariadne_mvp_e5`
- Verified through Gate: `NONE`
- Current Active Gate: `G00` (not started; draft contracts only)
- Last updated: `2026-08-11T11:12:00+09:00`
- Update authority: Human owner after final Gate Decision only

## 1. Purpose and authority

final PASS済みGate evidenceだけをverified stateへpromotionする。Draft design、package completion、READY_FOR_TEST、FAIL/BLOCKED candidateをcurrent truthへ昇格しない。

## 2. Verified baseline

- Baseline commit: `46122c68333df03680b97c253a7b5d32bf9393e7`
- Verified implementation commit: `NONE`
- Migration / schema head: `UNKNOWN`
- Runtime / deployment baseline: `UNKNOWN`

Planning baseline SHAはremote branch HEADから確定済み。G00契約freeze前にlocal checkout一致とtest baselineをpreflightで確認する。

## 3. Verified current architecture / behavior

Planning discoveryで観測したが、Gate PASSによるverified stateにはまだ昇格していない事項:

- Product domainに`AnalysisFamily = EXPLORATORY | CAUSAL | PREDICTIVE`が存在する。
- Execution workflow側にgeneric `StageType`, `StageDefinition`, `StageExecution`が存在する。
- current frontendはProject/Data, Explore, Causal Discovery, Causal Inference, Predictive, Results/Lineage等をsingle sidebarで混在表示する。
- current predictive UIは一つのworkspace内にPrediction Task / Split / Training / Evaluation / Explanation / Model Cardを保持する。

これらはarchitecture discoveryのsource factであり、G00 PASS前はprotected contractではない。

## 4. Authority map

| Domain | Authority |
|---|---|
| enhancement objective/scope | approved `00_enhance_background/02_enhancement_concept_approval_record.md` |
| target architecture | approved architecture decision record + `04_design_revision.md` |
| Gate implementation semantics | Gate-local `06_*_implementation_instruction.md` |
| Gate acceptance criteria | Gate-local `07_*_test_instruction.md` |
| Work Package execution | P00 + Pxx |
| Fixed Trial Candidate identity | implementation completion report |
| Gate PASS/FAIL/BLOCKED | Test Item 999 Gate Decision |

## 5. Protected contracts

`NONE` — no ENH-E5 Gate has passed yet.

## 6. OPEN Transition Debt

`NONE` at planning baseline. Deferred features are explicit out-of-scope, not Transition Debt.

## 7. Preflight state

- branch identity: `NOT_RUN`
- full baseline SHA / local match: `NOT_RUN` (expected `46122c68333df03680b97c253a7b5d32bf9393e7`)
- clean/expected repository state: `NOT_RUN`
- test baseline: `NOT_RUN`
- DB/migration head: `NOT_RUN`

## 8. Active orchestration pointer

1. Human reviews/approves 00-layer scope and architecture decision.
2. Execute `40_operator_workflows/preflight/ENH-E5_preflight_instruction.md`.
3. Confirm local HEAD equals the pinned baseline SHA and record test baseline.
4. Freeze G00 06/07.
5. Start G00 Trial01.

## 9. Evidence index

`NONE` — implementation/test evidence has not been generated.

## 10. Update log

- 2026-08-11T11:12:00+09:00: initial planning state created; no Gate PASS promotion.
