# Ariadne ENH-E5 G00 テスト指示書 — Gate Verification Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G00
- Gate title: Family / Navigation Stage Domain Contract
- Verification contract status: **DRAFT_FOR_REVIEW**
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Acceptance authority

This 07 is the Acceptance Criteria authority after freeze. Package completion, Coding self-check, or `READY_FOR_TEST` is not acceptance evidence.

## 2. Gate objective / acceptance claim

FamilyとNavigation Stageのapplication contractをExecution Stageから独立して成立させ、capability-owned canonical stage catalogとread APIを提供する。

PASS後にdownstreamが依存可能になるcontract:
G01以降が、stable Family ID / stage ID / order / default Stage / catalog APIへ依存できる。

## 3. Effective verification context

- Test target is the exact Fixed Trial Candidate.
- Navigation Stage and Execution Stage are distinct concepts.
- Existing analytical algorithms/persistence are regression-protected unless this Gate explicitly changes them.
- Deferred/out-of-scope features must not appear as accidental implementation.
- If environment/prerequisite prevents observation, use BLOCKED; do not convert preflight failure into product FAIL automatically.

## 4. Verification inputs

Required:
- current Trial implementation completion report
- Fixed Trial Candidate SHA
- repository status/diff
- package checkpoint chain when applicable
- Current State Control Sheet
- previous passed-Gate evidence for protected regression

If any identity is missing or ambiguous: `BLOCKED_CANDIDATE_IDENTITY`.

## 5. Candidate identity audit — MUST execute first

1. checkout/observe intended candidate;
2. record `git rev-parse HEAD`;
3. record `git status --short`;
4. compare tested repository state to Fixed Trial Candidate SHA;
5. if different, audit diff and prove it is documentation-only/non-semantic or block/fail accordingly.

## 6. Acceptance Criteria

| AC | Criterion | Level | Required evidence |
|---|---|---|---|
| AC-G00-001 | Family identity is the existing AnalysisFamily values EXPLORATORY/CAUSAL/PREDICTIVE. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G00-002 | Navigation descriptor types are structurally and semantically independent from execution StageType/StageDefinition/StageExecution. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G00-003 | Each capability owns its exact Stage IDs, labels, order, and default Stage. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G00-004 | Generic aggregation rejects duplicate families/stages, empty stage list, or invalid default Stage. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G00-005 | GET /api/v1/navigation/analysis returns deterministic schema analysis-navigation/1 for all 3 Families. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G00-006 | No DB migration or navigation-state persistence is introduced. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |
| AC-G00-007 | Existing workflow/execution tests remain green. | Mandatory | Fixed Trial Candidate behavior/code/test evidence |

All Mandatory ACs must PASS for Gate PASS.

## 7. Test Item plan

- `001_candidate_identity` — candidate/repository-state audit
- one or more focused items covering each AC cluster
- protected regression item(s)
- transition-debt audit item
- `999_gate_decision` — reserved final Gate Decision

Each test item records command/input, observed output, evidence path, and PASS/FAIL/BLOCKED result.

## 8. Protected regression

Verify all prior final-PASS Gate contracts that the current diff can affect. Absence of an explicit regression item when affected is a verification defect.

## 9. Transition Debt audit

Expected OPEN debt for this Gate: `NONE`. Confirm no undocumented temporary authority/exception was introduced.

## 10. Test / Audit Agent prohibited work

MUST NOT modify:
- production code
- automated test code
- migration/dependency definitions
- package implementation
- Acceptance Criteria

## 11. Evidence requirements

Evidence must be reproducible and tied to exact candidate identity. Screenshots/manual observation may supplement, not replace, automation where an automated assertion is practical.

## 12. PASS semantics

PASS means this Gate's semantic claim is established for the Fixed Trial Candidate, all mandatory ACs pass, protected regressions pass, no unapproved scope/migration/debt is present, and evidence identities are auditable.

FAIL means product/contract behavior violates a valid AC. BLOCKED means acceptance cannot be determined because prerequisite/candidate/contract ambiguity remains.
