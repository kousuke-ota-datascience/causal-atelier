# ENH-E5 Requirements / Design Consistency and Traceability Review

Document class: Traceability Review Artifact  
Status: DRAFT_FOR_REVIEW

## 1. Review conclusion

現時点のtarget designはhandoffのfixed decisionsとcurrent code structureに整合する。最大の整合性条件は、Navigation StageをExecution Stageから完全に分離しつつ、Family identityは既存`AnalysisFamily`を再利用することである。

## 2. Traceability matrix

| Requirement | Design trace | Gate | Acceptance implication |
|---|---|---|---|
| E5-REQ-001 | DR-01, DR-06 | G01 | Top navigationにExploratory/Predictive/Causalが表示され、current Familyが識別できる。 |
| E5-REQ-002 | DR-02, DR-03 | G01 | selected Familyに対応するStageだけがleft sidebarに表示される。 |
| E5-REQ-003 | DR-02 | G00 | Navigation descriptorがExecution StageType/StageDefinition/StageExecutionを再利用・継承しない。 |
| E5-REQ-004 | DR-03 | G00 | 各capability moduleが自Familyのstage set/default/orderを定義し、product layerはgeneric aggregation/validationのみ行う。 |
| E5-REQ-005 | DR-04 | G00 | backend descriptor APIからcatalogを取得し、frontendに別の完全catalogを重複定義しない。 |
| E5-REQ-006 | DR-05 | G01 | URL `/projects/{project_id}/analysis/{family}/{stage}` でdirect load/back/forwardが成立する。 |
| E5-REQ-007 | DR-05, DR-08 | G01 | Family/Stageをworkspace-state/DB schemaへ追加しない。 |
| E5-REQ-008 | Design Revision §3 | G02 | 全visible fieldとspec defaultがinventoryでBefore/After対応し、欠落/semantic changeがない。 |
| E5-REQ-009 | Design Revision §2 Predictive | G02 | Setup/Train/Predict/Metrics/Explainability/Model Managementが表示される。 |
| E5-REQ-010 | Design Revision §2 Causal | G03 | Setup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityが表示される。 |
| E5-REQ-011 | Design Revision §2 Causal | G03 | UI/route上で別Stageとなり、識別結果と推定実行が混同されない。 |
| E5-REQ-012 | Design Revision §2 Exploratory | G04 | Profile/Data Quality/Distribution/Relationships/Comparison/Findingsが表示される。 |
| E5-REQ-013 | Design Revision §2 Exploratory | G04 | Chart controls/outputはDistribution/Relationships/Comparison等の内部表現として配置される。 |
| E5-REQ-014 | DR-06, Design Revision §5 | G05 | Family切替後も既存cross-analysis result/lineage機能へ到達できる。 |
| E5-REQ-015 | DR-08, Design Revision §5-6 | G05 | 新engine/dependency/schema migrationなしで既存testが通る。 |
| E5-REQ-016 | DR-02, Design Revision §2 | G01 | 任意Stageへ移動でき、operation prerequisiteとnavigation progressionを同一視しない。 |
| E5-REQ-017 | DR-07 | G01 | `/explore`, `/causal`, `/predictive`がdocumented targetへredirect/normalizeされる。 |

## 3. Consistency checks

### C-01 Predictive 100% preservation
PASS condition: visible form inventoryとgenerated family_spec semanticsの双方がG02 test matrixに存在すること。

### C-02 Navigation vs Execution separation
PASS condition: new navigation domain types have no execution lifecycle semantics and execution plan tests remain unchanged.

### C-03 Capability ownership
PASS condition: concrete stage IDs/labels/default/order are defined in capability modules; aggregation layer contains no Family-specific stage lists.

### C-04 Persistence
PASS condition: no DB migration and no workspace-state field for family/stage is added.

### C-05 Deferred scope isolation
PASS condition: external engines, Overview, dedicated Findings/Evidence model, standalone scoring, model lifecycle write operations are absent from E5 diff.

## 4. Open approval item

Human approval: `PENDING_HUMAN_APPROVAL`.  
Planning baseline SHA: `46122c68333df03680b97c253a7b5d32bf9393e7`. Local checkout一致確認とtest baseline取得はpreflightで実施する。

Human approvalとlocal preflightが成立するまでGate contractはfreezeしない。
