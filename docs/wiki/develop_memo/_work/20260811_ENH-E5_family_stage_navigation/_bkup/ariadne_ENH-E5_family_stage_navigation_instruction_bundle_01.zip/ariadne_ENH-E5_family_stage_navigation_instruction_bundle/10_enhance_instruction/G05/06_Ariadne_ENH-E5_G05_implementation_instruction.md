# Ariadne ENH-E5 G05 実装指示書 — Gate Coding Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G05
- Gate title: Cross-family Convergence and Product Regression
- Branch: `feature/ariadne_mvp_e5`
- Baseline: `46122c68333df03680b97c253a7b5d32bf9393e7`
- Contract status: **DRAFT_FOR_REVIEW**
- Execution Mode: `SINGLE_EXECUTION`
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Gate definition / acceptance claim

### Objective
3 Familyのnavigation/Stage recomposition後に、project context・Results/Lineage・routing・existing analytical execution/persistenceがcross-familyで一貫することを確立する。

### Downstream usable result after PASS
ENH-E5全体をproduct-level verified contractとして利用・release判断できる。

### Why this is one Gate
This boundary is a single semantic claim that can be independently accepted and protected. Implementation volume is handled by Work Packages when mode is WORK_PACKAGE.

## 2. Effective implementation context

- Family is an analytical capability context.
- Navigation Stage is a UI/application work or view context.
- `Navigation Stage != Execution Stage`.
- Stage names/counts can differ by Family.
- Stage navigation is not a mandatory sequential workflow.
- Existing analytical execution/persistence semantics are protected unless this Gate explicitly says otherwise.
- External analytical engines are outside ENH-E5.

Acceptance targets associated with this Gate:
- AC-G05-001: Research Context/Dataset/Analysis View project context remains coherent across Family switching and global workspaces.
- AC-G05-002: Global Results/Lineage still aggregates/navigates existing cross-family results and lineage.
- AC-G05-003: All canonical Family/Stage deep links and legacy mappings work together after G02-G04 changes.
- AC-G05-004: No passed G00-G04 protected contract is silently changed.
- AC-G05-005: No DB schema migration, new analytical engine dependency, Result schema redesign, or navigation persistence was introduced.
- AC-G05-006: Full `uv run pytest -q` passes on the Fixed Trial Candidate.
- AC-G05-007: Available browser/e2e regression suite passes for Family tabs, Stage navigation, direct routes, back/forward, and representative family operations.
- AC-G05-008: Requirements/design/traceability docs match the implemented/verified contract and contain no unresolved placeholders except explicitly permitted evidence identities before PASS.

## 3. Execution Mode decision

Mode: `SINGLE_EXECUTION`.

Implement as one bounded candidate and perform Gate-wide self-check before candidate freeze.

## 4. Required implementation semantics

The implementation MUST make the Gate objective true without changing the meaning of protected upstream contracts. Favor additive/refactoring changes that preserve current analysis specs, execution plans, result schemas, and current algorithms unless explicitly required in this Gate.

## 5. Allowed scope

- cross-family context continuity
- Results/Lineage global continuity
- all canonical/legacy route regression
- full automated regression
- browser e2e
- documentation synchronization

## 6. Explicit prohibited scope

- new product feature beyond E5 accepted scope
- schema migration
- engine addition
- silent relaxation of prior Gate contracts

Global prohibitions:
- no assertion weakening/test deletion/skip/xfail solely to obtain green tests;
- no silent requirement/AC change;
- no next-Gate work bundled into this Gate;
- no unapproved schema/dependency/engine expansion.

## 7. Protected passed-Gate contracts

All final-PASS contracts from preceding ENH-E5 Gates; exact SHA/evidence must be read from Current State Control Sheet before execution.

Before coding, read the Current State Control Sheet and record the exact protected Gate evidence identities in the implementation report.

## 8. Transition Debt

NONE planned. Deferred scope is not Transition Debt.

If temporary exceptional behavior becomes unavoidable, stop and request explicit architecture/Human decision; do not invent undocumented debt.

## 9. Schema / migration / API / runtime policy

- DB schema migration: `PROHIBITED unless explicitly amended`.
- AnalysisSpecification/Execution/Result schema change: `PROHIBITED unless explicitly stated by this Gate`.
- Execution lifecycle: preserve existing semantics.
- API changes: additive only where this Gate explicitly requires them.
- Legacy analytical routes: preserve or explicitly normalize; do not silently remove.

## 10. Automated test obligations

- Implement automated evidence for AC-G05-001: Research Context/Dataset/Analysis View project context remains coherent across Family switching and global workspaces.
- Implement automated evidence for AC-G05-002: Global Results/Lineage still aggregates/navigates existing cross-family results and lineage.
- Implement automated evidence for AC-G05-003: All canonical Family/Stage deep links and legacy mappings work together after G02-G04 changes.
- Implement automated evidence for AC-G05-004: No passed G00-G04 protected contract is silently changed.
- Implement automated evidence for AC-G05-005: No DB schema migration, new analytical engine dependency, Result schema redesign, or navigation persistence was introduced.
- Implement automated evidence for AC-G05-006: Full `uv run pytest -q` passes on the Fixed Trial Candidate.
- Implement automated evidence for AC-G05-007: Available browser/e2e regression suite passes for Family tabs, Stage navigation, direct routes, back/forward, and representative family operations.
- Implement automated evidence for AC-G05-008: Requirements/design/traceability docs match the implemented/verified contract and contain no unresolved placeholders except explicitly permitted evidence identities before PASS.

Also run focused existing tests for modified modules and regression tests covering all protected upstream contracts impacted by the diff.

## 11. Candidate Assembly

Before `READY_FOR_TEST`:
1. all required implementation scope is complete;
2. all packages, if any, have valid checkpoint reports;
3. unresolved blockers are `NONE`;
4. focused and Gate-wide self-verification is recorded;
5. production/test/migration/dependency diff is reviewed;
6. one Fixed Trial Candidate SHA is recorded in the implementation completion report.

## 12. Coding Agent prohibited work

Coding Agent MUST NOT:
- decide Gate PASS;
- alter 07 Acceptance Criteria;
- treat package completion as partial PASS;
- modify passed-Gate semantics without amendment;
- implement excluded downstream features.

## 13. Required outputs

- implementation completion report for Trial01 (or current Trial)
- Gate-local implementation ledger/detail as required
- package checkpoint/status reports when WORK_PACKAGE
- exact Fixed Trial Candidate SHA
- commands and test evidence
- explicit blocker status

## 14. External reference policy

Source code paths and observed runtime/test output may be referenced as evidence. Normative rules needed for execution are contained in this contract and, in Work Package mode, the assigned Pxx contract.
