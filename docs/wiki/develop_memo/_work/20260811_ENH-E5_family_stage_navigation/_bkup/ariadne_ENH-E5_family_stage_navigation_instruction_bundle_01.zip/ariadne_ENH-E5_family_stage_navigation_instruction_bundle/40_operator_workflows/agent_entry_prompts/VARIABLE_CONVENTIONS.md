# Variable Conventions — ENH-E5

Human-supplied per run:
- `GATE_ID` = G00..G05
- `TRIAL_NO` = 01..99
- `PACKAGE_ID` = P01..P99 only for Work Package coding

Fixed:
- `PROJECT_NAME=Ariadne`
- `ENHANCE_ID=ENH-E5`
- `BRANCH_NAME=feature/ariadne_mvp_e5`

Derived path:
- `10_enhance_instruction/$GATE_ID/06_Ariadne_ENH-E5_$GATE_ID...` — derive exact filename from directory listing; if zero or multiple semantic matches, STOP.

Before Agent execution, replace/resolve all variables explicitly. Never select an arbitrary glob match.
