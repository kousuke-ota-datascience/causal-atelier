# ENH-E5 G03 P00 Work Package Plan

Document class: Planning / Operator Artifact  
Self-containment: MUST for orchestration

- Gate: G03
- Trial applicability: Trial01; re-baseline for later Trial only if remediation/amendment requires
- Parent 06: `06_Ariadne_ENH-E5_G03_implementation_instruction.md`
- Parent 07: `07_Ariadne_ENH-E5_G03_test_instruction.md`
- Plan status: **DRAFT_FOR_REVIEW**
- P00 is execution control, not implementation package.

## 1. Why Work Package Mode is required

The Gate semantic boundary must stay whole, but implementation spans route/state/UI/family-specific behavior and regression surfaces. Packages isolate coding execution and failure localization without creating partial Gate acceptance.

## 2. Effective Gate semantic boundary

- Gate acceptance claim: current Causal Discovery/Inference surfacesをSetup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityへ再配置し、IdentificationとEstimationの責務分離を明示する。
- Downstream result: ユーザーとG05が、causal design/execution/resultsをdistinct Stage contextで利用しつつ既存causal semanticsへ依存できる。
- All packages preserve: Navigation Stage != Execution Stage; no unapproved schema/engine change; prior passed-Gate protection.

## 3. Package map

| Package | Purpose | Depends on | Entry criterion | Exit criterion | Focused verification |
|---|---|---|---|---|---|
| P01 | Refactor current Causal UI into seven semantic Stage panels preserving existing form/result operations. | NONE | upstream package(s) complete or NONE | focused implementation + verification + checkpoint report | package-specific focused tests |
| P02 | Establish explicit Identification vs Estimation surfaces/routes and preserve action prerequisites. | P01 | upstream package(s) complete or NONE | focused implementation + verification + checkpoint report | package-specific focused tests |
| P03 | Causal focused regression including discovery/effects/diagnostics/sensitivity and candidate assembly inputs. | P01,P02 | upstream package(s) complete or NONE | focused implementation + verification + checkpoint report | package-specific focused tests |

## 4. Execution DAG

```text
P01 -> P02 -> P03
```

## 5. Shared rules

- Package complete != Gate PASS.
- Same package may be restarted/corrected within the same Trial until candidate assembly.
- Each package creates a checkpoint report with exact SHA and focused verification.
- Dependency package must be complete before dependent package starts.
- Pxx cannot alter Gate semantic claim or AC.

## 6. Package completion

Package complete requires implementation scope complete, focused checks pass, no unresolved package blocker, checkpoint SHA recorded, and report produced.

## 7. Restart policy

Coding interruption/focused self-check failure does not increment Trial. Resume/restart same package in same Trial, preserving package report history.

## 8. Checkpoint policy

Each package records one final checkpoint SHA; intermediate commits may exist but are not Gate acceptance identities.

## 9. Candidate Assembly

After all packages are complete, one designated assembly step must:
- verify package chain completeness;
- run Gate-wide tests;
- review total diff;
- resolve blockers;
- freeze one Fixed Trial Candidate SHA;
- create implementation completion report.

## 10. Trial completion

Only Independent Verification against 07 may issue PASS/FAIL/BLOCKED.

## 11. Remediation

Formal FAIL -> use 08 and Rxx if required. Do not edit frozen original 06/07/P00 semantics merely because a candidate failed.
