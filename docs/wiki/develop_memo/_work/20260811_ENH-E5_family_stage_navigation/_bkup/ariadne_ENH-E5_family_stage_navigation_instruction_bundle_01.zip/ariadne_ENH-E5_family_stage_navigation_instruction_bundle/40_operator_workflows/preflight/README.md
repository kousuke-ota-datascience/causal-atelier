# Preflight — ENH-E5

Preflight validates execution prerequisites and identity. Failure here is not automatically a product Gate FAIL; it can BLOCK Gate execution.
