# Product Basic Design — ENH-E5 revised scope

## Screen composition

```text
Global project header / context
[Exploratory] [Predictive] [Causal]     <- Family tabs
-------------------------------------------------------
Family-local Stage sidebar | Stage main content
                            |
Global project surfaces (Management / Context / Data / Results-Lineage) remain outside Family.
```

## Family behavior

- Family tab click navigates to that Family's declared default Stage.
- Stage click changes only the local analytical navigation context.
- Browser back/forward restores Family and Stage from URL.
- No last-stage memory in E5.

## Invalid route behavior

Unknown Family/Stage must not be silently interpreted as another semantic context. Show a navigation error with links to valid Family defaults, or normalize only when an explicit legacy mapping exists.
