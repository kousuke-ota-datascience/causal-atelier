# ENH-E5 G02 P01 — Predictive Compatibility Inventory

Document class: Primary Execution Contract  
Self-containment: MUST

- Gate: G02
- Trial: `01`
- Package: P01
- Parent 06: `06_Ariadne_ENH-E5_G02_implementation_instruction.md`
- P00 Plan: `06_G02_P00_work_package_plan.md`
- Depends on: `NONE`
- Status at issuance: **DRAFT_FOR_REVIEW**

## 1. Purpose

Codify/test complete current visible field + generated spec semantic inventory before UI move.

## 2. Effective Gate constraints

- Gate claim: current Predictive workspaceをSetup/Train/Predict/Metrics/Explainability/Model Managementへ再配置し、既存設定項目とgenerated spec/execution semanticsの完全互換を成立させる。
- Downstream result: ユーザーとG05が、新navigation下でもcurrent Predictive capabilityがsemantically unchangedで利用できることへ依存できる。
- Navigation Stage != Execution Stage.
- No schema migration/new engine/unapproved scope.
- Do not change Gate AC or passed-Gate semantics.

## 3. In scope

Package-specific purpose above, limited to the smallest code/test changes necessary. Gate-wide allowed scope for context:
- six Predictive stage surfaces
- existing config field preservation
- split/train/eval/explain workflow preservation
- prediction-bearing artifact/result inspection
- metrics/explanation/model-card read surfaces
- compatibility tests

## 4. Out of scope

- work assigned to later packages except minimal compile/interface stubs explicitly required by this package;
- any item listed in parent Gate prohibited scope;
- Gate decision/candidate acceptance.

## 5. Entry criterion / evidence

- prerequisite package(s): `NONE` are complete, or `NONE`;
- branch/baseline identity verified;
- current package instruction is frozen for Trial;
- protected upstream contract list recorded.

## 6. Implementation requirements

1. Make the package purpose true without broadening semantic scope.
2. Preserve existing analytical/spec/result/execution behavior unless this package explicitly relocates presentation.
3. Add/update focused automated tests for changed behavior.
4. Keep observable IDs/routes/API schema deterministic.

## 7. Focused verification

Run the narrowest relevant unit/API/frontend tests plus static/syntax checks needed for touched files. Record exact commands and results.

## 8. Protected contracts / Transition Debt

Read current Control Sheet before execution. Planned new Transition Debt: `NONE`.

## 9. Checkpoint and reporting

At package completion:
- record `git rev-parse HEAD` as Package Checkpoint SHA;
- record `git status --short`;
- create package checkpoint/status report under 20 layer;
- report focused verification;
- report unresolved blockers.

## 10. Exit criterion

Package purpose is implemented and focused verification is green, with one auditable checkpoint. This does **not** establish Gate PASS.

## 11. External reference policy

Source code/test output may be referenced as evidence; normative package rules are contained here.

## 12. Stop conditions

Stop as `BLOCKED_*` if contract ambiguity, unapproved migration/dependency requirement, baseline identity mismatch, or protected contract conflict is discovered.
