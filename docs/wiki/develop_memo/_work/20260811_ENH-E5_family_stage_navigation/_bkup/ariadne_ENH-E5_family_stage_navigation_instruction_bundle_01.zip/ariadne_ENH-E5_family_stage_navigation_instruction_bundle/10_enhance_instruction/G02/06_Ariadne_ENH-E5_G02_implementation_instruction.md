# Ariadne ENH-E5 G02 実装指示書 — Gate Coding Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G02
- Gate title: Predictive Family Recomposition and Compatibility
- Branch: `feature/ariadne_mvp_e5`
- Baseline: `46122c68333df03680b97c253a7b5d32bf9393e7`
- Contract status: **DRAFT_FOR_REVIEW**
- Execution Mode: `WORK_PACKAGE`
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Gate definition / acceptance claim

### Objective
current Predictive workspaceをSetup/Train/Predict/Metrics/Explainability/Model Managementへ再配置し、既存設定項目とgenerated spec/execution semanticsの完全互換を成立させる。

### Downstream usable result after PASS
ユーザーとG05が、新navigation下でもcurrent Predictive capabilityがsemantically unchangedで利用できることへ依存できる。

### Why this is one Gate
This boundary is a single semantic claim that can be independently accepted and protected. Implementation volume is handled by Work Packages when mode is WORK_PACKAGE.

## 2. Effective implementation context

- Family is an analytical capability context.
- Navigation Stage is a UI/application work or view context.
- `Navigation Stage != Execution Stage`.
- Stage names/counts can differ by Family.
- Stage navigation is not a mandatory sequential workflow.
- Existing analytical execution/persistence semantics are protected unless this Gate explicitly says otherwise.
- External analytical engines are outside ENH-E5.

Acceptance targets associated with this Gate:
- AC-G02-001: All six Predictive Navigation Stages are reachable and use canonical routes.
- AC-G02-002: Every current visible Predictive control is preserved with same input semantics/defaults unless only relocated.
- AC-G02-003: Generated predictive-analysis-spec/1 hidden/default semantics remain unchanged for equivalent inputs.
- AC-G02-004: Train action still invokes the existing split/prepare/train/evaluate/(explain) workflow; navigation Stage is not mapped 1:1 to execution Stage.
- AC-G02-005: Predict Stage does not introduce standalone scoring; it exposes only existing prediction-bearing outputs/artifacts/results where available and states absence deterministically.
- AC-G02-006: Metrics exposes existing evaluation/error-analysis semantics; Explainability preserves predictive-not-causal warning/meaning.
- AC-G02-007: Model Management is read-only fitted-model/model-card/artifact/lineage scope in E5.
- AC-G02-008: Family/Stage switching does not discard protected unsaved Predictive form values during the active page session.
- AC-G02-009: Existing Predictive regression tests and full relevant suite pass.

## 3. Execution Mode decision

Mode: `WORK_PACKAGE`.

Use `06_G02_P00_work_package_plan.md` and all planned Pxx instructions. Package completion does not mean Gate PASS.

## 4. Required implementation semantics

The implementation MUST make the Gate objective true without changing the meaning of protected upstream contracts. Favor additive/refactoring changes that preserve current analysis specs, execution plans, result schemas, and current algorithms unless explicitly required in this Gate.

## 5. Allowed scope

- six Predictive stage surfaces
- existing config field preservation
- split/train/eval/explain workflow preservation
- prediction-bearing artifact/result inspection
- metrics/explanation/model-card read surfaces
- compatibility tests

## 6. Explicit prohibited scope

- LightGBM
- new standalone scoring execution/API
- new model registry CRUD/deployment
- predictive-analysis-spec schema change
- hidden preprocessing/model default change

Global prohibitions:
- no assertion weakening/test deletion/skip/xfail solely to obtain green tests;
- no silent requirement/AC change;
- no next-Gate work bundled into this Gate;
- no unapproved schema/dependency/engine expansion.

## 7. Protected passed-Gate contracts

All final-PASS contracts from preceding ENH-E5 Gates; exact SHA/evidence must be read from Current State Control Sheet before execution.

Before coding, read the Current State Control Sheet and record the exact protected Gate evidence identities in the implementation report.

## 8. Transition Debt

NONE planned. Deferred scope is not Transition Debt.

If temporary exceptional behavior becomes unavoidable, stop and request explicit architecture/Human decision; do not invent undocumented debt.

## 9. Schema / migration / API / runtime policy

- DB schema migration: `PROHIBITED unless explicitly amended`.
- AnalysisSpecification/Execution/Result schema change: `PROHIBITED unless explicitly stated by this Gate`.
- Execution lifecycle: preserve existing semantics.
- API changes: additive only where this Gate explicitly requires them.
- Legacy analytical routes: preserve or explicitly normalize; do not silently remove.

## 10. Automated test obligations

- Implement automated evidence for AC-G02-001: All six Predictive Navigation Stages are reachable and use canonical routes.
- Implement automated evidence for AC-G02-002: Every current visible Predictive control is preserved with same input semantics/defaults unless only relocated.
- Implement automated evidence for AC-G02-003: Generated predictive-analysis-spec/1 hidden/default semantics remain unchanged for equivalent inputs.
- Implement automated evidence for AC-G02-004: Train action still invokes the existing split/prepare/train/evaluate/(explain) workflow; navigation Stage is not mapped 1:1 to execution Stage.
- Implement automated evidence for AC-G02-005: Predict Stage does not introduce standalone scoring; it exposes only existing prediction-bearing outputs/artifacts/results where available and states absence deterministically.
- Implement automated evidence for AC-G02-006: Metrics exposes existing evaluation/error-analysis semantics; Explainability preserves predictive-not-causal warning/meaning.
- Implement automated evidence for AC-G02-007: Model Management is read-only fitted-model/model-card/artifact/lineage scope in E5.
- Implement automated evidence for AC-G02-008: Family/Stage switching does not discard protected unsaved Predictive form values during the active page session.
- Implement automated evidence for AC-G02-009: Existing Predictive regression tests and full relevant suite pass.

Also run focused existing tests for modified modules and regression tests covering all protected upstream contracts impacted by the diff.

## 11. Candidate Assembly

Before `READY_FOR_TEST`:
1. all required implementation scope is complete;
2. all packages, if any, have valid checkpoint reports;
3. unresolved blockers are `NONE`;
4. focused and Gate-wide self-verification is recorded;
5. production/test/migration/dependency diff is reviewed;
6. one Fixed Trial Candidate SHA is recorded in the implementation completion report.

## 12. Coding Agent prohibited work

Coding Agent MUST NOT:
- decide Gate PASS;
- alter 07 Acceptance Criteria;
- treat package completion as partial PASS;
- modify passed-Gate semantics without amendment;
- implement excluded downstream features.

## 13. Required outputs

- implementation completion report for Trial01 (or current Trial)
- Gate-local implementation ledger/detail as required
- package checkpoint/status reports when WORK_PACKAGE
- exact Fixed Trial Candidate SHA
- commands and test evidence
- explicit blocker status

## 14. External reference policy

Source code paths and observed runtime/test output may be referenced as evidence. Normative rules needed for execution are contained in this contract and, in Work Package mode, the assigned Pxx contract.
