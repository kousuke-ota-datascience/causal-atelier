# Ariadne ENH-E5 G01 実装指示書 — Gate Coding Contract

Document class: Primary Execution Contract  
Self-containment: MUST

- Project: Ariadne
- Enhancement: ENH-E5
- Active Gate: G01
- Gate title: URL-driven Family / Stage Navigation Shell
- Branch: `feature/ariadne_mvp_e5`
- Baseline: `46122c68333df03680b97c253a7b5d32bf9393e7`
- Contract status: **DRAFT_FOR_REVIEW**
- Execution Mode: `WORK_PACKAGE`
- Current State Control Sheet: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Gate definition / acceptance claim

### Objective
canonical catalogを利用してtop Family tabs + Family-local Stage sidebarを成立させ、URL/deep link/history/legacy route compatibilityを確立する。

### Downstream usable result after PASS
Family-specific G02-G04が同一navigation shell上へStage contentを安全に配置できる。

### Why this is one Gate
This boundary is a single semantic claim that can be independently accepted and protected. Implementation volume is handled by Work Packages when mode is WORK_PACKAGE.

## 2. Effective implementation context

- Family is an analytical capability context.
- Navigation Stage is a UI/application work or view context.
- `Navigation Stage != Execution Stage`.
- Stage names/counts can differ by Family.
- Stage navigation is not a mandatory sequential workflow.
- Existing analytical execution/persistence semantics are protected unless this Gate explicitly says otherwise.
- External analytical engines are outside ENH-E5.

Acceptance targets associated with this Gate:
- AC-G01-001: Top tabs show exactly Exploratory/Predictive/Causal from backend catalog and visually identify current Family.
- AC-G01-002: Left sidebar shows only stages owned by current Family and identifies current Stage.
- AC-G01-003: Canonical URL is /projects/{id}/analysis/{family}/{stage}; direct load and browser back/forward restore state.
- AC-G01-004: Family switch navigates to the target Family declared default Stage; no last-stage persistence is used.
- AC-G01-005: Legacy /explore, /causal, /predictive routes normalize to documented canonical targets.
- AC-G01-006: Management, Context, Data, Results/Lineage remain global project surfaces outside Family tabs.
- AC-G01-007: Unknown Family/Stage is not silently reinterpreted; explicit navigation error/valid alternatives are provided.
- AC-G01-008: Stage navigation itself is non-sequential and does not enforce wizard completion.

## 3. Execution Mode decision

Mode: `WORK_PACKAGE`.

Use `06_G01_P00_work_package_plan.md` and all planned Pxx instructions. Package completion does not mean Gate PASS.

## 4. Required implementation semantics

The implementation MUST make the Gate objective true without changing the meaning of protected upstream contracts. Favor additive/refactoring changes that preserve current analysis specs, execution plans, result schemas, and current algorithms unless explicitly required in this Gate.

## 5. Allowed scope

- descriptor-driven Family tabs/stage sidebar
- canonical analysis route
- browser history/deep link
- legacy route normalization
- global workspace separation
- navigation error handling

## 6. Explicit prohibited scope

- family-specific analytical semantics redesign
- workspace-state DB persistence of family/stage
- new Overview tab
- removal of global Results/Lineage

Global prohibitions:
- no assertion weakening/test deletion/skip/xfail solely to obtain green tests;
- no silent requirement/AC change;
- no next-Gate work bundled into this Gate;
- no unapproved schema/dependency/engine expansion.

## 7. Protected passed-Gate contracts

All final-PASS contracts from preceding ENH-E5 Gates; exact SHA/evidence must be read from Current State Control Sheet before execution.

Before coding, read the Current State Control Sheet and record the exact protected Gate evidence identities in the implementation report.

## 8. Transition Debt

NONE planned. Deferred scope is not Transition Debt.

If temporary exceptional behavior becomes unavoidable, stop and request explicit architecture/Human decision; do not invent undocumented debt.

## 9. Schema / migration / API / runtime policy

- DB schema migration: `PROHIBITED unless explicitly amended`.
- AnalysisSpecification/Execution/Result schema change: `PROHIBITED unless explicitly stated by this Gate`.
- Execution lifecycle: preserve existing semantics.
- API changes: additive only where this Gate explicitly requires them.
- Legacy analytical routes: preserve or explicitly normalize; do not silently remove.

## 10. Automated test obligations

- Implement automated evidence for AC-G01-001: Top tabs show exactly Exploratory/Predictive/Causal from backend catalog and visually identify current Family.
- Implement automated evidence for AC-G01-002: Left sidebar shows only stages owned by current Family and identifies current Stage.
- Implement automated evidence for AC-G01-003: Canonical URL is /projects/{id}/analysis/{family}/{stage}; direct load and browser back/forward restore state.
- Implement automated evidence for AC-G01-004: Family switch navigates to the target Family declared default Stage; no last-stage persistence is used.
- Implement automated evidence for AC-G01-005: Legacy /explore, /causal, /predictive routes normalize to documented canonical targets.
- Implement automated evidence for AC-G01-006: Management, Context, Data, Results/Lineage remain global project surfaces outside Family tabs.
- Implement automated evidence for AC-G01-007: Unknown Family/Stage is not silently reinterpreted; explicit navigation error/valid alternatives are provided.
- Implement automated evidence for AC-G01-008: Stage navigation itself is non-sequential and does not enforce wizard completion.

Also run focused existing tests for modified modules and regression tests covering all protected upstream contracts impacted by the diff.

## 11. Candidate Assembly

Before `READY_FOR_TEST`:
1. all required implementation scope is complete;
2. all packages, if any, have valid checkpoint reports;
3. unresolved blockers are `NONE`;
4. focused and Gate-wide self-verification is recorded;
5. production/test/migration/dependency diff is reviewed;
6. one Fixed Trial Candidate SHA is recorded in the implementation completion report.

## 12. Coding Agent prohibited work

Coding Agent MUST NOT:
- decide Gate PASS;
- alter 07 Acceptance Criteria;
- treat package completion as partial PASS;
- modify passed-Gate semantics without amendment;
- implement excluded downstream features.

## 13. Required outputs

- implementation completion report for Trial01 (or current Trial)
- Gate-local implementation ledger/detail as required
- package checkpoint/status reports when WORK_PACKAGE
- exact Fixed Trial Candidate SHA
- commands and test evidence
- explicit blocker status

## 14. External reference policy

Source code paths and observed runtime/test output may be referenced as evidence. Normative rules needed for execution are contained in this contract and, in Work Package mode, the assigned Pxx contract.
