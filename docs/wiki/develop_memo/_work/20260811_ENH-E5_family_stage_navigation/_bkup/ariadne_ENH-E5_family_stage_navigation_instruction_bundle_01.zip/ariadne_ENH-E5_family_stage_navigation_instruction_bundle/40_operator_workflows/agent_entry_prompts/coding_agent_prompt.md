# Coding Agent Prompt — ENH-E5 SINGLE_EXECUTION Gate

Input variables: `GATE_ID`, `TRIAL_NO`.

1. Verify branch `feature/ariadne_mvp_e5` and exact baseline/current protected state.
2. Read the frozen `06_Ariadne_ENH-E5_<GATE_ID>_implementation_instruction.md` as implementation authority.
3. Read frozen 07 only to understand acceptance targets; do not change it.
4. Implement only Active Gate scope.
5. Run focused + Gate-wide self-verification required by 06.
6. Record exact candidate SHA and implementation completion report.
7. Stop `READY_FOR_TEST` or explicit `BLOCKED_*`.
8. Never issue PASS/FAIL Gate Decision.
