# ENH-E5 Enhancement Concept and Requirement Revision Plan

Document class: Planning / Background Artifact  
Status: DRAFT_FOR_REVIEW

## 1. Problem

現行UIではanalytical Familyとworkflow/view contextに相当するnavigation itemが同じleft sidebarへ混在しており、Ariadneの分析能力を「複数のanalytical perspective」として扱うapplication modelがUI/route/capability ownershipに明示されていない。

またbackendにはgeneric Execution Stage abstractionがあるため、UI上のStageをそのままExecution Stageへ流用すると、navigation concernとruntime execution lifecycleが混線するリスクがある。

## 2. Objective

Ariadneのanalytical capabilityを `Family -> Navigation Stage*` として再構成し、Exploratory / Predictive / Causalをfirst-classなanalytical contextとして横断できるnavigation architectureを確立する。

## 3. Target outcome

- 上部横タブに`Exploratory / Predictive / Causal`を常時表示する。
- 左sidebarはcurrent Familyが提供するNavigation Stageだけを表示する。
- capabilityがconcrete Stage catalogを所有する。
- URLでCurrent Family / Stageを表現し、deep link / browser historyを成立させる。
- current predictive configuration/semanticsを完全保持する。
- current causal/exploratory operationsをStageへ再配置し、機能欠落を発生させない。

## 4. In scope

### Application / architecture
- Family/Navigation Stage descriptor model
- capability-owned stage definition
- descriptor read API
- frontend Family/Stage navigation
- URL route / deep link / browser history
- legacy analytical routes compatibility

### Family stage set

Exploratory:
`Profile`, `Data Quality`, `Distribution`, `Relationships`, `Comparison`, `Findings`

Predictive:
`Setup`, `Train`, `Predict`, `Metrics`, `Explainability`, `Model Management`

Causal:
`Setup`, `Discovery`, `Identification`, `Estimation`, `Effects`, `Diagnostics`, `Sensitivity`

### Compatibility
- Predictive existing configuration fields 100% preservation
- current execution spec defaults/semantics preservation
- current Results / Lineage cross-family behavior preservation
- current Research Context / Dataset / Analysis View semantics preservation

## 5. Explicit out of scope

- LightGBM adapter
- DoWhy adapter
- EconML estimator
- new standalone Predict execution engine/scoring service
- model registry/deployment lifecycle CRUD
- Causal Analysis Management Stage
- Overview/Flagship top-level workspace
- new Findings/Evidence persistent domain model
- AnalysisResult/Result schema redesign
- navigation state DB persistence
- forced common Stage taxonomy across Families
- strict wizard/sequential navigation

## 6. Expected requirement/design impact

High impact:
- information architecture
- frontend route/state model
- capability ownership contract
- API descriptor contract

Medium impact:
- family-specific UI composition
- test/e2e matrix

Expected no-change:
- analytical algorithms
- execution lifecycle semantics
- persistent analysis/result schemas
- migration schema

## 7. Initial Gate decomposition

| Gate | PASS semantic claim |
|---|---|
| G00 | Family/Navigation Stage contract and capability-owned catalog can be relied on independently from Execution Stage. |
| G01 | Product navigation can be driven by Family/Stage URL and catalog while preserving global workspaces and legacy links. |
| G02 | Predictive capability is usable through six Navigation Stages with full existing configuration/execution compatibility. |
| G03 | Causal capability is usable through seven Navigation Stages with Identification and Estimation explicitly separated. |
| G04 | Exploratory capability is usable through six analytical-view Stages without a standalone Visualization Stage. |
| G05 | Cross-family context/results continuity and full regression protection are established for the completed navigation model. |

## 8. Main risks

1. **Semantic collision:** Navigation Stage accidentally reuses Execution `StageType`.
2. **Predictive regression:** visible fields are retained but hidden spec defaults change.
3. **State regression:** stage switching loses draft form values/context.
4. **Routing regression:** browser back/forward or direct URL bypasses expected workspace state.
5. **Scope creep:** new analytical engines or result-domain redesign get mixed into navigation enhancement.

## 9. Required decision before coding

- Human approval of scope and target architecture.
- full branch baseline SHA resolution.
- G00 06/07 freeze.
