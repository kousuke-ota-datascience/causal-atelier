# 20_implementation_reports — ENH-E5

Document class: Evidence Artifact Guide

No implementation evidence exists at planning time. Do not pre-create fake checkpoint SHA, candidate SHA, completion status, or implementation observations.

At Trial start create `{GATE_ID}/Trial{TRIAL_NO}/` and record:
- package status/checkpoint reports for Work Package gates;
- implementation report detail;
- implementation completion report with exact Fixed Trial Candidate SHA.
