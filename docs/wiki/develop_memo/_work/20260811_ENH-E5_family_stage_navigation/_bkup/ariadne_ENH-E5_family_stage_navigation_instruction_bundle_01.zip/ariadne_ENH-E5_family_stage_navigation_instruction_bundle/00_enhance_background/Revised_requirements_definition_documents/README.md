# Revised requirements definition documents — ENH-E5 scope snapshots

このdirectoryはENH-E5で改定対象となるrequirement/design sectionsをself-containedに再構成したscope snapshotである。

これは既存project-wide原典の全文複製ではない。E5実装・reviewに必要な変更契約を明示し、原典へmergeする際のapproved targetを提供する。
