# 10 要件定義

- 文書状態: `DRAFT_FOR_REVIEW`
- 文書種別: 現行requirementsのeffective snapshot
- 上位文書: `00_product_concept_memo.md`
- 下位文書: `21_logical_data_design.md` / `22_product_basic_design.md` / `23_api_interface_design.md` / `30_detailed_design.md`

## 0. INTRODUCTION

### 0.1. 背景となる問題

現行workspaceではanalytical FamilyとFamily内のworkflow/view contextがnavigation上で混在し、ユーザーが「どのanalytical perspectiveにいるか」と「その中の何をしているか」を別dimensionとして認識しづらい。

またcurrent backendにはexecution lifecycleを表すgeneric Stage abstractionが存在するため、UI上のStageを既存Execution Stageへ流用すると、navigation taxonomyの変更がCLI / library / runtime contractへ波及する危険がある。

既存のProject / Research Context / Dataset / Analysis Specification / Execution / Result / Lineage contractは分析の再現性・追跡可能性を支えるため、navigation再構成によって意味を失わせてはならない。

### 0.2. Legends

#### 0.2.1. Requirement levels

- `MUST`: acceptanceに必須。
- `MUST NOT`: 実装してはならない。
- `SHOULD`: 強い推奨。逸脱には明示理由が必要。
- `MAY`: 任意。必須acceptanceには含めない。

#### 0.2.2. 用語

- `Family`: Exploratory / Predictive / Causalのanalytical capability context。
- `Navigation Stage`: Family内でユーザーが選択するwork/view context。
- `Execution Stage`: ExecutionPlan / StageExecutionに属するruntime execution unit。
- `Stage`を単独で用いる場合、UI/application文脈ではNavigation Stageを指す。

## 1. 適用範囲

Ariadneは、Project / Research Topicを境界として、Research Context、Dataset Version、Exploratory / Predictive / Causalの三つのAnalysis Family、Execution、Result、Artifact、AnnotationおよびLineageを管理する。Analysis Familyはglobal analytical context、Navigation StageはFamily-local work/view contextとして扱う。

対象データは前処理可能な表形式データとし、予測分析の対象TaskはBinary ClassificationとRegressionとする。因果分析はGraph Discovery、Identification、Data Eligibility、ATE / ATT Estimation、Diagnostics、RefutationおよびSensitivityを対象とする。

## 2. Actor

| Actor | 責務 | 主要権限 |
| --- | --- | --- |
| Analyst | Context、Data、Analysis Specification、Execution、比較、Annotationを作成する | Project read/write/execute |
| Reviewer / Viewer | Result、warning、diagnostics、Lineage、Annotationを確認する | Project read |
| Operator | 実行基盤、保存領域、認証、監視、保持policyを運用する | system operate |

## 3. 業務Capability

| Capability | 目的 | 正本Resource |
| --- | --- | --- |
| Project / Research Context | 分析の意味、問い、意思決定を固定する | Project、ResearchContextVersion |
| Data / Analysis View | 入力データと分析対象条件を固定する | DatasetVersion、AnalysisView |
| Exploratory Analysis | データ品質・分布・関係・比較を探索し、Finding候補を蓄積する | AnalysisSpecification(EXPLORATORY)、Result、Artifact、Annotation |
| Causal Analysis | 介入効果を仮定・識別・診断とともに評価する | AnalysisSpecification(CAUSAL)、GraphVersion、Result |
| Predictive Analysis | 将来targetの予測可能性とmodel挙動を評価する | AnalysisSpecification(PREDICTIVE)、Result、Artifact |
| Workflow | Planner、Plan、Stage、Runner、Executorを制御する | ExecutionPlan、Execution、StageExecution |
| Results / Lineage | 結果比較、判断、来歴、Exportを提供する | Result、Artifact、Annotation、LineageEdge |
| Analytical Navigation | Analysis FamilyとFamily-local Navigation Stageを独立したnavigation dimensionとして提示する | AnalysisFamily、Navigation metadata/state（non-persistent） |

## 4. E2Eシナリオ

| ID | シナリオ | 完了条件 |
| --- | --- | --- |
| E2E-01 | Research Workspaceを作成する | ProjectとResearch Contextを作成し、Dataset Versionを登録してProject-global surfaceと三つのAnalytical Familyへ遷移できる |
| E2E-02 | 探索・可視化を保存する | Datasetの品質・分布・関連を確認し、ChartとAnalysis Viewを保存できる |
| E2E-03 | 探索から分析draftを作る | 探索ResultからCausalまたはPredictive Specification draftを作成し、source relationを保持できる |
| E2E-04 | 因果効果を評価する | Graph、Question、Design、Identification、Eligibility、Estimation、Diagnostics、Refutation、Sensitivityを実行できる |
| E2E-05 | 分類モデルを評価する | Binary Classificationをsplit、train、evaluate、explainし、test isolationを確認できる |
| E2E-06 | 回帰モデルを評価する | Regressionをsplit、train、evaluate、error analysisし、複数modelを比較できる |
| E2E-07 | 条件変更を比較する | base ExecutionからRERUNまたはREVISEDを作成し、changed dimensionsと結果差分を確認できる |
| E2E-08 | 横断来歴を確認する | ReviewerがResearch ContextからExploratory、Causal、PredictiveのResultと判断理由へ遡れる |
| E2E-09 | Analysis Familyを横断する | Family tabでExploratory / Predictive / Causalを切り替え、selected FamilyのNavigation Stageだけを左navigationから選択できる |
| E2E-10 | UIを経由せずanalysisを実行する | CLI / Python library / backend use caseからCurrent Navigation Stageを指定せず既存analysis executionを開始できる |

### 4.1. E2E共通受入条件

- Command受付時にProject権限、Resource状態、SchemaおよびFamily固有validationが実行される
- すべてのExecutionがResearch Context Version、Dataset VersionまたはAnalysis Viewを固定する
- ResultとArtifactがExecution / Stageへ紐付く
- UI表示とAPI payloadが同じ保存済み正本を参照する
- 失敗時にtechnical failure、validation rejection、analytical negative resultを区別する
- Navigation Stageの存在・順序をruntime Execution Stageやworkflow completionへ読み替えない

## 5. 機能要件

| ID | 領域 | 要件 | 優先度 |
| --- | --- | --- | --- |
| FR-001 | Project / Context | ProjectをResearch Topicの権限・来歴境界として作成、更新、archiveできる | MUST |
| FR-002 | Project / Context | Projectにtopic、objective、decision contextおよびmemoを保持できる | MUST |
| FR-003 | Project / Context | Research Contextをversioned resourceとして作成し、過去Versionを上書きしない | MUST |
| FR-004 | Project / Context | Research Contextに複数のResearch QuestionとHypothesisを保持できる | MUST |
| FR-005 | Project / Context | Context間にREFINES、DERIVED_FROM、SUPERSEDES、RELATED_TO relationを設定できる | SHOULD |
| FR-006 | Project / Context | Analysis Specificationは一つのResearch Context Versionを参照する | MUST |
| FR-007 | Project / Context | Executionは受付時のResearch Context snapshotとhashを保持する | MUST |
| FR-008 | Project / Context | Contextの履歴、利用Analysisおよび関連Resultを確認できる | MUST |
| FR-009 | Project / Context | ARCHIVED Projectでは新規Executionを受け付けず、既存Resultを保持する | MUST |
| FR-010 | Data / View | CSVまたはParquetをDataset Versionとして不変登録する | MUST |
| FR-011 | Data / View | Dataset Versionにcontent hash、schema、row count、column count、基本profileを保存する | MUST |
| FR-012 | Data / View | Dataset previewとcolumn metadataを権限内で取得できる | MUST |
| FR-013 | Data / View | 同一Dataset系列に複数Versionを登録し、Executionが参照Versionを固定する | MUST |
| FR-014 | Data / View | Analysis Viewにrow filter、column selection、derived column、missing policy、time cutoffを定義する | MUST |
| FR-015 | Data / View | Analysis Viewの式と参照列を型付きSchemaで検証する | MUST |
| FR-016 | Data / View | 固定済みAnalysis Viewを上書きせず、変更時は新Versionを作成する | MUST |
| FR-017 | Data / View | Analysis Viewからsource Dataset Versionと生成条件へ遡れる | MUST |
| FR-018 | Data / View | 同じAnalysis Viewを複数Analysis Familyから参照できる | SHOULD |
| FR-019 | Data / View | Dataset columnにグローバルなTreatment、Outcome、Target等の役割を固定しない | MUST |
| FR-020 | Data / View | Exploreのfilter・chart状態からAnalysis View draftを作成できる | SHOULD |
| FR-021 | Data / View | 機微列、利用制限および説明をcolumn metadataへ付与できる | SHOULD |
| FR-022 | Data / View | Analysis View生成時に不正列、空母集団、非決定的式を拒否する | MUST |
| FR-023 | Explore | Dataset overview、schema、型、欠損率、cardinalityを表示する | MUST |
| FR-024 | Explore | 数値列・カテゴリ列の記述統計と分布を生成する | MUST |
| FR-025 | Explore | 欠損パターンおよび列別missingnessを確認できる | MUST |
| FR-026 | Explore | 二変量の散布、箱ひげ、クロス集計および関連指標を生成できる | MUST |
| FR-027 | Explore | group-by集計および時系列推移を生成できる | MUST |
| FR-028 | Explore | correlation / association matrixを型に応じて生成できる | SHOULD |
| FR-029 | Explore | Chart Specificationを保存し、同じDataset Versionで再実行できる | MUST |
| FR-030 | Explore | 探索実行のResultとArtifactを保存する | MUST |
| FR-031 | Explore | 保存した探索Resultに観察メモと限界をAnnotationできる | MUST |
| FR-032 | Explore | 探索ResultからCausalまたはPredictive Analysis Specificationのdraftを作成できる | SHOULD |
| FR-033 | Explore | 探索結果をEXPLORATORYと表示し、確認的結論として自動昇格しない | MUST |
| FR-034 | Explore | 可視化の描画条件、集計条件、samplingおよびcode versionを保存する | MUST |
| FR-035 | Causal | 複数algorithm / parameterでcausal discoveryを実行できる | MUST |
| FR-036 | Causal | User-definedまたはImported GraphをDiscoveryなしで登録できる | MUST |
| FR-037 | Causal | DAG、CPDAG、PAGおよびendpoint semanticsを保持する | MUST |
| FR-038 | Causal | Graph Candidateの共通条件、変更条件およびedge差分を比較できる | MUST |
| FR-039 | Causal | FIXED Graphからchild DRAFTを作成し、編集理由を記録して再固定できる | MUST |
| FR-040 | Causal | Population、Treatment、Comparator、Outcome、Time、Estimand、Decision UseをCausal Questionに固定する | MUST |
| FR-041 | Causal | assignment、time zero、eligibility、strategy、adjustment set、assumptionsをCausal Designに固定する | MUST |
| FR-042 | Causal | Graph、Question、DesignからIdentification Resultを生成する | MUST |
| FR-043 | Causal | Identificationは全reasonを収集後、確定的不整合をreview statusより優先してstatus決定する | MUST |
| FR-044 | Causal | 型、欠測、post-treatment、sample size、overlapをData Eligibilityとして評価する | MUST |
| FR-045 | Causal | Treatment / Outcome inferred typeを正規化文字列で保存し、外部型objectを永続化しない | MUST |
| FR-046 | Causal | Identification、Eligibility、Estimator互換性を満たす場合のみEstimationを受け付ける | MUST |
| FR-047 | Causal | ATEまたはATTと区間推定を生成できる | MUST |
| FR-048 | Causal | overlap、balance、weight、sample loss等をDiagnostics Resultとして分離保存する | MUST |
| FR-049 | Causal | Placebo TreatmentおよびData SubsetによるRefutationを実行できる | MUST |
| FR-050 | Causal | Adjustment SetおよびPropensity ClippingのSensitivityを実行できる | MUST |
| FR-051 | Causal | 同一Project・Datasetの先行Discoveryを確認し、確認的Estimationへ探索後推論警告を保存する | MUST |
| FR-052 | Causal | 同一条件のRERUNと条件変更のREVISEDを区別し、changed dimensionsとreasonを保存する | MUST |
| FR-053 | Causal | 科学的負結果をExecution failureと区別する | MUST |
| FR-054 | Causal | Causal ResultからQuestion、Design、Graph、Eligibility、上流Resultへ遡れる | MUST |
| FR-055 | Predictive | 表形式Binary ClassificationとRegressionをPrediction Taskとして作成できる | MUST |
| FR-056 | Predictive | Prediction unit、target、prediction time、horizon、intended use、deployment populationを固定する | MUST |
| FR-057 | Predictive | feature setと各featureのavailability cutoffを固定する | MUST |
| FR-058 | Predictive | random、stratified、group、time-based splitを選択できる | MUST |
| FR-059 | Predictive | target leakage、future leakage、group leakage、split overlapをBackendで拒否する | MUST |
| FR-060 | Predictive | imputation、encoding、scaling等のfitをtraining partitionのみに限定する | MUST |
| FR-061 | Predictive | Algorithm Registryからtask対応modelを選択できる | MUST |
| FR-062 | Predictive | validation partitionまたはcross-validationでhyperparameter selectionを行える | SHOULD |
| FR-063 | Predictive | 固定済みspecとsplitからmodelをtrainingできる | MUST |
| FR-064 | Predictive | test partitionをmodel selectionに使用せず、最終評価まで隔離する | MUST |
| FR-065 | Predictive | classificationとregressionでtask対応metricを生成する | MUST |
| FR-066 | Predictive | classificationでclass balance、threshold、calibrationを確認できる | MUST |
| FR-067 | Predictive | 指定subgroupごとのperformanceとsample sizeを確認できる | SHOULD |
| FR-068 | Predictive | prediction、residual / error、metric、model、preprocessorをArtifactとして保存する | MUST |
| FR-069 | Predictive | global / local Predictive Explanationを生成できる | SHOULD |
| FR-070 | Predictive | Predictive Explanationを因果説明と区別して表示・exportする | MUST |
| FR-071 | Predictive | intended use、training data、metric、limitationsをModel Cardへ記録する | SHOULD |
| FR-072 | Predictive | 同一Taskのmodel、split、feature、metric差分を比較できる | MUST |
| FR-073 | Predictive | Prediction Taskからsource Context、Dataset、Analysis Viewへ遡れる | MUST |
| FR-074 | Workflow | Analysis FamilyをEXPLORATORY、CAUSAL、PREDICTIVEとして識別する | MUST |
| FR-075 | Workflow | Family別PlannerをRegistryから解決する | MUST |
| FR-076 | Workflow | Plannerはversionedで不変なExecution Planを生成する | MUST |
| FR-077 | Workflow | Stage Typeをnamespace、name、versionで識別する | MUST |
| FR-078 | Workflow | PlanはStage dependencyとinput/output bindingをDAGとして保持する | MUST |
| FR-079 | Workflow | Stage RunnerをRegistryから解決し、Executorへif/elif分岐を集約しない | MUST |
| FR-080 | Workflow | canonical lifecycle/application serviceがExecutionのclaim、state、cancel、retry、Result/Artifact metadata commitを所有し、Generic Executorはowned workflow context内で依存順、Stage sequencing、runner invocationを実行する | MUST |
| FR-081 | Workflow | Stage ExecutionとAttemptのstatus、開始・終了時刻、errorを保持する | MUST |
| FR-082 | Workflow | 同一idempotency keyと同一bodyのCommandを重複実行しない | MUST |
| FR-083 | Workflow | 技術retryは同一Execution、条件変更は新Executionとする | MUST |
| FR-084 | Workflow | 上流Artifactを下流Stage inputへ型付きでbindingする | MUST |
| FR-085 | Workflow | 未登録Runner、cycle、missing output、schema mismatchをPlan受付時に拒否する | MUST |
| FR-086 | Workflow | Stageごとのtimeout、resource limit、random seedを記録する | SHOULD |
| FR-087 | Workflow | code、runtime、library、schema versionをExecution snapshotへ固定する | MUST |
| FR-088 | Workflow | Execution StatusとResult analytical statusを分離する | MUST |
| FR-089 | Workflow | Generic validationとFamily-specific validationを分離して実行する | MUST |
| FR-090 | Result / Lineage | 共通Result Envelopeにfamily、type、schema version、execution、stageを保持する | MUST |
| FR-091 | Result / Lineage | Result payloadはFamily・Type別Schemaで検証する | MUST |
| FR-092 | Result / Lineage | Artifactにfamily、type、schema version、media type、hash、sizeを保持する | MUST |
| FR-093 | Result / Lineage | 同一または明示的に互換なResult Typeのみ定量比較する | MUST |
| FR-094 | Result / Lineage | Project単位でExplore、Causal、Predictiveのsummaryを横断表示する | MUST |
| FR-095 | Result / Lineage | ResultからContext、Dataset、View、Spec、Plan、Stage、Artifactへ遡る | MUST |
| FR-096 | Result / Lineage | 探索Resultから分析draft等のcross-analysis relationを明示保存する | MUST |
| FR-097 | Result / Lineage | Result、Graph、Analysis SpecificationまたはProjectへAnnotationできる | MUST |
| FR-098 | Result / Lineage | 採用判断、仮定、適用範囲、限界、次ActionをAnnotationへ記録できる | MUST |
| FR-099 | Result / Lineage | Manifest、Result summary、Specification、Artifact参照をexportできる | MUST |
| FR-100 | Result / Lineage | 保存済みResultを上書きせず、訂正は新ResultまたはAnnotationで行う | MUST |
| FR-101 | Result / Lineage | 改訂Executionとbase ExecutionのedgeをLineage表示する | MUST |
| FR-102 | Result / Lineage | AUC等とATE等を単一Scoreへ正規化しない | MUST |
| FR-103 | Result / Lineage | Viewerがread-onlyで全来歴を確認できる | MUST |
| FR-104 | UI | Project WorkspaceはProject-global surfaceとAnalytical Family navigationを別navigation dimensionとして提供する | MUST |
| FR-105 | UI | route-backed navigationは独立URL、deep link、reload、browser back / forwardに対応する | MUST |
| FR-106 | UI | 選択中Project、Context Version、Dataset Version、Analysis Viewを常時確認できる | MUST |
| FR-107 | UI | 操作可否をBackendの正本状態から導出し、拒否理由を表示する | MUST |
| FR-108 | UI | Result、Execution、Graph、Analysisへ直接遷移できる | MUST |
| FR-109 | UI | 非同期処理のloading、empty、partial、error、cancel状態を区別する | MUST |
| FR-110 | UI | 一覧と比較でfamily、status、dataset、context、dateによるfilterを提供する | SHOULD |
| FR-111 | UI | keyboard操作、focus、label、contrast等の基本accessibilityを満たす | MUST |
| FR-112 | UI | Exploratory、Predictive、Causalの用語と警告を明示的に分離する | MUST |
| FR-113 | API / CLI | HTTP APIをversioned pathとversioned payloadで提供する | MUST |
| FR-114 | API / CLI | 作成系APIでidempotency keyを受け付ける | MUST |
| FR-115 | API / CLI | validation、conflict、not found、forbidden、execution failureをcanonical errorで返す | MUST |
| FR-116 | API / CLI | 既存Executionから再実行用prefillを取得できる | MUST |
| FR-117 | API / CLI | ExportをAPIとUIから同一contractで生成する | MUST |
| FR-118 | API / CLI | CLIからFamily別Specificationをsubmitしstatus/resultを取得できる | SHOULD |
| FR-119 | API / CLI | 履歴を持たないCLIは探索後警告等を独自推測しない | MUST |
| FR-120 | API / CLI | OpenAPIとSchema exampleを正本contractと同期する | MUST |
| FR-121 | Security / Ops | Project単位でread、write、operate権限を検証する | MUST |
| FR-122 | Security / Ops | 作成、更新、archive、execution、cancel、retry、exportをaudit logへ記録する | MUST |
| FR-123 | Security / Ops | preview、artifact、prediction outputへの機微データ露出を権限と設定で制限する | MUST |
| FR-124 | Security / Ops | Artifact downloadでProject権限とcontent dispositionを検証する | MUST |
| FR-125 | Security / Ops | Project archive後も監査・Lineageを保持する | MUST |
| FR-126 | Security / Ops | Metadata、Artifact、logの保持期間と削除policyを設定できる | SHOULD |
| FR-127 | Security / Ops | API、DB、Worker、Artifact Storeのhealth / readinessを提供する | MUST |
| FR-128 | Security / Ops | Algorithm、Runner、size limit、timeoutをconfigurationで管理する | MUST |
| FR-129 | Navigation | Exploratory / Predictive / Causalをfirst-classなAnalysis Familyとして常時選択可能にする | MUST |
| FR-130 | Navigation | Current Familyをactive stateとcanonical routeの双方で一意に識別できる | MUST |
| FR-131 | Navigation | Family-local navigationにはselected Familyが所有するNavigation Stageだけを表示する | MUST |
| FR-132 | Navigation | Family切替時は対象Familyが宣言するdefault Navigation Stageへ遷移する | MUST |
| FR-133 | Navigation | FamilyごとにStage ID、label、order、default Stageを独立して定義できる | MUST |
| FR-134 | Navigation | Family間でStage数・名称を揃える目的のdummy/common Stageを導入しない | MUST NOT |
| FR-135 | Navigation | Navigation Stageの表示順をwizard completion、runtime dependency、実行前提として強制しない | MUST NOT |
| FR-136 | Navigation | canonical URLからProject、Family、Navigation Stageを復元できる | MUST |
| FR-137 | Navigation | reload、browser back、browser forwardでFamily / Stage stateをdeterministicに復元できる | MUST |
| FR-138 | Navigation | unknown Family / Stageをsilent fallbackで別contextへ意味変換せず、明示的errorと有効な遷移先を提示する | MUST |
| FR-139 | Navigation | Project Management、Research Context、Data、Results / Lineage等をAnalytical Familyと同一taxonomyへ混在させない | MUST |
| FR-140 | Navigation / Runtime | Navigation Stageをruntime `StageType` / `StageDefinition` / `StageExecution`として再利用・継承しない | MUST NOT |
| FR-141 | Navigation / Runtime | Navigation StageとExecution Stageの1:1 mappingを要求するcontractを導入しない | MUST NOT |
| FR-142 | API / CLI | CLI / Python library / backend use case / runtime executorはCurrent Navigation Stageを指定せずanalysis executionを開始できる | MUST |
| FR-143 | Workflow | runtime layerはNavigation Stage ID、browser route、tab/sidebar stateへ依存しない | MUST NOT |
| FR-144 | Capability | concrete Navigation Stage catalogは各Family-specific Capabilityが所有する | MUST |
| FR-145 | Capability | generic application layerはFamily-specific Stage semanticsを集中所有しない | MUST NOT |
| FR-146 | Exploratory | `Profile / Data Quality / Distribution / Relationships / Comparison / Findings`をFamily-local Navigation Stageとして提供する | MUST |
| FR-147 | Exploratory | Visualizationは各分析Stageの表現手段とし、独立Navigation Stageを設けない | MUST NOT |
| FR-148 | Exploratory | Findingsは既存Result / Annotation / Lineageを利用可能とし、新規persistent Finding resourceを必須化しない | MUST |
| FR-149 | Predictive | `Setup / Train / Predict / Metrics / Explainability / Model Management`をFamily-local Navigation Stageとして提供する | MUST |
| FR-150 | Predictive | 既存Predictive UIの設定項目、validation、generated `predictive-analysis-spec/1` semanticsを全量保持する | MUST |
| FR-151 | Predictive | MetricsとExplainabilityを異なる目的のNavigation Stageとして扱い、Predict Stage導入を理由に新規standalone scoring engineを必須化しない | MUST |
| FR-152 | Predictive | Model Managementは現行scopeではfitted model、model card、artifact、lineageのread-oriented確認を中心とする | MUST |
| FR-153 | Causal | `Setup / Discovery / Identification / Estimation / Effects / Diagnostics / Sensitivity`をFamily-local Navigation Stageとして提供する | MUST |
| FR-154 | Causal | IdentificationとEstimationを別Navigation Stageとして扱い、識別可能性と有限標本推定を混同しない | MUST |
| FR-155 | Causal | EstimationとEffectsを別Navigation Stageとして扱い、推定設定と推定結果の閲覧・利用を混同しない | MUST |
| FR-156 | Causal | DiagnosticsとSensitivityを別Navigation Stageとして扱う | MUST |
| FR-157 | Domain / Compatibility | 既存`AnalysisSpecification.analysis_family`をFamily discriminatorとして再利用し、duplicate Family field/enumを追加しない | MUST |
| FR-158 | Domain / Compatibility | AnalysisSpecification / ExecutionPlan / Execution / StageExecutionへNavigation Stage fieldを追加しない | MUST NOT |
| FR-159 | Compatibility | legacy analytical routeはcanonical Family / Stage routeへ互換的にnormalizeできる | MUST |
| FR-160 | Compatibility | Family / Stage navigation導入を理由にDB schema migrationまたはnavigation-state DB persistenceを導入しない | MUST NOT |
| FR-161 | Scope | LightGBM / DoWhy / EconML等のexternal analytical engineを必須dependencyとして追加しない | MUST NOT |
| FR-162 | Scope | Overview / FlagshipをAnalytical Family peerとして追加しない | MUST NOT |

## 6. 非機能要件

| ID | 品質特性 | 要件 |
| --- | --- | --- |
| NFR-001 | 再現性 | 同一snapshot、code version、seed、runtimeで再実行可能な情報を保持する |
| NFR-002 | 追跡可能性 | すべてのResultがProject、Context、Dataset、Spec、Execution、Artifactへ遡れる |
| NFR-003 | 決定性 | Canonical JSONとhash生成はfield順やprocessに依存しない |
| NFR-004 | 応答性能 | 通常一覧・詳細APIの95 percentileを2秒以内、重い集計は非同期化する |
| NFR-005 | 拡張性 | 新Analysis Familyを既存Executor変更なしにRegistry追加できる |
| NFR-006 | 信頼性 | Worker再起動時もclaim、retry、artifact commitの二重実行を防ぐ |
| NFR-007 | 整合性 | Metadata transactionとArtifact書込みの失敗補償を定義する |
| NFR-008 | 安全性 | 認証、認可、入力検証、path traversal防止、secret非露出を行う |
| NFR-009 | Privacy | 機微列、prediction、local explanationの表示・exportを最小化できる |
| NFR-010 | 可用性 | APIとWorkerの障害を分離し、実行中断と再開可否を明示する |
| NFR-011 | 観測性 | structured log、correlation id、execution id、stage id、metricを出力する |
| NFR-012 | Accessibility | 主要操作をkeyboardで実行でき、状態を色だけで伝えない |
| NFR-013 | Schema evolution | すべてのSpec、Plan、Result、Artifact descriptorにschema versionを持つ |
| NFR-014 | 互換性 | `causal-analysis-spec/2`の正規contractおよび保存済みCausal Resultをschema versionに従って読取可能に保つ |
| NFR-015 | Testability | Domain、Planner、Runner、API、Worker、UI、scientific benchmarkを分離testできる |
| NFR-016 | Scientific transparency | 仮定、warning、negative result、limitationを省略せず表示する |
| NFR-017 | Resource control | upload size、row count、column count、memory、timeoutに明示上限を持つ |
| NFR-018 | Dependency direction | Product DomainからWeb Framework、ORMおよびlegacy packageへ依存しない |
| NFR-019 | Documentation | 現行の正本requirements/design snapshotだけで機能・データ・API・詳細設計を理解できる |
| NFR-020 | 移植性 | Local filesystemとobject storageをPortで切り替えられる |
| NFR-021 | Navigation separation | Navigation concernの変更がruntime execution lifecycleへ不要に伝播しない |
| NFR-022 | Navigation determinism | 同一Project / Family / Stage routeは同一navigation stateへdeterministicに復元される |
| NFR-023 | Maintainability | Family-specific Navigation Stage catalogをCapability ownershipで局所化する |
| NFR-024 | Testability | Navigation descriptor、route、renderer binding、runtime independenceをunit/integration/E2Eで分離検証できる |
| NFR-025 | Portability | CLI / library executionがWeb UI route、tab/sidebar state、NavigationStageDescriptorへ依存しない |
| NFR-026 | Accessibility | Current Family / Stageを色だけでなくsemantic active state、label、focus等でも識別できる |
| NFR-027 | Performance | navigation metadata取得・renderingがanalysis executionのcritical pathへ不要なI/Oまたはblocking dependencyを追加しない |

## 7. 科学・統計・分析上の要件

| ID | 要件 |
| --- | --- |
| AR-001 | 探索的可視化は仮説生成であり、因果結論または確認的検定へ自動変換しない |
| AR-002 | 予測性能は因果効果を示さない |
| AR-003 | Predictive Explanationはmodel behaviorの説明でありcausal explanationではない |
| AR-004 | 同一データで探索後に確認的分析を行った事実を警告とLineageで保持する |
| AR-005 | 因果推定はIdentification ResultとData Eligibility Resultを参照してgateする |
| AR-006 | Identification statusは全reasonを収集後に決定する |
| AR-007 | Collider判定はback-door path上のcolliderまたはその子孫を対象とする |
| AR-008 | Eligibilityの型はBINARY、CONTINUOUS、UNSUPPORTED等の正規値で保存する |
| AR-009 | 外部libraryのdtype objectまたはmodel objectをJSON正本へ保存しない |
| AR-010 | Estimation前提不成立時は数値を無理に返さず分析状態を保存する |
| AR-011 | Predictive preprocessingはtrain partitionのみでfitする |
| AR-012 | test partitionをfeature selection、model selection、threshold selectionに利用しない |
| AR-013 | 時系列Taskは未来観測がtrain featureへ混入しないsplitを使用する |
| AR-014 | 同一entityがtrainとtestへ跨る場合はgroup leakageを検査する |
| AR-015 | classification metricはclass imbalance、threshold、calibrationと併記する |
| AR-016 | subgroup metricはsample sizeと不確実性を併記する |
| AR-017 | Result比較は同一Task / Estimand / Outcome等の比較可能性を検証する |
| AR-018 | AUC、RMSE、ATE等を単一の優劣scoreへ変換しない |
| AR-019 | random seedだけでなくsplit indexまたはpartition artifactを保存する |
| AR-020 | local explanationやprediction rowを機微情報として扱える |
| AR-021 | Navigation Stageの表示順を分析上必須の実行順序として解釈しない |
| AR-022 | Family間でStage数・名称を揃えることを科学的workflow要件としない |
| AR-023 | Causal Identificationでは観測データと仮定からestimandが識別可能かをEstimationと分離して扱う |
| AR-024 | Causal Effectsは推定されたeffectの閲覧・利用を扱い、estimator configurationと混在させない |
| AR-025 | Predictive MetricsとPredictive Explainabilityを別目的として扱い、feature importance等をcausal effectへ読み替えない |
| AR-026 | Exploratory Findings / visualizationをcausal conclusionまたはconfirmatory resultへ自動昇格しない |

## 8. 状態要件

### 8.1. Project

```text
ACTIVE → ARCHIVED
```

ARCHIVEDからACTIVEへの復元は管理操作として別途定義するまで対象外とする。

### 8.2. Versioned Resource

```text
DRAFT → FIXED
```

FIXED Resourceは上書きしない。変更時は新Versionまたはchild DRAFTを作成する。

### 8.3. Execution

```text
QUEUED → RUNNING → SUCCEEDED
                 ↘ FAILED → QUEUED（technical retry）
QUEUED / RUNNING → CANCELLED
```

### 8.4. Stage Execution

```text
PENDING → READY → RUNNING → SUCCEEDED
                       ↘ FAILED
PENDING / READY → SKIPPED_DUE_TO_PREREQUISITE
```

### 8.5. Analytical Status

Result Typeごとに許可statusを定義する。Execution Statusと混在させない。

### 8.6. Navigation State

```text
Project + Current Family + Current Navigation Stage
```

- Current Family / Navigation StageはURL/application navigation stateとして扱う。
- DBへworkspace preferenceとして永続化しない。
- Family切替時のlast-stage memoryを必須化しない。
- Navigation stateをAnalysisSpecification、ExecutionPlan、Execution、StageExecutionへ保存しない。

## 9. 権限要件

- Resourceは必ずProjectへ所属する
- Project read権限がない利用者へmetadata、preview、Artifact、Resultを返さない
- write権限はContext、View、Specification、Annotationの作成・更新に必要
- execute権限はPlan submit、cancel、retryに必要
- Operator権限はsystem configuration、retention、health detailに必要
- 認可失敗はResource存在を推測できない応答を選択できる

## 10. データ保持・監査要件

- Dataset Version、Result、Artifact metadata、Execution snapshotはappend-onlyを基本とする
- Project archiveで物理削除しない
- Artifact物理削除時もhash、descriptor、削除日時、理由を監査記録へ残す
- Auditにはactor、action、resource、project、request id、timestamp、outcomeを含める
- Annotation変更履歴を保持する

## 11. 対象外要件

- Multi-class classification
- survival analysis、forecasting、ranking、recommendation
- online inference endpoint
- model deployment / registry / monitoring
- arbitrary Python execution
- arbitrary SQL query
- dashboard layout editor
- causal effectの自動保証
- unbounded AutoML
- automatic business decision
- LightGBM / DoWhy / EconML等のexternal analytical engine追加
- Navigation stateのDB persistence / last-stage memory
- Overview / FlagshipをAnalytical Family peerとして追加すること
- 新規persistent Findings / Evidence domain modelの必須化

## 12. 総合完了条件

1. E2E-01〜E2E-10がWeb API、Worker、Persistence、FrontendおよびCLI/library境界を通して成立する。
2. FR-001〜FR-162に実装または明示的な承認済み非実装判定がある。
3. NFR-001〜NFR-027の検証証跡がある。
4. AR-001〜AR-026を自動test、scientific benchmarkまたはreview checklistで検証する。
5. `causal-analysis-spec/2`および`predictive-analysis-spec/1`の既存正規contractを読取り、既存scientific/regression testが通る。
6. `AnalysisSpecification.analysis_family`を再利用し、duplicate Family discriminatorを追加していない。
7. AnalysisSpecification / ExecutionPlan / Execution / StageExecutionへNavigation Stage fieldを追加していない。
8. CLI / Python library / backend use case / runtime executorがCurrent Navigation Stageなしで既存analysisを実行できる。
9. Product Domain / runtime execution layerからbrowser route / Navigation Stageへの新規逆依存がない。
10. Predictive既存設定項目およびgenerated specification semanticsが保持される。
11. 正本文書、OpenAPI、DB schema、Frontend文言およびtestが同じFamily / Stage / Execution用語とcontractを使用する。

## 13. CHANGE LOG

### 13.4. ENH-E4 Canonical Execution Architecture Requirements

- canonical Execution lifecycle / StageExecution / Result / Artifact / Lineage authorityをrequirementsへ統合した。
- Family-specific Analysis Specificationとgeneric workflow coreの境界を明確化した。
- FR-001〜FR-128、NFR-001〜NFR-020、AR-001〜AR-020を現行requirements baselineとして継承する。

### 13.5. ENH-E5 Family × Navigation Stage Application Architecture Requirements

- FR-104 / FR-105をProject Workspaceの新navigation architectureに合わせて改定した。
- FR-129〜FR-162を追加し、Family / Navigation Stage、Capability ownership、Navigation / Runtime separation、Family-specific Stage set、互換性とscope境界を定義した。
- NFR-021〜NFR-027、AR-021〜AR-026、Navigation State要件を追加した。
- 既存`AnalysisSpecification.analysis_family`を再利用し、Navigation Stageをpersistent analysis/runtime modelへ追加しないことを明示した。
