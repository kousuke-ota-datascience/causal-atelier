# Coding Agent Prompt — ENH-E5 `SINGLE_EXECUTION` Gate

入力variable: `GATE_ID`, `TRIAL_NO`。

1. branch `feature/ariadne_mvp_e5`と、正確なbaseline/current protected stateを確認する。
2. freeze済み`06_Ariadne_ENH-E5_<GATE_ID>_implementation_instruction.md`をimplementation authorityとして読む。
3. freeze済み07はacceptance target理解のために読む。変更してはならない。
4. Active Gate scopeのみを実装する。
5. 06で要求されたfocused + Gate-wide self-verificationを実行する。
6. exact candidate SHAとimplementation completion reportを記録する。
7. `READY_FOR_TEST`または明示的な`BLOCKED_*`で停止する。
8. PASS/FAILのGate Decisionを出してはならない。
