# ENH-E5 Enhancement 構想・要件改定計画

文書区分: Planning / Background Artifact（計画・背景資料）
状態: `DRAFT_FOR_REVIEW`（レビュー前ドラフト）

## 1. 課題

現行UIではanalytical Familyとworkflow/view contextに相当するnavigation itemが同じleft sidebarへ混在しており、Ariadneの分析能力を「複数のanalytical perspective」として扱うapplication modelがUI/route/capability ownershipに明示されていない。

またbackendにはgeneric Execution Stage abstractionがあるため、UI上のStageをそのままExecution Stageへ流用すると、navigation concernとruntime execution lifecycleが混線するリスクがある。

## 2. 目的

Ariadneのanalytical capabilityを `Family -> Navigation Stage*` として再構成し、Exploratory / Predictive / Causalをfirst-classなanalytical contextとして横断できるnavigation architectureを確立する。

## 3. 目標状態

- 上部横タブに`Exploratory / Predictive / Causal`を常時表示する。
- 左sidebarはcurrent Familyが提供するNavigation Stageだけを表示する。
- capabilityがconcrete Stage catalogを所有する。
- URLでCurrent Family / Stageを表現し、deep link / browser historyを成立させる。
- current predictive configuration/semanticsを完全保持する。
- current causal/exploratory operationsをStageへ再配置し、機能欠落を発生させない。

## 4. 対象範囲（In scope）

### Application / architecture
- Family/Navigation Stage descriptor model
- capability-owned Stage定義
- descriptor参照API
- frontendのFamily/Stage navigation
- URL route / deep link / browser history
- legacy analytical route互換

### FamilyごとのStage構成

Exploratory:
`Profile`, `Data Quality`, `Distribution`, `Relationships`, `Comparison`, `Findings`

Predictive:
`Setup`, `Train`, `Predict`, `Metrics`, `Explainability`, `Model Management`

Causal:
`Setup`, `Discovery`, `Identification`, `Estimation`, `Effects`, `Diagnostics`, `Sensitivity`

### 互換性（Compatibility）
- Predictive既存configuration fieldを100%保持
- 現行execution specのdefault/semanticsを保持
- 現行Results / Lineageのcross-family挙動を保持
- 現行Research Context / Dataset / Analysis View semanticsを保持

## 5. 明示的な対象外（Out of scope）

- LightGBM adapter
- DoWhy adapter
- EconML estimator
- 新規standalone Predict execution engine/scoring service
- model registry/deployment lifecycle CRUD
- CausalのAnalysis Management Stage
- Overview/Flagship top-level workspace
- 新規Findings/Evidence永続domain model
- AnalysisResult/Result schema再設計
- navigation stateのDB永続化
- Family間で共通Stage taxonomyを強制すること
- 厳密なwizard/sequential navigation

## 6. 要件・設計への想定影響

影響大:
- information architecture
- frontend route/state model
- capability ownership contract
- API descriptor contract

影響中:
- Family固有UI composition
- test/e2e matrix

変更なしを想定:
- analytical algorithm
- execution lifecycle semantics
- 永続analysis/result schema
- migration schema

## 7. 初期Gate分解

| Gate | PASS時に成立すべきsemantic claim |
|---|---|
| G00 | Family/Navigation Stage contractとcapability-owned catalogがExecution Stageから独立して依存可能になる。 |
| G01 | global workspaceとlegacy linkを保持したまま、Family/Stage URLとcatalogでproduct navigationを駆動できる。 |
| G02 | 既存configuration/executionとの完全互換を保ち、Predictive capabilityを6つのNavigation Stageから利用できる。 |
| G03 | IdentificationとEstimationを明示的に分離し、Causal capabilityを7つのNavigation Stageから利用できる。 |
| G04 | 独立したVisualization Stageを設けず、Exploratory capabilityを6つのanalytical-view Stageから利用できる。 |
| G05 | 完成したnavigation modelについて、cross-familyのcontext/result継続性と全面的なregression保護が成立する。 |

## 8. 主なリスク

1. **Semantic collision:** Navigation Stageが誤ってExecution `StageType`を再利用する。
2. **Predictive regression:** visible fieldは残るが、hidden spec defaultが変わる。
3. **State regression:** Stage切替で編集中form値/contextが失われる。
4. **Routing regression:** browser back/forwardまたはdirect URLにより想定workspace stateを迂回する。
5. **Scope creep:** 新規analytical engineやresult-domain再設計がnavigation改修へ混入する。

## 9. Coding開始前に必要な決定

- scopeおよびtarget architectureのHuman approval。
- branch baseline SHAの完全確定。
- G00 06/07のfreeze。


---

# ENH-E5 要件改定

Document class: 要件 Revision Artifact
状態: `DRAFT_FOR_REVIEW`（レビュー前ドラフト）

## 1. Before / After サマリ

### Before（現状）
- analytical workspaceが単一の左navigation軸に混在している。
- UI navigationでFamilyが独立したglobal contextとして表現されていない。
- causal discovery/inferenceおよびpredictive/exploratory workspaceが、Family-owned Stage中心ではなくpage/workspace中心で構成されている。

### After（変更後）
- analytical navigationをglobal FamilyとFamily-local Navigation Stageの2次元で構成する。
- concrete Stage setはcapabilityが所有する。
- current Family/StageをURLで一意に指定できる。
- 既存analytical behaviorは保持し、Stage surfaceへ再構成する。

## 2. 改定要件

| ID | 要件 | Acceptance上の意味 | 主担当Gate |
|---|---|---|---|
| E5-REQ-001 | Familyをglobal analytical navigation dimensionとして明示する。 | Top navigationにExploratory/Predictive/Causalが表示され、current Familyが識別できる。 | G01 |
| E5-REQ-002 | StageをFamily-local navigation/work contextとして扱う。 | selected Familyに対応するStageだけがleft sidebarに表示される。 | G01 |
| E5-REQ-003 | Navigation StageをExecution Stageから分離する。 | Navigation descriptorがExecution StageType/StageDefinition/StageExecutionを再利用・継承しない。 | G00 |
| E5-REQ-004 | concrete Stage catalogはCapabilityが所有する。 | 各capability moduleが自Familyのstage set/default/orderを定義し、product layerはgeneric aggregation/validationのみ行う。 | G00 |
| E5-REQ-005 | Family/Stage catalogのcanonical sourceを一つにする。 | backend descriptor APIからcatalogを取得し、frontendに別の完全catalogを重複定義しない。 | G00 |
| E5-REQ-006 | Current Family/Stageをdeep-linkableにする。 | URL `/projects/{project_id}/analysis/{family}/{stage}` でdirect load/back/forwardが成立する。 | G01 |
| E5-REQ-007 | navigation stateをE5では永続化しない。 | Family/Stageをworkspace-state/DB schemaへ追加しない。 | G01 |
| E5-REQ-008 | Predictive既存設定を100%保持する。 | 全visible fieldとspec defaultがinventoryでBefore/After対応し、欠落/semantic changeがない。 | G02 |
| E5-REQ-009 | Predictiveを6 Navigation Stageへ再配置する。 | Setup/Train/Predict/Metrics/Explainability/Model Managementが表示される。 | G02 |
| E5-REQ-010 | Causalを7 Navigation Stageへ再配置する。 | Setup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityが表示される。 | G03 |
| E5-REQ-011 | IdentificationとEstimationを明確に分離する。 | UI/route上で別Stageとなり、識別結果と推定実行が混同されない。 | G03 |
| E5-REQ-012 | Exploratoryを6 analytical-view Stageへ再配置する。 | Profile/Data Quality/Distribution/Relationships/Comparison/Findingsが表示される。 | G04 |
| E5-REQ-013 | Visualizationを独立Stageにしない。 | Chart controls/outputはDistribution/Relationships/Comparison等の内部表現として配置される。 | G04 |
| E5-REQ-014 | Results/Lineageをcross-family global surfaceとして保持する。 | Family切替後も既存cross-analysis result/lineage機能へ到達できる。 | G05 |
| E5-REQ-015 | 既存analytical engineとresult persistence semanticsを変更しない。 | 新engine/dependency/schema migrationなしで既存testが通る。 | G05 |
| E5-REQ-016 | Family/Stage navigationはwizard化しない。 | 任意Stageへ移動でき、operation prerequisiteとnavigation progressionを同一視しない。 | G01 |
| E5-REQ-017 | legacy analytical URLsを互換維持する。 | `/explore`, `/causal`, `/predictive`がdocumented targetへredirect/normalizeされる。 | G01 |

## 3. 新しいinvariant（不変条件）

1. `Navigation Stage != Execution Stage`。
2. Family IDは既存`AnalysisFamily` semanticsを再利用する。UI labelはinternal IDと異なってよい。
3. abstract navigation layerはDiscovery/Train/Estimation等のdomain-specific semanticsを持ってはならない。
4. concrete Stage semanticsはcapabilityが所有し、product/application layerはgenericに集約する。
5. Stageの数・名称はFamilyごとに異なってよい。
6. navigation順序を科学的・運用上の完了順序と同一視しない。
7. Predictive既存settingとgenerated spec semanticsを保護対象のcompatibility contractとする。

## 4. 廃止・置換する要件上の前提

- 単一sidebar item listを主要analytical navigation taxonomyとする前提 — 廃止。
- UI Stageはexecution pipeline stageと1対1対応すべきという前提 — 明示的に不採用。
- 全Familyが共通Stage taxonomyを持つべきという前提 — 明示的に不採用。

## 5. 後続Enhancementへ延期する要件

- Overview/Flagship surface
- 専用Findings/Evidence persistence model
- standalone Predict execution service
- model registry/deployment lifecycle
- external analytical engine adapter


---

# ENH-E5 設計改定

Document class: 設計改定 Artifact
状態: `DRAFT_FOR_REVIEW`（レビュー前ドラフト）

## 1. Architecture decision

### DR-01 — Family identityとして`AnalysisFamily`を再利用する

**決定:** existing product-domain `AnalysisFamily` values `EXPLORATORY`, `CAUSAL`, `PREDICTIVE` are the internal Family IDs.

**理由:** current code already binds planners/specifications/results to these analytical families. Creating a second Family identity would introduce unnecessary translation.

**不採用案:** frontend-only string catalog disconnected from product domain.

### DR-02 — 独立したNavigation descriptor modelを導入する

想定するgeneric type:

```text
NavigationStageDescriptor
- stage_id
- label
- order

FamilyNavigationDescriptor
- family: AnalysisFamily
- label
- default_stage_id
- stages: tuple[NavigationStageDescriptor, ...]
```

このmodelにexecution dependency、input/output contract、runner ID、execution status、attempt lifecycleを含めてはならない（MUST NOT）。

### DR-03 — concrete catalogはCapabilityが所有する

想定ownership:

```text
src/ariadne/capabilities/exploratory/navigation.py
src/ariadne/capabilities/predictive/navigation.py
src/ariadne/capabilities/causal/navigation.py
```

各capabilityはimmutableな`FamilyNavigationDescriptor`を1つexportする。product/application codeはvalidationとaggregationのみを担当する。

### DR-04 — Backend descriptor APIをcanonical catalog sourceとする

想定endpoint:

```http
GET /api/v1/navigation/analysis
```

Response schema version: `analysis-navigation/1`。

Frontendはsemantic IDとDOM/rendering codeを結び付けるため、`(family_id, stage_id)`をkeyとするrenderer registryを保持してよい。ただし、stage order/label/defaultの完全catalogを別途二重管理してはならない（MUST NOT）。

### DR-05 — URLをCurrent Family/Stageのcanonical stateとする

Target canonical route:

```text
/projects/{project_id}/analysis/{family_slug}/{stage_slug}
```

Canonical family slugs:
- `exploratory`
- `predictive`
- `causal`

E5ではlast Family/StageをDBまたは`/workspace-state`へ永続化しない。

### DR-06 — Global project surfaceはFamilyの外側に置く

以下はglobal project-level surfaceとして維持する:
- Project Management
- Research Context
- Project / Data
- Results / Lineage

上部Family tabにはanalytical Familyのみを置く。E5では`Overview`を導入しない。

### DR-07 — Legacy analytical routeを新routeへnormalizeする

- `/projects/{id}/explore` -> `/projects/{id}/analysis/exploratory/profile`
- `/projects/{id}/causal` -> `/projects/{id}/analysis/causal/discovery`
- `/projects/{id}/predictive` -> `/projects/{id}/analysis/predictive/setup`

`context`、`data`、`results`はglobal routeとして維持する。

### DR-08 — persistence/schema migrationは行わない

Navigation catalogはcode-definedかつread-onlyとする。Current Family/StageはURL stateとする。既存AnalysisSpecification/Execution/Result/Artifactのpersistenceは変更しない。

実装中にschema migrationが真に必要と判明した場合は`BLOCKED_CONTRACT_AMBIGUITY`として停止する。architecture amendmentなしにmigrationを追加してはならない。

## 2. FamilyごとのStage mapping

### Exploratory

| Stage | 現行capabilityとの対応 | E5でのsemantic rule |
|---|---|---|
| Profile | dataset/profile/explore profile | dataset overview。必要な場合はAnalysis View contextの作成・選択を内包してよい |
| Data Quality | 既存profile/quality observation | 既にsupportされるfactのみ表示し、新規quality engineは追加しない |
| Distribution | DISTRIBUTION + 関連chart control | visualizationは表現手段として扱う |
| Relationships | ASSOCIATION + 関連chart | causal interpretationを行わない |
| Comparison | GROUP_SUMMARY / TIME_TREND + 関連chart | group/segment/cohort比較 |
| Findings | 保存済みexploratory Resultと既存annotation/linkage | 新規Findings entityは作らない |

### Predictive

| Stage | 現行capabilityとの対応 | E5でのsemantic rule |
|---|---|---|
| Setup | 現行Predictiveの全form field/specification | **既存fieldをすべて保持する** |
| Train | split validation + 現行full workflow launch/status | execution pipelineは既存split/prepare/train/evaluate/(explain)を維持 |
| Predict | 存在する場合、prediction-bearing output/artifact参照 | standalone scoring executionは追加しない |
| Metrics | Evaluation + Error Analysis result surface | metric engineは変更しない |
| Explainability | 既存Explanation result surface | predictive explanationはnon-causalとして維持 |
| Model Management | fitted model/model card/artifact/lineageのread-only surface | registry CRUD/deployment lifecycleは追加しない |

### Causal

| Stage | 現行capabilityとの対応 | E5でのsemantic rule |
|---|---|---|
| Setup | dataset/view/population/comparator/treatment/outcome/unit/time/window/estimand/assumptions | design context |
| Discovery | 現行causal discovery/graph candidate/direct graph registration | optional/non-sequential |
| Identification | fixed graph/strategy/adjustment/identification/data eligibility | Estimationと分離する |
| Estimation | estimator選択 + 許可されたestimation execution/revision | 現行estimatorのみ |
| Effects | treatment-effect result / comparison | resultの閲覧・利用 |
| Diagnostics | eligibility + estimation diagnostics | 妥当性確認 |
| Sensitivity | refutation + sensitivity | 現行methodのみ |

## 3. Predictive compatibility inventory — 保護対象

現行visible controlのうち、引き続き表現可能でなければならない項目（MUST）:

- Active Research Context
- Dataset Version
- Analysis View
- Task Type
- Prediction unit
- Target column
- Prediction time
- Horizon
- Intended use
- Deployment population
- Feature columns
- Excluded columns
- Split strategy
- Seed
- Train ratio
- Validation ratio
- Test ratio
- Explanation method
- Explanation sample size
- Local explanations flag

generated `predictive-analysis-spec/1` semanticsのうち、無断変更してはならない項目（MUST NOT）:

- feature availability cutoff = `PREDICTION_TIME`
- split strategy semanticsおよびratio/seed
- preprocessing: TRAIN fit、MEAN numeric imputation、numeric scaling、ONE_HOT categorical encoding
- model ID: logistic_regression.v1 / linear_regression.v1（現行parameterを保持）
- tuning partition: TRAIN + VALIDATION
- primary metric: current task typeに応じてROC_AUCまたはRMSE
- explanation dataset = TEST、sampling = FIRST_N、既存explanation method/local flag

## 4. UI state handling

Family/Stage navigationは、current analytical workspaceの未保存field値を破棄せずにvisibility/routingだけを変更しなければならない（MUST）。推奨実装はStage DOM/formをmountしたままpresentationを切り替える方式。refactoringでpanelをrender/unmountする場合は、明示的なfrontend draft stateですべての保護対象fieldを保持する。

## 5. Result model decision

現行generic Result envelopeを保持する。E5では新しい`AnalysisResult` hierarchyを導入せず、predictive metrics / causal effects / exploratory findingsを単一scalar schemaへ平坦化しない。

## 6. Migration / compatibility

- DB migration: target designでは`N/A`。
- API migration: additiveなread endpointのみ。
- route互換: legacy analytical routeをnormalize/redirectする。
- result/analysis spec schema: 変更なし。
- execution stage contract: 変更なし。


---

# ENH-E5 Target Architecture Decision Record（目標アーキテクチャ決定記録）

文書区分: Architecture Decision Artifact（アーキテクチャ決定資料）
状態: **DRAFT_FOR_HUMAN_APPROVAL**（Human承認待ちドラフト）

## ADR-1 Decision

独立した薄いapplication navigation modelを確立する:

```text
AnalysisFamily
  -> FamilyNavigationDescriptor
       -> NavigationStageDescriptor*
```

concrete descriptor instanceは各analytical capabilityが所有する。generic product/application codeはvalidation/aggregationを担当する。Frontendはread-only descriptor APIを利用し、stage IDをpresentation surfaceへbindingする。

## ADR-2 Invariants

1. Navigation StageはExecution Stageではない。
2. Navigation descriptorはrunner/lifecycle/dependency/input-output-contract semanticsを持たない。
3. concrete Stage semanticsはcapability-ownedとする。
4. 既存`AnalysisFamily`をFamily identityとして再利用する。
5. Backend descriptor APIをcanonical Stage catalog sourceとする。
6. E5ではCurrent Family/StageをURL stateとし、persisted stateにはしない。
7. Global project workspaceはFamily外に維持する。
8. Predictive既存configuration/spec semanticsを保護する。
9. 新規analytical engineまたはpersistent result modelを導入しない。

## ADR-3 API / route

- descriptor: `GET /api/v1/navigation/analysis`
- canonical page route: `/projects/{project_id}/analysis/{family_slug}/{stage_slug}`

## ADR-4 Capability catalog

Exploratory: Profile, Data Quality, Distribution, Relationships, Comparison, Findings.
Predictive: Setup, Train, Predict, Metrics, Explainability, Model Management.
Causal: Setup, Discovery, Identification, Estimation, Effects, Diagnostics, Sensitivity.

## ADR-5 Alternatives considered

### A. Frontend-static full catalog
不採用: capability semanticsを重複定義し、ownership contractを弱めるため。

### B. navigationにExecution StageTypeを再利用する案
不採用: Execution Stageはpipeline/runtime semanticsを持ち、UI contextと1対1対応しないため。

### C. Current Family/Stageをworkspace-stateへ永続化する案
E5では不採用: URLだけでshare可能かつhistory-awareなstateを表現できる。永続化すると、要件化されていないcross-device/session semanticsまで追加されるため。

### D. 4つ目の上部tabとしてOverviewを追加する案
E5では不採用: Overviewはanalytical Familyではなく、navigation dimensionを混在させるため。必要であれば後続Enhancementでglobal workspaceとして再検討する。

## ADR-6 Migration

DB migration: `N/A`。
API change: additive.
Route変更: additive canonical route + legacy normalization。
Execution/result schema migration: `N/A`。

## ADR-7 Approval

Human architecture owner: `PENDING`。
Approved at: `PENDING`
レビュー対象Baseline SHA: `46122c68333df03680b97c253a7b5d32bf9393e7`


---

# ENH-E5 Gate Decomposition（Gate分解） Record

文書区分: Architecture / Planning Artifact（アーキテクチャ・計画資料）
状態: `DRAFT_FOR_REVIEW`（レビュー前ドラフト）

## Decomposition principle

Gateは、後続が利用できるsemantic resultを持つ独立acceptance boundaryである。Coding量はWork Packageで分割する。

## Gates

| Gate | PASS時に成立すること | 後続が依存できる理由 |
|---|---|---|
| G00 | FamilyとNavigation Stageのapplication contractをExecution Stageから独立して成立させ、capability-owned canonical stage catalogとread APIを提供する。 | G01以降が、stable Family ID / stage ID / order / default Stage / catalog APIへ依存できる。 |
| G01 | canonical catalogを利用してtop Family tabs + Family-local Stage sidebarを成立させ、URL/deep link/history/legacy route compatibilityを確立する。 | Family-specific G02-G04が同一navigation shell上へStage contentを安全に配置できる。 |
| G02 | current Predictive workspaceをSetup/Train/Predict/Metrics/Explainability/Model Managementへ再配置し、既存設定項目とgenerated spec/execution semanticsの完全互換を成立させる。 | ユーザーとG05が、新navigation下でもcurrent Predictive capabilityがsemantically unchangedで利用できることへ依存できる。 |
| G03 | current Causal Discovery/Inference surfacesをSetup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityへ再配置し、IdentificationとEstimationの責務分離を明示する。 | ユーザーとG05が、causal design/execution/resultsをdistinct Stage contextで利用しつつ既存causal semanticsへ依存できる。 |
| G04 | current Explore & Visualize capabilityをProfile/Data Quality/Distribution/Relationships/Comparison/Findingsへ再配置し、visualizationをanalytical Stageではなく各Stageの表現手段として位置づける。 | ユーザーとG05が、EDAを探索観点別にnavigationしつつ既存exploratory resultsを失わず利用できる。 |
| G05 | 3 Familyのnavigation/Stage recomposition後に、project context・Results/Lineage・routing・existing analytical execution/persistenceがcross-familyで一貫することを確立する。 | ENH-E5全体をproduct-level verified contractとして利用・release判断できる。 |

## Dependency DAG

```text
G00 -> G01 -> G02 ----\
             G03 -----+-> G05
             G04 ----/
```

G02/G03/G04はすべてG01に依存する。G01 PASS後はFamily再構成contractとしてsemantically独立する。運用上の単純さから実行順をG02 -> G03 -> G04としてよい。G05は3つすべてに依存する。

## Work Package rationale

- G00: bounded domain/API contract。`SINGLE_EXECUTION`。
- G01: route/state/UI/historyが分離可能なcoding unitに跨るため`WORK_PACKAGE`。
- G02: compatibility inventory、UI再構成、regressionを1つのsemantic claim下のexecution unitとして扱うため`WORK_PACKAGE`。
- G03: mapping、Identification/Estimation分離、regressionを分割実行するため`WORK_PACKAGE`。
- G04: mapping、visualization/findings composition、regressionを分割実行するため`WORK_PACKAGE`。
- G05: 実装済みcontract全体のconvergence/regression acceptanceを行うため`SINGLE_EXECUTION`。

## Non-gates

- 「backend work」「frontend work」は単独でproduct semanticsを成立させないためGateにはしない。
- 個別Stage実装だけではFamily contract全体がcoherentにならず後続利用可能にならないため、個別StageをGateにはしない。
