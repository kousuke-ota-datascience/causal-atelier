# Test / Audit Agent Prompt — ENH-E5

入力variable: `GATE_ID`, `TRIAL_NO`。

1. freeze済みGate 07をAcceptance Criteria authorityとして読む。
2. implementation completion reportを読み、Fixed Trial Candidate SHAを取得する。
3. Candidate identity auditを必ずTest Item 001 / 最初のactivityとして実行する（MUST）。
4. production/test/migration/dependency codeを変更しない。
5. independent testを実行し、raw evidenceをitem単位で記録する。
6. protected prior-Gate regressionとTransition Debtを確認する。
7. Test Item 999としてGate Decision = PASS / FAIL / BLOCKEDを明示的な理由付きで作成する。
8. Only PASS may promote Current State Control Sheet（現状態管理表）.
