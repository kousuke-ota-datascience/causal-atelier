# 論理データ設計 — ENH-E5 revised scope

## 1. 永続データ

navigationのための新規persistent entityは不要。

AnalysisSpecification、Execution、StageExecution、Result、Artifact、Research Context、Dataset Version、Analysis View等の既存persisted entityは現行schemaを保持する。

## 2. 非永続navigation data

```text
FamilyNavigationDescriptor
  family: AnalysisFamily
  label: str
  default_stage_id: str
  stages: ordered tuple[NavigationStageDescriptor]

NavigationStageDescriptor
  stage_id: str
  label: str
  order: int
```

制約:
- family unique
- stage_id unique inside family
- Familyごとに有効な`default_stage_id`を正確に1つ持つ
- non-empty stages
- deterministic ordering
- no execution-stage lifecycle fields

## 3. Current navigation state（現在のnavigation状態）

Current Family/StageはURLにencodeする。DB rowではなく、E5ではworkspace-stateへ追加しない。
