# プロダクト構想メモ — ENH-E5 revised scope

Ariadneは単一の因果分析画面ではなく、Exploratory / Predictive / Causalという異なるanalytical perspectiveを一つのproject context上で扱うanalytical workspaceである。

ENH-E5ではこの概念をUI/navigation構造へ昇格させる。

- Family: global analytical perspective
- Stage: Family内の主要な作業・閲覧context
- Result/Lineage: Family横断のevidence trace surface

Family切替はfirst-class navigation operationであり、Stage順序はwizard progressを意味しない。
