# Ariadne ENH-E5 G00 実装指示書 — Gate Coding Contract（Gate実装契約）

文書区分: Primary Execution Contract（主要実行契約）
自己完結性: MUST（必須）

- プロジェクト: Ariadne
- Enhancement: ENH-E5
- Active Gate: G00
- Gate title: Family / Navigation Stage Domain Contract（Family / Navigation Stageドメイン契約）
- Branch: `feature/ariadne_mvp_e5`
- Baseline SHA: `46122c68333df03680b97c253a7b5d32bf9393e7`
- 契約状態: **DRAFT_FOR_REVIEW**（レビュー前ドラフト）
- Execution Mode: `SINGLE_EXECUTION`
- Current State Control Sheet（現状態管理表）: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Gate定義 / acceptance claim

### 目的
FamilyとNavigation Stageのapplication contractをExecution Stageから独立して成立させ、capability-owned canonical stage catalogとread APIを提供する。

### PASS後に後続Gateが利用できる成果
G01以降が、stable Family ID / stage ID / order / default Stage / catalog APIへ依存できる。

### この単位を1つのGateとする理由
この境界は、独立してaccept/protectできる1つのsemantic claimである。実装量が大きい場合は、Execution Modeが`WORK_PACKAGE`のときにWork Packageで分割する。

## 2. 実装時に有効な前提

- Familyはanalytical capabilityのcontextである。
- Navigation StageはUI/application上の作業・閲覧contextである。
- `Navigation Stage != Execution Stage` を維持する。
- Stageの名称・数はFamilyごとに異なってよい。
- Stage navigationを必須のsequential workflowとはみなさない。
- このGateで明示的に変更しない限り、既存のanalysis execution/persistence semanticsを保護する。
- 外部analytical engineの追加はENH-E5のscope外である。

このGateに対応するAcceptance target:
- AC-G00-001: Family identityとして既存AnalysisFamily値EXPLORATORY/CAUSAL/PREDICTIVEを用いる。
- AC-G00-002: Navigation descriptor typeは、execution StageType/StageDefinition/StageExecutionから構造上・semantics上独立している。
- AC-G00-003: 各capabilityが自身のStage ID、label、order、default Stageを正確に所有する。
- AC-G00-004: Generic aggregationはduplicate Family/Stage、空Stage list、不正default Stageをrejectする。
- AC-G00-005: `GET /api/v1/navigation/analysis`が3 Familyすべてについてdeterministicな`analysis-navigation/1` schemaを返す。
- AC-G00-006: DB migrationまたはnavigation-state persistenceを導入しない。
- AC-G00-007: 既存workflow/execution testがgreenを維持する。

## 3. Execution Mode の決定

Mode: `SINGLE_EXECUTION`.

1つのbounded candidateとして実装し、candidate freeze前にGate-wide self-checkを実施する。

## 4. 必須の実装semantics

実装は、保護対象upstream contractの意味を変えずにGate目的を成立させなければならない（MUST）。このGateで明示的に必要としない限り、現在のanalysis spec、execution plan、result schema、algorithmを保持するadditive/refactoring変更を優先する。

## 5. 許可されるscope

- generic navigation descriptor types
- 3 Familyすべてのcapability-owned Stage catalog
- catalog aggregation/validation
- GET /api/v1/navigation/analysis
- unit/API tests

## 6. 明示的な禁止scope

- Execution StageType/StageDefinition/StageExecutionの変更またはalias利用
- frontend navigation shell implementation
- DB migration
- analytical engine changes

全Gate共通の禁止事項:
- testをgreenにすることだけを目的としたassertion弱体化、test削除、skip、xfailは禁止;
- requirement/ACの無断変更は禁止;
- 後続Gateの作業をこのGateへ混入させない;
- 未承認のschema/dependency/engine拡張は禁止。

## 7. 保護対象となる既PASS Gate contract

NONE — first Gate.

coding開始前にCurrent State Control Sheetを読み、保護対象Gateのevidence identityを実装報告へ正確に記録する。

## 8. Transition Debt

計画上は`NONE`。後続へ延期したscopeはTransition Debtではない。

一時的な例外挙動が不可避になった場合は停止し、architecture/Humanの明示的判断を求める。文書化されていないdebtを勝手に作らない。

## 9. Schema / migration / API / runtime ポリシー

- DB schema migration: 明示的なamendmentがない限り`PROHIBITED`。
- AnalysisSpecification/Execution/Result schema変更: このGateで明示しない限り`PROHIBITED`。
- Execution lifecycle: 既存semanticsを保持する。
- API変更: このGateで明示的に必要とするadditive変更だけを許可する。
- legacy analytical route: 保持または明示的にnormalizeし、無断削除しない。

## 10. 自動テスト義務

- AC-G00-001について自動テストevidenceを実装する: Family identityとして既存AnalysisFamily値EXPLORATORY/CAUSAL/PREDICTIVEを用いる。
- AC-G00-002について自動テストevidenceを実装する: Navigation descriptor typeは、execution StageType/StageDefinition/StageExecutionから構造上・semantics上独立している。
- AC-G00-003について自動テストevidenceを実装する: 各capabilityが自身のStage ID、label、order、default Stageを正確に所有する。
- AC-G00-004について自動テストevidenceを実装する: Generic aggregationはduplicate Family/Stage、空Stage list、不正default Stageをrejectする。
- AC-G00-005について自動テストevidenceを実装する: `GET /api/v1/navigation/analysis`が3 Familyすべてについてdeterministicな`analysis-navigation/1` schemaを返す。
- AC-G00-006について自動テストevidenceを実装する: DB migrationまたはnavigation-state persistenceを導入しない。
- AC-G00-007について自動テストevidenceを実装する: 既存workflow/execution testがgreenを維持する。

変更moduleに対するfocused existing testと、diffの影響を受けるすべての保護対象upstream contractを対象としたregression testも実行する。

## 11. Candidate Assembly（候補成果物の組み立て）

`READY_FOR_TEST`へ移行する前に:
1. 必須の実装scopeがすべて完了していること;
2. Packageがある場合、すべてに有効なcheckpoint reportがあること;
3. 未解決blockerが`NONE`であること;
4. focusedおよびGate-wide self-verificationが記録されていること;
5. production/test/migration/dependency diffがレビュー済みであること;
6. implementation completion reportにFixed Trial Candidate SHAが1つ記録されていること。

## 12. Coding Agent の禁止作業

Coding Agentは以下をしてはならない:
- Gate PASSを判定する;
- 07 Acceptance Criteriaを変更する;
- Package完了をpartial PASSとして扱う;
- amendmentなしに既PASS Gateのsemanticsを変更する;
- 対象外の後続featureを実装する。

## 13. 必須成果物

- Trial01（またはcurrent Trial）のimplementation completion report
- 必要に応じたGate-local implementation ledger/detail
- `WORK_PACKAGE`時のPackage checkpoint/status report
- 正確なFixed Trial Candidate SHA
- 実行commandとtest evidence
- 明示的なblocker status

## 14. 外部参照ポリシー

source code pathおよび観測したruntime/test outputはevidenceとして参照してよい。実行に必要な規範的ルールは本contract、およびWork Package modeでは割り当てられたPxx contractに記載する。
