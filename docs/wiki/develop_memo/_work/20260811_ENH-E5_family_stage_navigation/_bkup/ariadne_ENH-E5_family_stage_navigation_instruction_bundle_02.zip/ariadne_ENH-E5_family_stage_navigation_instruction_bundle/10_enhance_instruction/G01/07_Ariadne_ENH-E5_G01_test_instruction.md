# Ariadne ENH-E5 G01 テスト指示書 — Gate Verification Contract（Gate検証契約）

文書区分: Primary Execution Contract（主要実行契約）
自己完結性: MUST（必須）

- プロジェクト: Ariadne
- Enhancement: ENH-E5
- Active Gate: G01
- Gate title: URL-driven Family / Stage Navigation Shell（URL駆動Family/Stage navigation shell）
- 検証契約状態: **DRAFT_FOR_REVIEW**（レビュー前ドラフト）
- Current State Control Sheet（現状態管理表）: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Acceptance の権威情報

freeze後は、この07をAcceptance Criteriaの権威情報とする。Package完了、Coding self-check、`READY_FOR_TEST`はacceptance evidenceではない。

## 2. Gate目的 / acceptance claim

canonical catalogを利用してtop Family tabs + Family-local Stage sidebarを成立させ、URL/deep link/history/legacy route compatibilityを確立する。

PASS後にdownstreamが依存可能になるcontract:
Family-specific G02-G04が同一navigation shell上へStage contentを安全に配置できる。

## 3. 検証時に有効な前提

- test対象は、正確なFixed Trial Candidateである。
- Navigation StageとExecution Stageは別概念である。
- このGateが明示的に変更しない限り、既存analytical algorithm/persistenceはregression保護対象である。
- deferred/out-of-scope featureを偶発的に実装してはならない。
- environment/prerequisiteにより観測不能な場合は`BLOCKED`とし、preflight失敗を自動的にproduct `FAIL`へ変換しない。

## 4. 検証入力

必須:
- current Trialのimplementation completion report
- Fixed Trial Candidate SHA
- repository status/diff
- 該当する場合はPackage checkpoint chain
- Current State Control Sheet
- protected regression確認に必要な既PASS Gate evidence

identityが欠落または曖昧な場合は`BLOCKED_CANDIDATE_IDENTITY`とする。

## 5. Candidate identity audit — 最初に必ず実行

1. 意図したcandidateをcheckout/観測する;
2. `git rev-parse HEAD`を記録する;
3. `git status --short`を記録する;
4. test対象repository stateとFixed Trial Candidate SHAを比較する;
5. 異なる場合はdiffをauditし、documentation-only/non-semanticであることを証明する。証明できなければ状況に応じてBLOCKED/FAILとする。

## 6. Acceptance Criteria（受入基準）

| AC | 基準 | レベル | 必要evidence |
|---|---|---|---|
| AC-G01-001 | 上部tabにbackend catalog由来のExploratory/Predictive/Causalだけを表示し、current Familyを視覚的に識別できる。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G01-002 | 左sidebarにはcurrent Familyが所有するStageだけを表示し、current Stageを識別できる。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G01-003 | canonical URLを`/projects/{id}/analysis/{family}/{stage}`とし、direct loadとbrowser back/forwardでstateを復元できる。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G01-004 | Family切替時は対象Familyが宣言するdefault Stageへnavigateし、last-stage persistenceは使用しない。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G01-005 | legacy `/explore`、`/causal`、`/predictive` routeを文書化されたcanonical targetへnormalizeする。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G01-006 | Management、Context、Data、Results/LineageはFamily tab外のglobal project surfaceとして維持する。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G01-007 | unknown Family/Stageを黙って別contextへ解釈せず、明示的navigation errorと有効な代替先を提示する。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G01-008 | Stage navigation自体はnon-sequentialであり、wizard completionを強制しない。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |

Gate PASSには、すべてのMandatory ACがPASSしなければならない。

## 7. Test Item 計画

- `001_candidate_identity` — candidate/repository-state audit
- 各AC clusterをカバーする1つ以上のfocused item
- protected regression item
- transition-debt audit item
- `999_gate_decision` — 最終Gate Decision専用

各test itemにcommand/input、observed output、evidence path、PASS/FAIL/BLOCKED結果を記録する。

## 8. 保護対象regression

current diffが影響し得る、過去のfinal-PASS Gate contractをすべて検証する。影響があるのに明示的なregression itemがない場合、それ自体をverification defectとする。

## 9. Transition Debt audit

このGateで想定するOPEN debtは`NONE`。文書化されていない一時的authority/exceptionが導入されていないことを確認する。

## 10. Test / Audit Agent の禁止作業

以下を変更してはならない（MUST NOT）:
- production code
- automated test code
- migration/dependency定義
- Package実装
- Acceptance Criteria

## 11. Evidence 要件

Evidenceは再現可能で、正確なcandidate identityに紐付いていなければならない。自動assertionが実用的な箇所では、screenshot/manual observationはautomationの補足には使えるが代替にはできない。

## 12. PASS の意味

PASSとは、Fixed Trial CandidateについてこのGateのsemantic claimが成立し、すべてのmandatory ACとprotected regressionがPASSし、未承認scope/migration/debtが存在せず、evidence identityをaudit可能であることを意味する。

FAILはproduct/contract挙動が有効なACに違反していることを意味する。BLOCKEDはprerequisite/candidate/contractの曖昧さが残り、acceptanceを判定できないことを意味する。
