# 詳細設計 — ENH-E5 revised scope

## 想定コード配置

### Domain / application
- `src/ariadne/product/domain/navigation.py` — generic immutable descriptor typeとvalidation primitive。
- `src/ariadne/product/application/navigation_service.py` — capability descriptorをaggregateする。Family-specific Stage literalは置かない。

### Capability ownership
- `src/ariadne/capabilities/exploratory/navigation.py`
- `src/ariadne/capabilities/predictive/navigation.py`
- `src/ariadne/capabilities/causal/navigation.py`

### Web API
- `src/ariadne/interfaces/web_api/routers/navigation.py`
- `src/ariadne/interfaces/web_api/schemas/navigation.py`
- 既存web API app/router compositionへrouterを登録する。

### Frontend
- `frontend/index.html` — global Family tab、Family-local Stage sidebar/panel。
- `frontend/app.js` — descriptor load、route parser/serializer、history handling、Stage rendering activation、legacy normalization。
- `frontend/styles.css` — top tab + Stage sidebar layoutとactive state。

## Frontend renderer registry

Frontendは以下のようなsparse implementation bindingを持ってよい:

```text
(EXPLORATORY, profile) -> existing explore profile surface
(PREDICTIVE, setup) -> existing predictive form surface
(CAUSAL, identification) -> existing identification surface
```

このbindingはsemantic IDをfrontend implementationへmapするため許可する。ただしlabel/order/default-stage catalogを重複定義してはならない（MUST NOT）。

## Route parser

Canonical route:
`/projects/{project_id}/analysis/{family_slug}/{stage_slug}`

Legacy mappingは明示的かつone-wayとする。unknown new routeにheuristic fallbackを適用しない。

## Test layer

- domain unit tests for descriptor invariants
- application/API tests for catalog response
- navigation state/history/deep linkに対するfrontend/browser test
- family-specific regression tests
- full `uv run pytest -q`
- 利用可能な既存browser e2e suite
