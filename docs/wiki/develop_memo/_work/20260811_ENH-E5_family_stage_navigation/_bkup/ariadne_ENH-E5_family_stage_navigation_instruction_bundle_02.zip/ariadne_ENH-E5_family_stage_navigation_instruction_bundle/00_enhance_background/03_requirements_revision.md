# ENH-E5 要件改定

Document class: 要件 Revision Artifact
状態: `DRAFT_FOR_REVIEW`（レビュー前ドラフト）

## 1. Before / After サマリ

### Before（現状）
- analytical workspaceが単一の左navigation軸に混在している。
- UI navigationでFamilyが独立したglobal contextとして表現されていない。
- causal discovery/inferenceおよびpredictive/exploratory workspaceが、Family-owned Stage中心ではなくpage/workspace中心で構成されている。

### After（変更後）
- analytical navigationをglobal FamilyとFamily-local Navigation Stageの2次元で構成する。
- concrete Stage setはcapabilityが所有する。
- current Family/StageをURLで一意に指定できる。
- 既存analytical behaviorは保持し、Stage surfaceへ再構成する。

## 2. 改定要件

| ID | 要件 | Acceptance上の意味 | 主担当Gate |
|---|---|---|---|
| E5-REQ-001 | Familyをglobal analytical navigation dimensionとして明示する。 | Top navigationにExploratory/Predictive/Causalが表示され、current Familyが識別できる。 | G01 |
| E5-REQ-002 | StageをFamily-local navigation/work contextとして扱う。 | selected Familyに対応するStageだけがleft sidebarに表示される。 | G01 |
| E5-REQ-003 | Navigation StageをExecution Stageから分離する。 | Navigation descriptorがExecution StageType/StageDefinition/StageExecutionを再利用・継承しない。 | G00 |
| E5-REQ-004 | concrete Stage catalogはCapabilityが所有する。 | 各capability moduleが自Familyのstage set/default/orderを定義し、product layerはgeneric aggregation/validationのみ行う。 | G00 |
| E5-REQ-005 | Family/Stage catalogのcanonical sourceを一つにする。 | backend descriptor APIからcatalogを取得し、frontendに別の完全catalogを重複定義しない。 | G00 |
| E5-REQ-006 | Current Family/Stageをdeep-linkableにする。 | URL `/projects/{project_id}/analysis/{family}/{stage}` でdirect load/back/forwardが成立する。 | G01 |
| E5-REQ-007 | navigation stateをE5では永続化しない。 | Family/Stageをworkspace-state/DB schemaへ追加しない。 | G01 |
| E5-REQ-008 | Predictive既存設定を100%保持する。 | 全visible fieldとspec defaultがinventoryでBefore/After対応し、欠落/semantic changeがない。 | G02 |
| E5-REQ-009 | Predictiveを6 Navigation Stageへ再配置する。 | Setup/Train/Predict/Metrics/Explainability/Model Managementが表示される。 | G02 |
| E5-REQ-010 | Causalを7 Navigation Stageへ再配置する。 | Setup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityが表示される。 | G03 |
| E5-REQ-011 | IdentificationとEstimationを明確に分離する。 | UI/route上で別Stageとなり、識別結果と推定実行が混同されない。 | G03 |
| E5-REQ-012 | Exploratoryを6 analytical-view Stageへ再配置する。 | Profile/Data Quality/Distribution/Relationships/Comparison/Findingsが表示される。 | G04 |
| E5-REQ-013 | Visualizationを独立Stageにしない。 | Chart controls/outputはDistribution/Relationships/Comparison等の内部表現として配置される。 | G04 |
| E5-REQ-014 | Results/Lineageをcross-family global surfaceとして保持する。 | Family切替後も既存cross-analysis result/lineage機能へ到達できる。 | G05 |
| E5-REQ-015 | 既存analytical engineとresult persistence semanticsを変更しない。 | 新engine/dependency/schema migrationなしで既存testが通る。 | G05 |
| E5-REQ-016 | Family/Stage navigationはwizard化しない。 | 任意Stageへ移動でき、operation prerequisiteとnavigation progressionを同一視しない。 | G01 |
| E5-REQ-017 | legacy analytical URLsを互換維持する。 | `/explore`, `/causal`, `/predictive`がdocumented targetへredirect/normalizeされる。 | G01 |

## 3. 新しいinvariant（不変条件）

1. `Navigation Stage != Execution Stage`。
2. Family IDは既存`AnalysisFamily` semanticsを再利用する。UI labelはinternal IDと異なってよい。
3. abstract navigation layerはDiscovery/Train/Estimation等のdomain-specific semanticsを持ってはならない。
4. concrete Stage semanticsはcapabilityが所有し、product/application layerはgenericに集約する。
5. Stageの数・名称はFamilyごとに異なってよい。
6. navigation順序を科学的・運用上の完了順序と同一視しない。
7. Predictive既存settingとgenerated spec semanticsを保護対象のcompatibility contractとする。

## 4. 廃止・置換する要件上の前提

- 単一sidebar item listを主要analytical navigation taxonomyとする前提 — 廃止。
- UI Stageはexecution pipeline stageと1対1対応すべきという前提 — 明示的に不採用。
- 全Familyが共通Stage taxonomyを持つべきという前提 — 明示的に不採用。

## 5. 後続Enhancementへ延期する要件

- Overview/Flagship surface
- 専用Findings/Evidence persistence model
- standalone Predict execution service
- model registry/deployment lifecycle
- external analytical engine adapter
