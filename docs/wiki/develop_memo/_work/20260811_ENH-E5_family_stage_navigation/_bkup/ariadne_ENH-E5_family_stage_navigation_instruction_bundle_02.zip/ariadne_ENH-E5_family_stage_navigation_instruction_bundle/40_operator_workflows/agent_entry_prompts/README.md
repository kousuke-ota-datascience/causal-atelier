# Agent entry prompt — ENH-E5

これらのpromptは、対象Gateの06/07がFROZENとなり、すべてのidentity variableが確定した後にのみ使用する。実行時に未解決template variableを残してはならない。
