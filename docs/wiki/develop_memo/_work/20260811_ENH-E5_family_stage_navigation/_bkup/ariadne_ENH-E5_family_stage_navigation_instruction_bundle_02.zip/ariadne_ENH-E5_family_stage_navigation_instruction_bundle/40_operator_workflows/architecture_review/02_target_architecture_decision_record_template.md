# ENH-E5 Target Architecture Decision Record（目標アーキテクチャ決定記録）

文書区分: Architecture Decision Artifact（アーキテクチャ決定資料）
状態: **DRAFT_FOR_HUMAN_APPROVAL**（Human承認待ちドラフト）

## ADR-1 Decision

独立した薄いapplication navigation modelを確立する:

```text
AnalysisFamily
  -> FamilyNavigationDescriptor
       -> NavigationStageDescriptor*
```

concrete descriptor instanceは各analytical capabilityが所有する。generic product/application codeはvalidation/aggregationを担当する。Frontendはread-only descriptor APIを利用し、stage IDをpresentation surfaceへbindingする。

## ADR-2 Invariants

1. Navigation StageはExecution Stageではない。
2. Navigation descriptorはrunner/lifecycle/dependency/input-output-contract semanticsを持たない。
3. concrete Stage semanticsはcapability-ownedとする。
4. 既存`AnalysisFamily`をFamily identityとして再利用する。
5. Backend descriptor APIをcanonical Stage catalog sourceとする。
6. E5ではCurrent Family/StageをURL stateとし、persisted stateにはしない。
7. Global project workspaceはFamily外に維持する。
8. Predictive既存configuration/spec semanticsを保護する。
9. 新規analytical engineまたはpersistent result modelを導入しない。

## ADR-3 API / route

- descriptor: `GET /api/v1/navigation/analysis`
- canonical page route: `/projects/{project_id}/analysis/{family_slug}/{stage_slug}`

## ADR-4 Capability catalog

Exploratory: Profile, Data Quality, Distribution, Relationships, Comparison, Findings.
Predictive: Setup, Train, Predict, Metrics, Explainability, Model Management.
Causal: Setup, Discovery, Identification, Estimation, Effects, Diagnostics, Sensitivity.

## ADR-5 Alternatives considered

### A. Frontend-static full catalog
不採用: capability semanticsを重複定義し、ownership contractを弱めるため。

### B. navigationにExecution StageTypeを再利用する案
不採用: Execution Stageはpipeline/runtime semanticsを持ち、UI contextと1対1対応しないため。

### C. Current Family/Stageをworkspace-stateへ永続化する案
E5では不採用: URLだけでshare可能かつhistory-awareなstateを表現できる。永続化すると、要件化されていないcross-device/session semanticsまで追加されるため。

### D. 4つ目の上部tabとしてOverviewを追加する案
E5では不採用: Overviewはanalytical Familyではなく、navigation dimensionを混在させるため。必要であれば後続Enhancementでglobal workspaceとして再検討する。

## ADR-6 Migration

DB migration: `N/A`。
API change: additive.
Route変更: additive canonical route + legacy normalization。
Execution/result schema migration: `N/A`。

## ADR-7 Approval

Human architecture owner: `PENDING`。
Approved at: `PENDING`
レビュー対象Baseline SHA: `46122c68333df03680b97c253a7b5d32bf9393e7`
