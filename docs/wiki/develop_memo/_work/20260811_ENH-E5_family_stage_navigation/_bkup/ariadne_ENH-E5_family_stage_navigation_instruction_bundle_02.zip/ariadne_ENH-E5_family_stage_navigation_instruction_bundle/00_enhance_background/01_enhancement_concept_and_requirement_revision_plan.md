# ENH-E5 Enhancement 構想・要件改定計画

文書区分: Planning / Background Artifact（計画・背景資料）
状態: `DRAFT_FOR_REVIEW`（レビュー前ドラフト）

## 1. 課題

現行UIではanalytical Familyとworkflow/view contextに相当するnavigation itemが同じleft sidebarへ混在しており、Ariadneの分析能力を「複数のanalytical perspective」として扱うapplication modelがUI/route/capability ownershipに明示されていない。

またbackendにはgeneric Execution Stage abstractionがあるため、UI上のStageをそのままExecution Stageへ流用すると、navigation concernとruntime execution lifecycleが混線するリスクがある。

## 2. 目的

Ariadneのanalytical capabilityを `Family -> Navigation Stage*` として再構成し、Exploratory / Predictive / Causalをfirst-classなanalytical contextとして横断できるnavigation architectureを確立する。

## 3. 目標状態

- 上部横タブに`Exploratory / Predictive / Causal`を常時表示する。
- 左sidebarはcurrent Familyが提供するNavigation Stageだけを表示する。
- capabilityがconcrete Stage catalogを所有する。
- URLでCurrent Family / Stageを表現し、deep link / browser historyを成立させる。
- current predictive configuration/semanticsを完全保持する。
- current causal/exploratory operationsをStageへ再配置し、機能欠落を発生させない。

## 4. 対象範囲（In scope）

### Application / architecture
- Family/Navigation Stage descriptor model
- capability-owned Stage定義
- descriptor参照API
- frontendのFamily/Stage navigation
- URL route / deep link / browser history
- legacy analytical route互換

### FamilyごとのStage構成

Exploratory:
`Profile`, `Data Quality`, `Distribution`, `Relationships`, `Comparison`, `Findings`

Predictive:
`Setup`, `Train`, `Predict`, `Metrics`, `Explainability`, `Model Management`

Causal:
`Setup`, `Discovery`, `Identification`, `Estimation`, `Effects`, `Diagnostics`, `Sensitivity`

### 互換性（Compatibility）
- Predictive既存configuration fieldを100%保持
- 現行execution specのdefault/semanticsを保持
- 現行Results / Lineageのcross-family挙動を保持
- 現行Research Context / Dataset / Analysis View semanticsを保持

## 5. 明示的な対象外（Out of scope）

- LightGBM adapter
- DoWhy adapter
- EconML estimator
- 新規standalone Predict execution engine/scoring service
- model registry/deployment lifecycle CRUD
- CausalのAnalysis Management Stage
- Overview/Flagship top-level workspace
- 新規Findings/Evidence永続domain model
- AnalysisResult/Result schema再設計
- navigation stateのDB永続化
- Family間で共通Stage taxonomyを強制すること
- 厳密なwizard/sequential navigation

## 6. 要件・設計への想定影響

影響大:
- information architecture
- frontend route/state model
- capability ownership contract
- API descriptor contract

影響中:
- Family固有UI composition
- test/e2e matrix

変更なしを想定:
- analytical algorithm
- execution lifecycle semantics
- 永続analysis/result schema
- migration schema

## 7. 初期Gate分解

| Gate | PASS時に成立すべきsemantic claim |
|---|---|
| G00 | Family/Navigation Stage contractとcapability-owned catalogがExecution Stageから独立して依存可能になる。 |
| G01 | global workspaceとlegacy linkを保持したまま、Family/Stage URLとcatalogでproduct navigationを駆動できる。 |
| G02 | 既存configuration/executionとの完全互換を保ち、Predictive capabilityを6つのNavigation Stageから利用できる。 |
| G03 | IdentificationとEstimationを明示的に分離し、Causal capabilityを7つのNavigation Stageから利用できる。 |
| G04 | 独立したVisualization Stageを設けず、Exploratory capabilityを6つのanalytical-view Stageから利用できる。 |
| G05 | 完成したnavigation modelについて、cross-familyのcontext/result継続性と全面的なregression保護が成立する。 |

## 8. 主なリスク

1. **Semantic collision:** Navigation Stageが誤ってExecution `StageType`を再利用する。
2. **Predictive regression:** visible fieldは残るが、hidden spec defaultが変わる。
3. **State regression:** Stage切替で編集中form値/contextが失われる。
4. **Routing regression:** browser back/forwardまたはdirect URLにより想定workspace stateを迂回する。
5. **Scope creep:** 新規analytical engineやresult-domain再設計がnavigation改修へ混入する。

## 9. Coding開始前に必要な決定

- scopeおよびtarget architectureのHuman approval。
- branch baseline SHAの完全確定。
- G00 06/07のfreeze。
