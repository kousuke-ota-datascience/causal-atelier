# Ariadne ENH-E5 G00 テスト指示書 — Gate Verification Contract（Gate検証契約）

文書区分: Primary Execution Contract（主要実行契約）
自己完結性: MUST（必須）

- プロジェクト: Ariadne
- Enhancement: ENH-E5
- Active Gate: G00
- Gate title: Family / Navigation Stage Domain Contract（Family / Navigation Stageドメイン契約）
- 検証契約状態: **DRAFT_FOR_REVIEW**（レビュー前ドラフト）
- Current State Control Sheet（現状態管理表）: `../../ENH-E5_Current_State_Control_Sheet.md`

## 1. Acceptance の権威情報

freeze後は、この07をAcceptance Criteriaの権威情報とする。Package完了、Coding self-check、`READY_FOR_TEST`はacceptance evidenceではない。

## 2. Gate目的 / acceptance claim

FamilyとNavigation Stageのapplication contractをExecution Stageから独立して成立させ、capability-owned canonical stage catalogとread APIを提供する。

PASS後にdownstreamが依存可能になるcontract:
G01以降が、stable Family ID / stage ID / order / default Stage / catalog APIへ依存できる。

## 3. 検証時に有効な前提

- test対象は、正確なFixed Trial Candidateである。
- Navigation StageとExecution Stageは別概念である。
- このGateが明示的に変更しない限り、既存analytical algorithm/persistenceはregression保護対象である。
- deferred/out-of-scope featureを偶発的に実装してはならない。
- environment/prerequisiteにより観測不能な場合は`BLOCKED`とし、preflight失敗を自動的にproduct `FAIL`へ変換しない。

## 4. 検証入力

必須:
- current Trialのimplementation completion report
- Fixed Trial Candidate SHA
- repository status/diff
- 該当する場合はPackage checkpoint chain
- Current State Control Sheet
- protected regression確認に必要な既PASS Gate evidence

identityが欠落または曖昧な場合は`BLOCKED_CANDIDATE_IDENTITY`とする。

## 5. Candidate identity audit — 最初に必ず実行

1. 意図したcandidateをcheckout/観測する;
2. `git rev-parse HEAD`を記録する;
3. `git status --short`を記録する;
4. test対象repository stateとFixed Trial Candidate SHAを比較する;
5. 異なる場合はdiffをauditし、documentation-only/non-semanticであることを証明する。証明できなければ状況に応じてBLOCKED/FAILとする。

## 6. Acceptance Criteria（受入基準）

| AC | 基準 | レベル | 必要evidence |
|---|---|---|---|
| AC-G00-001 | Family identityとして既存AnalysisFamily値EXPLORATORY/CAUSAL/PREDICTIVEを用いる。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G00-002 | Navigation descriptor typeは、execution StageType/StageDefinition/StageExecutionから構造上・semantics上独立している。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G00-003 | 各capabilityが自身のStage ID、label、order、default Stageを正確に所有する。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G00-004 | Generic aggregationはduplicate Family/Stage、空Stage list、不正default Stageをrejectする。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G00-005 | `GET /api/v1/navigation/analysis`が3 Familyすべてについてdeterministicな`analysis-navigation/1` schemaを返す。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G00-006 | DB migrationまたはnavigation-state persistenceを導入しない。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |
| AC-G00-007 | 既存workflow/execution testがgreenを維持する。 | 必須（Mandatory） | Fixed Trial Candidateのbehavior/code/test evidence |

Gate PASSには、すべてのMandatory ACがPASSしなければならない。

## 7. Test Item 計画

- `001_candidate_identity` — candidate/repository-state audit
- 各AC clusterをカバーする1つ以上のfocused item
- protected regression item
- transition-debt audit item
- `999_gate_decision` — 最終Gate Decision専用

各test itemにcommand/input、observed output、evidence path、PASS/FAIL/BLOCKED結果を記録する。

## 8. 保護対象regression

current diffが影響し得る、過去のfinal-PASS Gate contractをすべて検証する。影響があるのに明示的なregression itemがない場合、それ自体をverification defectとする。

## 9. Transition Debt audit

このGateで想定するOPEN debtは`NONE`。文書化されていない一時的authority/exceptionが導入されていないことを確認する。

## 10. Test / Audit Agent の禁止作業

以下を変更してはならない（MUST NOT）:
- production code
- automated test code
- migration/dependency定義
- Package実装
- Acceptance Criteria

## 11. Evidence 要件

Evidenceは再現可能で、正確なcandidate identityに紐付いていなければならない。自動assertionが実用的な箇所では、screenshot/manual observationはautomationの補足には使えるが代替にはできない。

## 12. PASS の意味

PASSとは、Fixed Trial CandidateについてこのGateのsemantic claimが成立し、すべてのmandatory ACとprotected regressionがPASSし、未承認scope/migration/debtが存在せず、evidence identityをaudit可能であることを意味する。

FAILはproduct/contract挙動が有効なACに違反していることを意味する。BLOCKEDはprerequisite/candidate/contractの曖昧さが残り、acceptanceを判定できないことを意味する。
