# FAIL後Rework Coding Agent Prompt — ENH-E5

formal Gate FAIL後にのみ使用する。

1. 元のfreeze済み06/07とfailed candidate evidenceを保持する。
2. Gate contractが依然有効か判定する。
3. 有効なら、approved 08 Remediation Contractと、存在する場合はRxxを使用する。
4. Gate claim/AC自体が誤りなら、Human-approved 09 Amendmentのため停止する。criteriaを無断変更して修復してはならない。
5. 新しいTrial candidate identityを作成し、failed evidenceを上書きしない。
