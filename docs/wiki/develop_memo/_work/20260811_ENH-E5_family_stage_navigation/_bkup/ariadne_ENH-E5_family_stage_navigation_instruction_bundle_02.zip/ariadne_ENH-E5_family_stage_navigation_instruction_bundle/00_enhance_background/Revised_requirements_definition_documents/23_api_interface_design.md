# APIインターフェース設計 — ENH-E5 revised scope

## GET /api/v1/navigation/analysis

Purpose: frontendへcanonical analytical Family/Navigation Stage catalogを提供するread-only endpoint。

### Response 200

```json
{
  "schema_version": "analysis-navigation/1",
  "families": [
    {
      "id": "EXPLORATORY",
      "slug": "exploratory",
      "label": "Exploratory",
      "default_stage_id": "profile",
      "stages": [
        {"id": "profile", "label": "Profile", "order": 10}
      ]
    }
  ]
}
```

### Contract

- order is deterministic.
- support対象の3つのAnalysisFamily値をすべて返す。
- E5ではresponseをread-onlyかつproject-independentとする。
- endpointからExecution `StageType`、dependency DAG、input/output contract、runtime status、runner IDを公開しない。
- no write endpoint is introduced.

### 互換性（Compatibility）

Additive endpoint. Existing APIs remain unchanged.
