# Ariadne ENH-E5 — Family × Stage Navigation 改修

文書区分: Authoring / Orchestration Guide（作成・運用ガイド）
Template互換性: `agentic_enhancement_workflow_template` schema v11
Branch: `feature/ariadne_mvp_e5`
Bundle状態: **DRAFT_FOR_REVIEW**（レビュー前ドラフト）
Prepared at: `2026-08-11T11:12:00+09:00`

## 文書言語ポリシー

本bundleは**日本語話者が単独で読み、設計意図・実装指示・受入条件を理解できること**を文書品質要件とする。説明文、判断理由、手順、Acceptance Criteriaは原則として日本語で記述する。

一方、`Gate`、`Work Package`、`Acceptance Criteria`、`Transition Debt`、`Family`、`Stage`、API/route/schema/type/class/function名、状態値（`PASS` / `FAIL` / `BLOCKED`等）は、template・code・evidenceとの対応を明確にするため英語表記を許容する。英語の専門概念を残す場合も、周辺文脈は日本語で意味が理解できるようにする。

## 0. 結論

本bundleは、Ariadneのanalytical capabilitiesを **Family × Family-owned Navigation Stage** で再構成する ENH-E5 の初版指示書一式である。

今回の中心契約は次のとおり。

1. `Family = global analytical context`、`Navigation Stage = Family-local work/view context` とする。
2. UIは **上部横タブ=Family、左サイド=selected FamilyのStage** とする。
3. `Navigation Stage != Execution Stage` をarchitecture invariantとする。
4. concrete Navigation Stage catalogは各Capabilityが所有する。
5. Current Family / Stageのcanonical stateはURLとし、E5ではDB/workspace-stateへ永続化しない。
6. Predictive既存設定・実行semanticsは100%保持する。
7. LightGBM / DoWhy / EconML等の新規analytical engineはscope外とする。
8. Overview/Flagship、専用Findings/Evidence domain、AnalysisResult再設計はE5では導入しない。

## 1. Workflow status

このbundleはschema v11のdocument authority modelに従う。

- 00: 背景 / 要件 / 設計改定
- 10: Gate Coding Contract（Gate実装契約） / Gate Verification Contract（Gate検証契約） / Work Package
- 20: Implementation evidence — **execution開始前なので未生成**
- 30: Independent verification evidence — **verification開始前なので未生成**
- 40: Architecture review / operator prompt / preflight
- Current State Control Sheet（現状態管理表）: verified current stateのみを保持

**重要:** 未実行のimplementation/test evidenceを捏造しないため、20/30にはREADMEのみを配置している。Trial開始時にtemplate規約どおり生成すること。

## 2. Freeze preconditions

Planning baselineはremote branch HEAD `46122c68333df03680b97c253a7b5d32bf9393e7` にpinした。

06/07を`FROZEN`へ昇格する前に、local repositoryでpreflightを実行し、local checkoutがこのpinと一致すること、およびtest baselineが成立することを確認する。

```bash
git branch --show-current
git rev-parse HEAD
git status --short
```

期待branch: `feature/ariadne_mvp_e5`
期待SHA: `46122c68333df03680b97c253a7b5d32bf9393e7`

Human approvalとpreflight成立前にCoding Agentを起動してはならない。

## 3. Gate map

| Gate | Semantic acceptance boundary（意味上の受入境界） | Execution Mode |
|---|---|---|
| G00 | Family / Navigation Stage domain contractとcapability-owned catalogが成立 | SINGLE_EXECUTION |
| G01 | URL-driven Family/Stage navigation shellとlegacy navigation compatibilityが成立 | WORK_PACKAGE |
| G02 | Predictiveを6 Stageへ再配置し、既存設定・実行semanticsの完全互換が成立 | WORK_PACKAGE |
| G03 | Causalを7 Stageへ再配置し、Identification/Estimation分離と既存操作互換が成立 | WORK_PACKAGE |
| G04 | Exploratoryを6 Stageへ再配置し、探索観点ベースnavigationと既存操作互換が成立 | WORK_PACKAGE |
| G05 | 3 Family横断のcontext/result continuityとproduct-wide regression contractが成立 | SINGLE_EXECUTION |

## 4. Source hierarchy

Planning時のsource hierarchyは以下とする。

1. 本bundleのapproved 00層 / 06 / 07（approval後）
2. `feature/ariadne_mvp_e5` のcurrent code
3. ENH-E5引き継ぎメモ
4. template schema v11

Factとtarget decisionが衝突する場合、実装Agentは勝手に解釈して進めず`BLOCKED_CONTRACT_AMBIGUITY`とする。

## 5. Directory entry points

- Background: `00_enhance_background/`
- Gate contract: `10_enhance_instruction/`
- Architecture review: `40_operator_workflows/architecture_review/`
- Preflight指示: `40_operator_workflows/preflight/ENH-E5_preflight_instruction.md`
- Current state管理: `ENH-E5_Current_State_Control_Sheet.md`
- Manifest: `MANIFEST.json`
