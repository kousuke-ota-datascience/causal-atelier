# 改定要件定義文書 — ENH-E5 scope snapshot

このdirectoryはENH-E5で改定対象となるrequirement/design sectionsをself-containedに再構成したscope snapshotである。

これは既存project-wide原典の全文複製ではない。E5実装・reviewに必要な変更契約を明示し、原典へmergeする際のapproved targetを提供する。
