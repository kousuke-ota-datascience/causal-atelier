# ENH-E5 設計改定

Document class: 設計改定 Artifact
状態: `DRAFT_FOR_REVIEW`（レビュー前ドラフト）

## 1. Architecture decision

### DR-01 — Family identityとして`AnalysisFamily`を再利用する

**決定:** existing product-domain `AnalysisFamily` values `EXPLORATORY`, `CAUSAL`, `PREDICTIVE` are the internal Family IDs.

**理由:** current code already binds planners/specifications/results to these analytical families. Creating a second Family identity would introduce unnecessary translation.

**不採用案:** frontend-only string catalog disconnected from product domain.

### DR-02 — 独立したNavigation descriptor modelを導入する

想定するgeneric type:

```text
NavigationStageDescriptor
- stage_id
- label
- order

FamilyNavigationDescriptor
- family: AnalysisFamily
- label
- default_stage_id
- stages: tuple[NavigationStageDescriptor, ...]
```

このmodelにexecution dependency、input/output contract、runner ID、execution status、attempt lifecycleを含めてはならない（MUST NOT）。

### DR-03 — concrete catalogはCapabilityが所有する

想定ownership:

```text
src/ariadne/capabilities/exploratory/navigation.py
src/ariadne/capabilities/predictive/navigation.py
src/ariadne/capabilities/causal/navigation.py
```

各capabilityはimmutableな`FamilyNavigationDescriptor`を1つexportする。product/application codeはvalidationとaggregationのみを担当する。

### DR-04 — Backend descriptor APIをcanonical catalog sourceとする

想定endpoint:

```http
GET /api/v1/navigation/analysis
```

Response schema version: `analysis-navigation/1`。

Frontendはsemantic IDとDOM/rendering codeを結び付けるため、`(family_id, stage_id)`をkeyとするrenderer registryを保持してよい。ただし、stage order/label/defaultの完全catalogを別途二重管理してはならない（MUST NOT）。

### DR-05 — URLをCurrent Family/Stageのcanonical stateとする

Target canonical route:

```text
/projects/{project_id}/analysis/{family_slug}/{stage_slug}
```

Canonical family slugs:
- `exploratory`
- `predictive`
- `causal`

E5ではlast Family/StageをDBまたは`/workspace-state`へ永続化しない。

### DR-06 — Global project surfaceはFamilyの外側に置く

以下はglobal project-level surfaceとして維持する:
- Project Management
- Research Context
- Project / Data
- Results / Lineage

上部Family tabにはanalytical Familyのみを置く。E5では`Overview`を導入しない。

### DR-07 — Legacy analytical routeを新routeへnormalizeする

- `/projects/{id}/explore` -> `/projects/{id}/analysis/exploratory/profile`
- `/projects/{id}/causal` -> `/projects/{id}/analysis/causal/discovery`
- `/projects/{id}/predictive` -> `/projects/{id}/analysis/predictive/setup`

`context`、`data`、`results`はglobal routeとして維持する。

### DR-08 — persistence/schema migrationは行わない

Navigation catalogはcode-definedかつread-onlyとする。Current Family/StageはURL stateとする。既存AnalysisSpecification/Execution/Result/Artifactのpersistenceは変更しない。

実装中にschema migrationが真に必要と判明した場合は`BLOCKED_CONTRACT_AMBIGUITY`として停止する。architecture amendmentなしにmigrationを追加してはならない。

## 2. FamilyごとのStage mapping

### Exploratory

| Stage | 現行capabilityとの対応 | E5でのsemantic rule |
|---|---|---|
| Profile | dataset/profile/explore profile | dataset overview。必要な場合はAnalysis View contextの作成・選択を内包してよい |
| Data Quality | 既存profile/quality observation | 既にsupportされるfactのみ表示し、新規quality engineは追加しない |
| Distribution | DISTRIBUTION + 関連chart control | visualizationは表現手段として扱う |
| Relationships | ASSOCIATION + 関連chart | causal interpretationを行わない |
| Comparison | GROUP_SUMMARY / TIME_TREND + 関連chart | group/segment/cohort比較 |
| Findings | 保存済みexploratory Resultと既存annotation/linkage | 新規Findings entityは作らない |

### Predictive

| Stage | 現行capabilityとの対応 | E5でのsemantic rule |
|---|---|---|
| Setup | 現行Predictiveの全form field/specification | **既存fieldをすべて保持する** |
| Train | split validation + 現行full workflow launch/status | execution pipelineは既存split/prepare/train/evaluate/(explain)を維持 |
| Predict | 存在する場合、prediction-bearing output/artifact参照 | standalone scoring executionは追加しない |
| Metrics | Evaluation + Error Analysis result surface | metric engineは変更しない |
| Explainability | 既存Explanation result surface | predictive explanationはnon-causalとして維持 |
| Model Management | fitted model/model card/artifact/lineageのread-only surface | registry CRUD/deployment lifecycleは追加しない |

### Causal

| Stage | 現行capabilityとの対応 | E5でのsemantic rule |
|---|---|---|
| Setup | dataset/view/population/comparator/treatment/outcome/unit/time/window/estimand/assumptions | design context |
| Discovery | 現行causal discovery/graph candidate/direct graph registration | optional/non-sequential |
| Identification | fixed graph/strategy/adjustment/identification/data eligibility | Estimationと分離する |
| Estimation | estimator選択 + 許可されたestimation execution/revision | 現行estimatorのみ |
| Effects | treatment-effect result / comparison | resultの閲覧・利用 |
| Diagnostics | eligibility + estimation diagnostics | 妥当性確認 |
| Sensitivity | refutation + sensitivity | 現行methodのみ |

## 3. Predictive compatibility inventory — 保護対象

現行visible controlのうち、引き続き表現可能でなければならない項目（MUST）:

- Active Research Context
- Dataset Version
- Analysis View
- Task Type
- Prediction unit
- Target column
- Prediction time
- Horizon
- Intended use
- Deployment population
- Feature columns
- Excluded columns
- Split strategy
- Seed
- Train ratio
- Validation ratio
- Test ratio
- Explanation method
- Explanation sample size
- Local explanations flag

generated `predictive-analysis-spec/1` semanticsのうち、無断変更してはならない項目（MUST NOT）:

- feature availability cutoff = `PREDICTION_TIME`
- split strategy semanticsおよびratio/seed
- preprocessing: TRAIN fit、MEAN numeric imputation、numeric scaling、ONE_HOT categorical encoding
- model ID: logistic_regression.v1 / linear_regression.v1（現行parameterを保持）
- tuning partition: TRAIN + VALIDATION
- primary metric: current task typeに応じてROC_AUCまたはRMSE
- explanation dataset = TEST、sampling = FIRST_N、既存explanation method/local flag

## 4. UI state handling

Family/Stage navigationは、current analytical workspaceの未保存field値を破棄せずにvisibility/routingだけを変更しなければならない（MUST）。推奨実装はStage DOM/formをmountしたままpresentationを切り替える方式。refactoringでpanelをrender/unmountする場合は、明示的なfrontend draft stateですべての保護対象fieldを保持する。

## 5. Result model decision

現行generic Result envelopeを保持する。E5では新しい`AnalysisResult` hierarchyを導入せず、predictive metrics / causal effects / exploratory findingsを単一scalar schemaへ平坦化しない。

## 6. Migration / compatibility

- DB migration: target designでは`N/A`。
- API migration: additiveなread endpointのみ。
- route互換: legacy analytical routeをnormalize/redirectする。
- result/analysis spec schema: 変更なし。
- execution stage contract: 変更なし。
