# プロダクト基本設計 — ENH-E5 revised scope

## 画面構成

```text
Global project header / context
[Exploratory] [Predictive] [Causal]     <- Family tabs
-------------------------------------------------------
Family-local Stage sidebar | Stage main content
                            |
Global project surfaces (Management / Context / Data / Results-Lineage) remain outside Family.
```

## Family切替時の挙動

- Family tab clickで、そのFamilyが宣言するdefault Stageへnavigateする。
- Stage clickはlocal analytical navigation contextだけを変更する。
- Browser back/forwardでURLからFamilyとStageを復元する。
- No last-stage memory in E5.

## 不正route時の挙動

Unknown Family/Stageを別semantic contextへ黙って解釈してはならない。有効なFamily defaultへのlinkを含むnavigation errorを表示するか、明示的legacy mappingが存在する場合のみnormalizeする。
