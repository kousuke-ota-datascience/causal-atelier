# Work Package Coding Agent Prompt — ENH-E5

入力variable: `GATE_ID`, `TRIAL_NO`, `PACKAGE_ID`。

1. 対象Gateが`WORK_PACKAGE`で、freeze済みP00が存在することを確認する。
2. freeze済み`06_<GATE_ID>_<PACKAGE_ID>_*.md`を正確に1つ選択する。
3. Package dependency/checkpoint identityを確認する。
4. Package scopeとfocused verificationのみを実行する。
5. Package checkpoint/status reportを作成・更新し、checkpoint SHAを記録する。
6. 全Package完了後のcandidate assembly stepを明示的に担当する場合を除き、Fixed Trial Candidateをassembleしない。
7. Package completeはGate PASSを意味しない。
