# ENH-E5 G01 P02 — Navigation Shell UI

文書区分: Primary Execution Contract（主要実行契約）
自己完結性: MUST（必須）

- Gate: G01
- Trial: `01`
- Package: P02
- Parent 06（Operator provenance only / Package Agent参照不要）: `06_Ariadne_ENH-E5_G01_implementation_instruction.md`
- P00 Plan（Operator provenance only / Package Agent参照不要）: `06_G01_P00_work_package_plan.md`
- 依存Package: `P01`
- 発行時状態: **DRAFT_FOR_REVIEW**（レビュー前ドラフト）


## 0. Package Coding Agentの参照ポリシー — assigned Pxxのみ

本Pxxは、当該Package Coding Agentに対する**唯一のnormative implementation contract**である。

Package Agentは仕様を補う目的で06、07、P00、00〜30、ADR、他Pxx、過去Enhancement、issue、外部Webを参照してはならない（MUST NOT）。

current repositoryはimplementation substrateとして参照してよいが仕様authorityではない。

本Pxxだけではrequired behavior / scope / dependency / protected invariantを一意に決められない場合、探索を広げず`BLOCKED_CONTRACT_AMBIGUITY`で停止する。

本PxxをfreezeするPlanning担当は、担当packageに必要なGate-level constraints、entry condition、protected semantics、focused verificationを本文へ具体的に転記してからAgentへ渡す。

### Package共通のGate invariant
- Family = global analytical context。
- Navigation Stage = Family-local UI/navigation context。
- URLをCurrent Family/Stageのcanonical stateとする。
- Navigation StageをExecution Stageへmapping/依存させない。
- existing analytical execution/persistence semanticsを変更しない。
- unknown routeをheuristic fallbackしない。


## 1. 目的

上部Family tab + Family-local Stage sidebar + catalog駆動active/error state。

## 2. このGateで有効な制約

- Gate claim: canonical catalogを利用してtop Family tabs + Family-local Stage sidebarを成立させ、URL/deep link/history/legacy route compatibilityを確立する。
- Downstream result: Family-specific G02-G04が同一navigation shell上へStage contentを安全に配置できる。
- `Navigation Stage != Execution Stage` を維持する。
- schema migration、新規engine、未承認scopeを持ち込まない。
- GateのACおよび既PASS Gateのsemanticsを変更しない。

## 3. 対象範囲（In scope）

上記Package固有の目的を満たすために必要な最小限のcode/test変更に限定する。参考として、このGate全体で許可されるscopeは以下。
- descriptor-driven Family tab / Stage sidebar
- canonical analysis route
- browser history / deep link
- legacy route normalization
- global workspaceとの責務分離
- navigation error handling

## 4. 対象外（Out of scope）

- このPackageで明示的に必要な最小限のcompile/interface stubを除き、後続Packageへ割り当てられた作業;
- 親Gateで禁止scopeとして列挙された項目;
- Gate判定およびcandidate acceptance。

## 5. 開始条件 / evidence

- prerequisite Package `P01` が完了済みであること;
- branch/baseline identityが確認済みであること;
- 現在のPackage instructionが当該Trial向けにFROZENであること;
- 保護対象となるupstream contract一覧が記録済みであること。

## 6. 実装要件

1. semantic scopeを広げずに、このPackageの目的を成立させる。
2. このPackageがpresentationの再配置を明示している場合を除き、既存のanalysis/spec/result/execution挙動を保持する。
3. 変更した挙動に対するfocused automated testを追加・更新する。
4. 外部から観測可能なID/route/API schemaをdeterministicに保つ。

## 7. 局所検証（Focused verification）

変更箇所に対して必要最小限のunit/API/frontend testとstatic/syntax checkを実行し、実行commandと結果を正確に記録する。

## 8. 保護対象contract / Transition Debt

実行前にCurrent State Control Sheetを確認する。計画上の新規Transition Debtは`NONE`。

## 9. Checkpoint と報告

Package完了時:
- `git rev-parse HEAD` をPackage Checkpoint SHAとして記録する;
- `git status --short` を記録する;
- 20層にPackage checkpoint/status reportを作成する;
- focused verificationの結果を報告する;
- 未解決blockerを報告する。

## 10. 完了条件

Package目的が実装され、focused verificationがgreenで、監査可能なcheckpointが1つ記録されていること。これは**Gate PASSを意味しない**。

## 11. 外部参照ポリシー

source code/test outputはevidenceとして参照してよい。Package実行に必要な規範的ルールは本書に記載する。

## 12. 停止条件

contractの曖昧さ、未承認migration/dependency要求、baseline identity不一致、または保護対象contractとの衝突を発見した場合は`BLOCKED_*`として停止する。
