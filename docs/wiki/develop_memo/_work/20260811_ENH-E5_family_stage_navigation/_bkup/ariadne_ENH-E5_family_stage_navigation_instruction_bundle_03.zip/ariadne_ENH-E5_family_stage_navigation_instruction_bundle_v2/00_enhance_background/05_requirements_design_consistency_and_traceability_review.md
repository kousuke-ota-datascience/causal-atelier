# ENH-E5 要件s / Design Consistency and Traceability Review

Document class: Traceability Review Artifact
状態: `DRAFT_FOR_REVIEW`（レビュー前ドラフト）

## 1. Review conclusion

現時点のtarget designはhandoffのfixed decisionsとcurrent code structureに整合する。最大の整合性条件は、Navigation StageをExecution Stageから完全に分離しつつ、Family identityは既存`AnalysisFamily`を再利用することである。

## 2. Traceability matrix

| 要件 | Design trace | Gate | Acceptance上の意味 |
|---|---|---|---|
| E5-REQ-001 | DR-01, DR-06 | G01 | Top navigationにExploratory/Predictive/Causalが表示され、current Familyが識別できる。 |
| E5-REQ-002 | DR-02, DR-03 | G01 | selected Familyに対応するStageだけがleft sidebarに表示される。 |
| E5-REQ-003 | DR-02 | G00 | Navigation descriptorがExecution StageType/StageDefinition/StageExecutionを再利用・継承しない。 |
| E5-REQ-004 | DR-03 | G00 | 各capability moduleが自Familyのstage set/default/orderを定義し、product layerはgeneric aggregation/validationのみ行う。 |
| E5-REQ-005 | DR-04 | G00 | backend descriptor APIからcatalogを取得し、frontendに別の完全catalogを重複定義しない。 |
| E5-REQ-006 | DR-05 | G01 | URL `/projects/{project_id}/analysis/{family}/{stage}` でdirect load/back/forwardが成立する。 |
| E5-REQ-007 | DR-05, DR-08 | G01 | Family/Stageをworkspace-state/DB schemaへ追加しない。 |
| E5-REQ-008 | 設計改定 §3 | G02 | 全visible fieldとspec defaultがinventoryでBefore/After対応し、欠落/semantic changeがない。 |
| E5-REQ-009 | 設計改定 §2 Predictive | G02 | Setup/Train/Predict/Metrics/Explainability/Model Managementが表示される。 |
| E5-REQ-010 | 設計改定 §2 Causal | G03 | Setup/Discovery/Identification/Estimation/Effects/Diagnostics/Sensitivityが表示される。 |
| E5-REQ-011 | 設計改定 §2 Causal | G03 | UI/route上で別Stageとなり、識別結果と推定実行が混同されない。 |
| E5-REQ-012 | 設計改定 §2 Exploratory | G04 | Profile/Data Quality/Distribution/Relationships/Comparison/Findingsが表示される。 |
| E5-REQ-013 | 設計改定 §2 Exploratory | G04 | Chart controls/outputはDistribution/Relationships/Comparison等の内部表現として配置される。 |
| E5-REQ-014 | DR-06, 設計改定 §5 | G05 | Family切替後も既存cross-analysis result/lineage機能へ到達できる。 |
| E5-REQ-015 | DR-08, 設計改定 §5-6 | G05 | 新engine/dependency/schema migrationなしで既存testが通る。 |
| E5-REQ-016 | DR-02, 設計改定 §2 | G01 | 任意Stageへ移動でき、operation prerequisiteとnavigation progressionを同一視しない。 |
| E5-REQ-017 | DR-07 | G01 | `/explore`, `/causal`, `/predictive`がdocumented targetへredirect/normalizeされる。 |

## 3. Consistency checks

### C-01 Predictive 100% preservation
PASS condition: visible form inventoryとgenerated family_spec semanticsの双方がG02 test matrixに存在すること。

### C-02 Navigation vs Execution separation
PASS条件: 新navigation domain typeがexecution lifecycle semanticsを持たず、execution plan testが変更されていないこと。

### C-03 Capability ownership
PASS条件: concrete Stage ID/label/default/orderがcapability moduleで定義され、aggregation layerにFamily-specific Stage listが存在しないこと。

### C-04 Persistence
PASS条件: DB migrationがなく、workspace-stateにfamily/stage fieldを追加していないこと。

### C-05 Deferred scope isolation
PASS条件: external engine、Overview、専用Findings/Evidence model、standalone scoring、model lifecycle write operationがE5 diffに含まれないこと。

## 4. Open approval item

Human approval: `PENDING_HUMAN_APPROVAL`.
Planning baseline SHA: `46122c68333df03680b97c253a7b5d32bf9393e7`. Local checkout一致確認とtest baseline取得はpreflightで実施する。

Human approvalとlocal preflightが成立するまでGate contractはfreezeしない。

## 追加traceability — Navigation / Execution separation

| Requirement | Design decision | Gate / verification |
|---|---|---|
| Navigation Stage != Execution Stage | DR-02 / DR-09 | G00 AC: type independence / no 1:1 requirement |
| CLI/libraryはNavigation Stageなしで実行可能 | DR-09 | G00 regression AC |
| runtime layerはNavigation Stageへ逆依存しない | DR-09 | G00 code/dependency audit |
| Agentは上流資料から仕様を補完しない | DR-10 | 全Gate 06/07/Pxx execution isolation section |
