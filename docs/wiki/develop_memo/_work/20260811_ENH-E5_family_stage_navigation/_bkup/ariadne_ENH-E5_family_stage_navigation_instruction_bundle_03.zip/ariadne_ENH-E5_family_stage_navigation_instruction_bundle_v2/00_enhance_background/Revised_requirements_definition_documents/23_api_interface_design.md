# 23 API・インターフェース設計 — ENH-E5 revised target snapshot

- 文書状態: `DRAFT_FOR_REVIEW`
- API base: `/api/v1`
- ENH-E5のAPI変更方針: additive read interfaceを基本とし、existing execution/result APIを変更しない。

## 1. 設計目的

Family/Navigation Stage catalogをFrontendへ提供し、Frontend static duplicate catalogを避ける。

同時に、navigation APIへExecution Stageのruntime semanticsを漏らさない。

## 2. API原則

1. Family / Navigation Stageのsemantic catalog sourceを1つにする。
2. Responseはschema versionを持つ。
3. ordering / defaultはdeterministic。
4. read-only catalogとする。
5. Navigation descriptorへrunner/dependency/status/attempt等を含めない。
6. existing execution/result command APIを変更しない。
7. navigation state persistence write APIを追加しない。
8. Frontend renderer bindingはAPI catalogとは別concernとする。

## 3. Navigation catalog endpoint

### 3.1 Request

```http
GET /api/v1/navigation/analysis
```

Target designではproject-independentなcode-defined catalogであるため、`project_id`を必須にしない。

将来project権限やfeature availabilityでcatalog自体を変える要件が生じた場合はschema/API revisionとして扱う。

### 3.2 Response 200 example

```json
{
  "schema_version": "analysis-navigation/1",
  "families": [
    {
      "id": "EXPLORATORY",
      "slug": "exploratory",
      "label": "Exploratory",
      "default_stage_id": "profile",
      "stages": [
        {"id": "profile", "slug": "profile", "label": "Profile", "order": 10},
        {"id": "data-quality", "slug": "data-quality", "label": "Data Quality", "order": 20}
      ]
    }
  ]
}
```

実装で`id`と`slug`を同一fieldへ簡略化する場合、route/identifier contractとして一意であることを保証する。

## 4. Response contract

### 4.1 schema_version
`analysis-navigation/1`。

### 4.2 families
support対象`AnalysisFamily`をすべて返す。

Target:
- `EXPLORATORY`
- `PREDICTIVE`
- `CAUSAL`

### 4.3 ordering
Family orderおよびStage orderはdeterministicに返す。

### 4.4 default_stage_id
Family内でvalidなStage IDを1つ指定する。

### 4.5 no runtime fields
次のようなfieldをresponseへ入れない。

- execution_stage_type
- runner_id
- dependency
- input_contract
- output_contract
- execution_status
- attempt_id
- retry_policy

Navigation catalogはruntime plan endpointではない。

## 5. Family catalog target

### Exploratory
Default: `profile`

- profile
- data-quality
- distribution
- relationships
- comparison
- findings

### Predictive
Default: `setup`

- setup
- train
- predict
- metrics
- explainability
- model-management

### Causal
Proposed default: `discovery`

- setup
- discovery
- identification
- estimation
- effects
- diagnostics
- sensitivity

Human approval前はCausal defaultをDRAFT decisionとして扱う。

## 6. API error behavior

Catalog構成にinternal invariant violationがある場合、欠損Familyをsilentに返すよりstartup/testでfail-fastすることを優先する。

Runtime responseでerrorを返す必要がある場合はexisting common error formatへ合わせる。

## 7. Caching

catalogはcode-definedで頻繁に変化しないため、Frontend sessionでcacheしてよい。

ただしcacheがroute source-of-truthを置換しない。reload時にversion mismatch等を検出可能にする。

ETag等はENH-E5必須要件ではない。

## 8. Frontend interface

FrontendはAPI responseから次を構成する。

- Family tabs
- current Family label
- Stage sidebar
- default Stage resolution
- route validation

Frontendはpresentation implementationへのbindingとして次のようなregistryを持ってよい。

```text
(EXPLORATORY, profile) -> existing profile surface renderer
(PREDICTIVE, setup) -> existing predictive setup renderer
(CAUSAL, identification) -> existing identification surface renderer
```

このregistryは**renderer implementation binding**であり、label/order/defaultのcanonical catalogではない。

## 9. Route interface

Canonical page route:

```text
/projects/{project_id}/analysis/{family_slug}/{stage_slug}
```

API routeとbrowser page routeを混同しない。

Browser route parserはcatalogを使ってfamily/stage validityを確認する。

## 10. Legacy route mapping

existing route inventoryをG01 freeze前に具体化する。

Target concept:

```text
/projects/{project_id}/explore
  -> /projects/{project_id}/analysis/exploratory/profile

/projects/{project_id}/causal
  -> /projects/{project_id}/analysis/causal/discovery

/projects/{project_id}/predictive
  -> /projects/{project_id}/analysis/predictive/setup
```

legacy compatibilityはFrontend redirect/history replaceまたはserver routingのcurrent architectureに合う方法で実装する。

semantic targetは06/Pxxでfreezeする。

## 11. Existing execution APIとの境界

ENH-E5 navigation endpointはexisting execution APIを置換しない。

analysis executionはexisting Analysis Specification / Execution Plan / Execution command contractを使用する。

CLI / library / backend use caseへnavigation endpointの利用を必須化しない。

悪い依存:

```text
CLI run
  -> GET navigation catalog
  -> resolve current Stage
  -> execution API
```

これは不要である。

望ましい依存:

```text
CLI/library
  -> Analysis Spec / Use Case
  -> existing execution application/runtime
```

## 12. Project-specific availabilityとの境界

Navigation Stageの存在と、現在resource stateでoperation可能かどうかは別概念である。

例えば`Causal / Estimation` Stageは常にnavigation上存在しても、identification未成立ならRun操作がdisabled/blockedになることがある。

このavailabilityをNavigation catalog自体からStage削除で表現しない。既存operation availability/validation mechanismがある場合はそちらを用いる。

## 13. Security / authorization

navigation catalogがproject-independent static metadataである場合、sensitive project dataを含めない。

project page自体のaccess controlはexisting project authorizationに従う。

## 14. Compatibility

- Endpoint: additive
- Existing API removal: NONE
- Existing request schema change: NONE
- Existing response schema change: NONE
- DB migration: NONE
- New write endpoint: NONE

## 15. API test requirement

最低限:

- 200 response schema version
- all 3 Family present
- deterministic order
- Family-specific Stage IDs/order/default
- no duplicate Family/Stage
- no runtime lifecycle field leakage
- endpoint callがDB navigation stateを作らない
- existing API regression green
