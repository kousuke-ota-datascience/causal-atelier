# ENH-E5 Enhancement Concept Approval Record

Document class: Planning / Approval Artifact
Decision status: **PENDING_HUMAN_APPROVAL**
Prepared: `2026-08-11T11:12:00+09:00`

## 1. Proposed approved scope

- Family × Navigation Stage application model
- 上部Family tab + Family-local左Stage navigation
- capability-owned concrete stage catalog
- Navigation Stage / Execution Stage separation
- backend descriptor API
- URL canonical current Family/Stage
- legacy route compatibility
- Exploratory/Predictive/CausalのFamily-specific UI再構成
- Predictive existing settings and semantics 100% preservation
- cross-family Results/Lineage compatibility

## 2. Proposed approval conditions

1. G00 freeze前に`BASELINE_FULL_SHA`を確定しなければならない。
2. Predictive inventoryはvisible form field **および** generated `predictive-analysis-spec/1` defaultの両方を網羅しなければならない。
3. Human approvalによるarchitecture contractの明示的amendmentなしにDB migrationを導入してはならない。
4. 新しいanalytical engine/libraryを追加してはならない。
5. Navigation StageをExecution `StageType`のalias/subclassとして実装してはならない。

## 3. Explicitly not approved in this enhancement

- LightGBM / DoWhy / EconML
- standalone batch/online scoring API
- Model Management write lifecycle/deployment
- Overview/Flagship
- Analysis Management
- new common Evidence/Findings domain
- Result schema flattening/replacement

## 4. Human owner decision

`PENDING_HUMAN_APPROVAL`

approveする場合、Human ownerはこのsectionを以下へ変更する:

- 決定: `APPROVED`
- Approved by: `<identity>`
- Approved at: `<ISO8601>`
- 条件/追加除外: `NONE`または明示的な記述

draft作成指示だけではGate PASSまたはarchitecture approvalとはみなさない。
