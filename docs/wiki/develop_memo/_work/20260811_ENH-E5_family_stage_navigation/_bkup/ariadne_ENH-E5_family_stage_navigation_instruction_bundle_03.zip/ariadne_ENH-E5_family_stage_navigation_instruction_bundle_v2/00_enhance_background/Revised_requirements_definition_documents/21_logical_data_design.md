# 21 論理データ設計 — ENH-E5 revised target snapshot

- 文書状態: `DRAFT_FOR_REVIEW`
- 対象: Family / Navigation Stage descriptor、navigation state、既存persistent resourceとの境界

## 1. 設計目的

ENH-E5ではapplication navigationを構造化するが、navigationのために新しいpersistent business entityを導入しない。

論理データ設計上の中心は、次の2種類のdataを分離することである。

1. **Persistent analytical data** — Project、Research Context、Dataset Version、Analysis View、Analysis Specification、Execution、Result、Artifact等。
2. **Non-persistent navigation descriptor/state** — Family catalog、Navigation Stage catalog、Current Family/Stage。

## 2. Existing persistent entityの扱い

ENH-E5では次のexisting entity semanticsを原則変更しない。

- Project
- Research Context / version
- Dataset Version
- Analysis View
- Analysis Specification
- Execution Plan
- Execution / StageExecution
- Result
- Artifact
- Annotation / Lineage relation（current implementationに存在する範囲）

Navigation Stageを追加するために、これらへ`current_stage`等のfieldを追加しない。

## 3. AnalysisFamily

current product domainに既存の`AnalysisFamily`が存在し、少なくとも次のvaluesを持つ。

```text
EXPLORATORY
CAUSAL
PREDICTIVE
```

ENH-E5ではこれをFamily identityとして再利用する。

新たに`NavigationFamily`等のduplicate enumを作成しない。

## 4. Navigation descriptor model

Target logical model:

```text
FamilyNavigationDescriptor
  family: AnalysisFamily
  slug: str
  label: str
  default_stage_id: str
  stages: ordered tuple[NavigationStageDescriptor, ...]

NavigationStageDescriptor
  stage_id: str
  slug: str
  label: str
  order: int
```

実装上`slug == stage_id`等の簡略化を選ぶことは可能だが、API/route contract上の識別子とpresentation labelを混同しない。

## 5. Descriptor invariant

### 5.1 Family uniqueness
1 descriptorは1 `AnalysisFamily`に対応し、aggregate内でFamily duplicateを許可しない。

### 5.2 Non-empty stage set
support対象Familyは少なくとも1 Navigation Stageを持つ。

### 5.3 Stage uniqueness
`stage_id` / `slug`はFamily内でuniqueである。

### 5.4 Default stage validity
`default_stage_id`は同一Familyの`stages`に正確に存在しなければならない。

### 5.5 Deterministic order
同一code/versionから常に同一orderを返す。

### 5.6 No runtime lifecycle fields
Navigation descriptorには次を含めない。

- runner ID
- dependency DAG
- execution status
- retry / attempt state
- execution input/output contract
- persisted StageExecution identity
- operation prerequisite completion state

これらはExecution Stage側のconcernである。

## 6. Family-specific catalog

### 6.1 Exploratory

| stage_id | label | intent |
|---|---|---|
| `profile` | Profile | dataset overview |
| `data-quality` | Data Quality | quality observation |
| `distribution` | Distribution | univariate distribution |
| `relationships` | Relationships | inter-variable relation |
| `comparison` | Comparison | group/segment/cohort comparison |
| `findings` | Findings | exploratory result reuse/summary |

Default target: `profile`。

### 6.2 Predictive

| stage_id | label | intent |
|---|---|---|
| `setup` | Setup | analysis configuration |
| `train` | Train | training/run launch/status |
| `predict` | Predict | prediction result/artifact view |
| `metrics` | Metrics | model performance evaluation |
| `explainability` | Explainability | predictive explanation |
| `model-management` | Model Management | fitted model/model card/artifact/lineage |

Default target: `setup`。

### 6.3 Causal

| stage_id | label | intent |
|---|---|---|
| `setup` | Setup | causal analysis design context |
| `discovery` | Discovery | graph/structure exploration |
| `identification` | Identification | causal identification |
| `estimation` | Estimation | effect estimation execution |
| `effects` | Effects | causal effect result view |
| `diagnostics` | Diagnostics | validity/overlap/balance diagnostics |
| `sensitivity` | Sensitivity | sensitivity/refutation |

Default targetはtarget designで`discovery`を採用候補とする。ただしHuman approval前はDRAFT decisionである。

## 7. Current navigation state

Current Family / StageはENH-E5ではURL stateとする。

```text
/projects/{project_id}/analysis/{family_slug}/{stage_slug}
```

logical state:

```text
NavigationLocation
  project_id
  family_slug
  stage_slug
```

これをDB rowとして保存しない。

## 8. Browser historyとの関係

URLがcanonical navigation stateであるため、history entryごとにFamily/Stageが表現される。

- direct load: URL -> state
- click: state -> URL
- back/forward: URL -> state
- reload: URL -> state

memory-only `currentStage`をURLとは別のsource-of-truthにしない。

## 9. Family switching state

ENH-E5では「Familyごとのlast Stage memory」をpersistent requirementにしない。

Family tab clickはtarget Familyの`default_stage_id`へ遷移する。

将来last-stage memoryを導入する場合も、URL canonicalityと競合しない明示要件が必要である。

## 10. Draft form state

Navigation stateとanalysis draft dataを区別する。

Predictive Setup等でユーザーが未保存入力を持つ場合、Stage visibility切替でinput stateを失わない必要がある。

これは`Current Navigation Stage`をpersistent domainへ保存することとは別問題である。

実装は、既存DOM/formを保持する、または明示的frontend draft storeを用いる等で解決する。

## 11. Navigation descriptorとExecution Stageのデータ境界

```text
NavigationStageDescriptor
  id / label / order / default relation

Execution Stage domain
  stage type / dependency / runner / status / attempt / IO contract
```

両者間にforeign key / inheritance / persisted identityを要求しない。

必要ならpresentation/use-case binding tableをapplication/frontend側に持てるが、それは1:1 execution mappingを意味しない。

## 12. Result model

ENH-E5ではexisting Result envelopeを維持する。

新しい共通`AnalysisResult` persistent hierarchyは導入しない。

Family-specific semantic payloadを`score`等に平坦化しない。

## 13. Migration policy

DB migration: target designでは`N/A`。

次の変更はENH-E5 approved contractなしに行わない。

- new navigation table
- Analysis Specification schema revision
- Execution / StageExecution schema revision
- Result / Artifact schema revision
- last Family/Stage persistence

実装中に必要性が判明した場合はcontract ambiguityとして上流へ戻す。

## 14. Data integrity / validation test

最低限次をautomated testで検証する。

- all supported Family present
- unique Family
- non-empty stage list
- unique stage IDs/slugs in Family
- valid default
- deterministic ordering
- navigation descriptor typeがExecution Stage typeを継承しない
- descriptor payloadにruntime lifecycle fieldが存在しない
- navigation追加でmigration file/schema revisionが生じない
