# ENH-E5 指示書一式 — 次版概要

## 1. Enhancement claim

Ariadneのanalytical capabilityを`Family -> Navigation Stage*`として再構成し、Exploratory / Predictive / Causalをglobal analytical contextとして横断可能にする。

## 2. 原点となるarchitecture issue

Navigation Stageは画面上の作業・閲覧contextであり、backend Execution Stageとは異なる。

- Distribution: read-only viewでexecutionがなくてもよい。
- Metrics: training中に生成済みresultを読むだけでもよい。
- Explainability: 1 Navigation Stageから複数use case/executionがあり得る。
- CLI/library: UI Stageをexecution inputとして要求してはならない。

したがって`Navigation Stage != Execution Stage`を単なる型分離ではなく、dependency-direction invariantとして扱う。

## 3. Gate sequence

```text
G00 -> G01 -> G02 ----\
             G03 -----+-> G05
             G04 ----/
```

- G00: Family / Navigation Stage domain contract
- G01: navigation shell / route / history
- G02: Predictive compatibility + 6 Stage
- G03: Causal 7 Stage
- G04: Exploratory 6 Stage
- G05: cross-family convergence / full regression

## 4. Documentation strategy

### Planning layer
`00〜30`はENH-E4同種文書をbenchmarkとし、背景・理由・構造・互換性を自己完結的に保存する。

### Execution layer
- SINGLE Coding: 06だけ
- Package Coding: assigned Pxxだけ
- Test: 07だけ

上流資料をExecution Agentへ再探索させない。

## 5. Current status

全contractは`DRAFT_FOR_REVIEW`。Human approval / preflight / protected identity convergence後にGateごとにfreezeする。
