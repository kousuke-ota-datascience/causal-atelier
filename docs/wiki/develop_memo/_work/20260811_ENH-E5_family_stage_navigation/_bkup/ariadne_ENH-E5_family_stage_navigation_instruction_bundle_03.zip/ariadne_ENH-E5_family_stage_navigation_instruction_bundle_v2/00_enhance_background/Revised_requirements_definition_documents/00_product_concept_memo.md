# 00 プロダクト構想メモ — ENH-E5 revised target snapshot

- 文書状態: `DRAFT_FOR_REVIEW`
- 対象: Ariadne ENH-E5 Family × Navigation Stage改修
- Implementation status: target conceptを記述する。production実装完了を意味しない。
- 上位概念: Project / Research Topic
- 対象分析Family: Exploratory / Predictive / Causal
- 下位文書: `10_requirements_definition.md`, `21_logical_data_design.md`, `22_product_basic_design.md`, `23_api_interface_design.md`, `30_detailed_design.md`

> 本書は差分要約ではない。ENH-E5適用後にAriadneをどのようなanalytical workspaceとして扱うか、その背景・判断理由・境界を自己完結的に記述する。

## 1. Enhancementの位置づけ

ENH-E5は単なる画面レイアウト変更ではない。

中心となる変更は、Ariadneのanalytical capabilityを **Family × Family-owned Navigation Stage** というapplication modelで構造化し、そのmodelをUI、navigation、route、capability ownershipへ反映することである。

変更面は次に及ぶ。

- information architecture
- application navigation model
- capability ownership
- current Family / Stage state
- route / deep link / browser history
- 既存機能の再配置
- Family間のanalytical context表現

一方で、ENH-E4のようなexecution authority / persistence / lifecycleそのものの全面再構築は目的としない。ENH-E5はruntime engineを作り直すのではなく、既存のanalytical capabilityを適切なapplication structureとして提示する改修である。

## 2. Ariadneのプロダクト像

Ariadneは単一の因果分析画面ではなく、同一のProject / Research Topicに対して複数のanalytical perspectiveを扱うanalytical workspaceである。

ENH-E5では、少なくとも次の3 Familyをfirst-classに扱う。

- `Exploratory`
- `Predictive`
- `Causal`

これらは単なるメニュー分類ではない。それぞれが異なる問い、成果、検証観点を持つanalytical capability contextである。

```text
Research Topic / Decision Context
        │
        ├─ Exploratory: データに何が見えるか
        ├─ Predictive : 将来・未知をどの程度予測できるか
        └─ Causal     : 介入した場合に何が変わるか
```

三者は相互に参照できるが、意味論を平坦化しない。Predictive explanationをcausal effectとして扱わず、exploratory associationをconfirmatory conclusionとして扱わない。

## 3. Family / Stageの基本モデル

application-levelの抽象modelは薄く保つ。

```text
Family
 └─ Navigation Stage*
```

abstract layerが知るべきことは次で十分である。

- Familyが存在する
- FamilyごとにNavigation Stageが存在する
- Current Familyが存在する
- Current Navigation Stageが存在する
- Family切替とStage切替がnavigation operationとして存在する

abstract layerは`Discovery`, `Train`, `Estimation`, `Metrics`, `Distribution`等の具体的domain semanticsを知らない。

concrete Stage名・Stage内部UI・use caseとのbindingはCapability側が具象化する。

## 4. FamilyとStageの役割差

ENH-E5では次の区別を基本とする。

```text
Family = global analytical context
Stage  = Family-local work / view context
```

Familyは「どのanalytical perspectiveでResearch Topicを見るか」を表すglobal navigation dimensionである。

Navigation Stageは「そのFamilyの中で何を設定・実行・閲覧・評価しているか」を表すlocal contextである。

Stageはwizard stepではない。Stage順序は必須progressionを意味せず、ユーザーは条件が許す範囲で必要なStageへ直接移動できる。

## 5. Familyタブを常時表示する理由

Familyを上部横タブとして常時表示する理由は、「Stage名だけではFamilyが推測できないから」ではない。

本質は、**Familyそのものが独立したnavigation dimensionだから**である。

Familyタブには次の意味がある。

1. Current Familyをapplication stateとして明示する。
2. 他に利用可能なanalytical perspectiveを常時認識できる。
3. Family間の横断移動をfirst-class operationにする。
4. Ariadneが複数analytical perspectiveを統合するworkspaceであることをUI構造で示す。

したがって、上部タブに`Overview`等の非Family概念を混在させる場合は別のnavigation dimensionを混ぜることになる。ENH-E5ではOverview/Flagshipは実装せず、将来global workspaceとして再検討する。

## 6. Navigation StageとExecution Stageを分離する原点

### 6.1 問題意識

ユーザーが画面上で認識・移動する作業/閲覧contextと、backend runtimeが処理を実行する単位は一致しない。

そのため、次をarchitecture invariantとする。

> **Navigation Stage != Execution Stage**

Navigation Stageはapplication/navigation concernである。Execution Stageはrunner、dependency、status transition、attempt、artifact binding等を持つruntime concernである。

### 6.2 具体例A — Exploratory / Distribution

UI上では、`Exploratory / Distribution`を1つのNavigation Stageとして表示することが自然である。

しかし、その画面が既存Dataset/Resultからhistogram、quantile、category frequencyを読み出して表示するだけなら、backendに`ExecutionStage.DISTRIBUTION`という独立runtime stageを新設する必要はない。

```text
Navigation:
Exploratory / Distribution
        ↓
existing profile/result/query/read model
```

Navigation Stageの存在は、同名Execution Stageの存在を意味しない。

### 6.3 具体例B — Predictive / Metrics

UI上では`Predictive / Metrics`を独立Stageとする。

一方、runtimeではmodel trainingの実行中にすでに`evaluate`が完了し、保存済みevaluation resultをMetrics画面が読むだけかもしれない。

```text
Runtime:
prepare -> fit -> evaluate -> persist
                      │
                      └─ saved result
                              ↓
Navigation:
Predictive / Metrics
```

この状況でUIに合わせて新しい`METRICS` Execution Stageを作ると、runtime modelへ架空のsemanticを導入することになる。

### 6.4 具体例C — Predictive / Explainability

UI上は1つの`Explainability` Stageでも、内部でfeature importance、SHAP、PDP等について複数use case / executionが存在してよい。

```text
1 Navigation Stage
   ├─ explanation result read
   ├─ optional explanation computation A
   └─ optional explanation computation B
```

逆に、1 Executionから生成された複数artifactを複数Navigation Stageが参照してもよい。

したがってNavigation StageとExecution Stageの1:1 mappingを前提にしない。

### 6.5 同一化した場合の実害 — CLI / libraryへのleakage

Navigation Stageをbackend execution contractへ流用すると、CLIやPython APIでanalysisを直接実行する際にもUI taxonomyを構築しなければならない設計になり得る。

悪い例:

```text
model trainingを実行したい
  ↓
Current Family = Predictive を設定
Current Navigation Stage = Train を設定
  ↓
初めてbackend use caseを呼べる
```

これはapplication/navigation modelのexecution APIへのleakageである。

CLI / library / backend use caseは、必要なAnalysis Specificationやuse-case inputだけで実行できなければならない。

`AnalysisFamily`がanalysis typeのdomain discriminatorとして現れることは許容する。しかし`Current Navigation Stage`はexecutionを成立させる必須入力にしない。

依存方向は次とする。

```text
Family / Navigation Stage
        ↓ selects / presents
Capability / Use Case
        ↓ plans / executes
Runtime / Execution Stage
```

runtime側がNavigation Stageを要求する逆依存は導入しない。

## 7. Capability ownership

FamilyはCapability contextに対応する。

concrete Stage catalogは各Capabilityが所有する。

```text
Application abstraction
Family -> Navigation Stage*
        ↓ concrete definition
Capability layer
Exploratory Capability
Predictive Capability
Causal Capability
```

product/application layerはgenericなaggregation、validation、deliveryを担当してよいが、Family-specific Stage taxonomyを集中管理しない。

この方針により、将来Family固有のStageが増減してもabstract modelを変更せず拡張できる。

## 8. Exploratory Family

### 8.1 Stage working set

```text
Exploratory
├─ Profile
├─ Data Quality
├─ Distribution
├─ Relationships
├─ Comparison
└─ Findings
```

ExploratoryはPredictive/Causalより非線形な探索であるため、workflow順ではなく**探索観点**でStageを分ける。

### 8.2 Profile
Dataset全体を把握するcontext。shape、schema、type、cardinality、summary statistics、metadata等を扱う。

### 8.3 Data Quality
missing、duplicate、outlier candidate、invalid value、unexpected category、coverage等を扱う。ENH-E5で新規quality engineを追加することは目的ではなく、現行capabilityで利用可能な情報を適切に配置する。

### 8.4 Distribution
主に単変量分布を扱う。histogram、density、quantile、category frequency等のvisualizationはこのStageの表現手段である。

### 8.5 Relationships
変数間のrelationを探索する。scatter、correlation、cross-tab、grouped distribution、conditional relationship等を扱うが、因果意味論を付与しない。

### 8.6 Comparison
segment、group、before/after、region、cohort等の比較context。

### 8.7 Findings
探索結果をfinding/evidenceとして再利用する接続点。ただしENH-E5では新規persistent `Finding` entityを必須導入しない。既存Result / Annotation / Lineageで表現可能な範囲を優先する。

### 8.8 Visualizationを独立Stageにしない理由

Visualizationはanalytical contextではなくrepresentation techniqueである。

- Distribution -> histogram
- Relationships -> scatter
- Comparison -> boxplot

`Visualization`をStageとして置くと、「何を調べるか」と「どう表現するか」という異なる分類軸が混在する。そのため独立Stageにはしない。

## 9. Predictive Family

### 9.1 Stage working set

```text
Predictive
├─ Setup
├─ Train
├─ Predict
├─ Metrics
├─ Explainability
└─ Model Management
```

### 9.2 既存設定100%保持

ENH-E5の最重要compatibility requirementの一つである。

既存Predictive画面の設定項目は「新UIに合わせて簡略化する対象」ではない。

基本方針:

> **既存設定項目100%保持 + Stage構造への再配置 + 必要なnavigation capability追加**

visible fieldだけでなく、generated specのdefault、split semantics、preprocessing、metric、explanation condition等のhidden semanticsも保護する。

### 9.3 Setup
目的変数、feature/input、split、実行条件等を設定するcontext。現行Predictiveの設定を欠落させない。

### 9.4 Train
model training/runを開始し、statusを確認するcontext。ただしNavigation `Train`をExecution `TRAIN`と同一視しない。既存execution pipelineはそのまま利用できる。

### 9.5 Predict
学習済みmodelから得られるprediction-bearing result/artifactを扱うcontext。ENH-E5で新規standalone online/batch scoring engineを追加することを意味しない。

### 9.6 Metrics
performance evaluationを扱う。classification/regressionに応じたmetric、validation comparison、error analysis等を扱う。

### 9.7 Explainability
model behaviorの説明を扱う。feature importance、permutation importance、SHAP、PDP/ICE、local explanation等。causal effectとは明確に区別する。

### 9.8 Model Management
ENH-E5ではscopeを限定し、既存fitted model、model card、artifact、lineage等のread-oriented management surfaceとする。full model registry、deployment lifecycle、servingはscope外。

## 10. Causal Family

### 10.1 Stage working set

```text
Causal
├─ Setup
├─ Discovery
├─ Identification
├─ Estimation
├─ Effects
├─ Diagnostics
└─ Sensitivity
```

### 10.2 Setup
Dataset、treatment、outcome、covariate候補、unit、population、time window、estimand、assumptions等のanalysis design context。

### 10.3 Discovery
DAG、candidate confounder、mediator、collider、temporal ordering、domain assumption等を検討するcontext。必須のlinear stepとはしない。

### 10.4 Identification
問いは「観測データと仮定から目的causal estimandを識別できるか」である。

adjustment set、identification strategy、exchangeability、positivity、consistency、IV、parallel trends等の識別上の問題を扱う。

### 10.5 IdentificationとEstimationを分ける理由

識別可能性は「何を推定すればcausal quantityになるか」の問題であり、Estimationは「有限標本からそのquantityをどう数値化するか」の問題である。

両者を1つのStageにすると、estimatorを選択できることとcausal estimandが識別されていることがUI上で混同される。

したがって独立Stageとする。

### 10.6 Estimation
regression adjustment、propensity score、IPW、matching、doubly robust、DML、DiD等の推定methodを扱い得るが、ENH-E5で新規engine libraryを導入することは目的ではない。

### 10.7 Effects
推定されたATE/ATT/CATE/subgroup effect/confidence interval等を閲覧・比較・利用するcontext。

`Estimation = 推定処理`、`Effects = 推定結果の閲覧・利用`と分ける。

### 10.8 Diagnostics
covariate balance、overlap、positivity、ESS、weight distribution、nuisance diagnostics等、推定の妥当性確認を扱う。

### 10.9 Sensitivity
unmeasured confounding、alternate adjustment、alternate estimator、placebo/falsification、window/trimming等、assumption/specification依存性を評価する。

## 11. Global project surface

Familyはanalytical navigation dimensionであるため、Project全体のsurfaceをFamily配下へ無理に入れない。

ENH-E5 targetでは少なくとも次をglobal surfaceとして扱う。

- Project / Management
- Research Context
- Data / Dataset / Analysis View
- Results / Lineage

これらはFamily切替の外側に存在し得る。

## 12. Flagship / 看板画面の将来構想

Ariadneの長期的な看板価値は、複数データ・複数Familyのanalysis resultを意思決定へ接続することである。

概念例:

```text
Decision / Question
      │
      ├─ Exploratory Findings
      ├─ Predictive Results
      └─ Causal Effects
             ↓
          Evidence
```

ただしENH-E5では`Overview`をFamily peerとして上部tabへ追加しない。Overview/Decision workspaceが必要なら、Familyとは別のglobal navigation dimensionとして後続Enhancementで設計する。

## 13. Analysis Result共通化の方向

将来的にはcommon envelope + Family-specific typed payloadが候補である。

```text
AnalysisResult
├─ lineage
├─ analysis family/type
├─ method
├─ status
├─ artifact
└─ typed payload
   ├─ PredictiveResult
   ├─ CausalEffectResult
   └─ ExploratoryFinding
```

ただしPredictive metricとcausal effectを同じ`score`として平坦化しない。

ENH-E5ではexisting Result modelを維持し、この共通化を新規persistent hierarchyとして実装しない。

## 14. External analytical engineを今回導入しない理由

LightGBM、DoWhy、EconML等は後続Enhancement候補とする。

ENH-E5の目的はanalytical application model / navigation / capability responsibilityの確立であり、concrete analytical engine追加ではない。

望ましいarchitectureは、将来

```text
Predictive -> LightGBM adapter
Causal -> DoWhy adapter / EconML estimator
```

を追加してもFamily / Navigation Stage modelを作り直さずに済むことである。

## 15. 成功条件

ENH-E5の価値は「新しいタブが表示された」ことではない。

成功とは少なくとも次が成立することである。

- 3 Familyがglobal analytical contextとして明示される。
- selected FamilyのStageがlocal contextとして一貫表示される。
- Navigation StageとExecution Stageがarchitecture上分離される。
- CLI/library/backend use caseがNavigation Stageなしでanalysis executionできる。
- Predictive既存設定/semanticsが欠落しない。
- Causal Identification / Estimationが概念上分離される。
- Exploratory visualizationがanalysis contextと混同されない。
- Family切替後もProject context、Results、Lineageへ一貫して到達できる。
- 新engine / DB migration / result-domain再設計を混入させない。

## 16. 用語

| 用語 | 定義 |
|---|---|
| Family | Ariadneにおけるglobal analytical capability context。Exploratory/Predictive/Causal。 |
| Navigation Stage | Family内の主要な作業・閲覧context。UI/route上のnavigation概念。 |
| Execution Stage | backend runtimeの実行単位。dependency/status/runner等のexecution semanticsを持ち得る。 |
| Capability | Family固有のStage semantics、use case、analysis contractを具象化するmodule/layer。 |
| Current Family | 現在UIで選択されているanalytical Family。 |
| Current Stage | Current Family内で選択されているNavigation Stage。 |
| Family switching | global analytical contextを切り替えるfirst-class navigation operation。 |
| Renderer binding | semantic `(family, stage)`をfrontend実装surfaceへ結びつけるbinding。catalog sourceそのものではない。 |
