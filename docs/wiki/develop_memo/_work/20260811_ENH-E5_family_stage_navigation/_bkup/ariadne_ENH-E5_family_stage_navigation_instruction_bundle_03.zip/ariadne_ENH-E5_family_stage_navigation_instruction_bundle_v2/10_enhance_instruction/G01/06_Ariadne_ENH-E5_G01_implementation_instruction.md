# Ariadne ENH-E5 G01 実装指示書 — Gate Coding Contract（Gate実装契約）

文書区分: Primary Execution Contract（主要実行契約）
自己完結性: MUST（必須）

- プロジェクト: Ariadne
- Enhancement: ENH-E5
- Active Gate: G01
- Gate title: URL-driven Family / Stage Navigation Shell（URL駆動Family/Stage navigation shell）
- Branch: `feature/ariadne_mvp_e5`
- Baseline SHA: `46122c68333df03680b97c253a7b5d32bf9393e7`
- 契約状態: **DRAFT_FOR_REVIEW**（レビュー前ドラフト）
- Execution Mode: `WORK_PACKAGE`


## 0. 実装時の参照ポリシー — 単一normative contract

本GateのGate-level implementation semanticsについて、**本06文書を唯一のnormative authority**とする。

### 0.1 SINGLE_EXECUTIONの場合
Coding Agentは、本06のみから`WHAT / WHY / scope / boundary / prohibited change / required outcome`を判断する（MUST）。

仕様を補完する目的で、00〜30、ADR、Gate decomposition、07、他Gate文書、過去Enhancement、issue、commit message、外部Webを参照してはならない（MUST NOT）。

### 0.2 WORK_PACKAGEの場合
本06はGate-level authorityであるが、各Package Coding Agentへは**assigned Pxxだけ**をnormative inputとして与える。Pxxには当該packageに必要な本06のeffective constraintsを事前に収束させる。Package Agentに06/P00/07/ADR等を併読させて仕様を合成させてはならない。

### 0.3 Repositoryの扱い
current source code、existing tests、schema/type/interface、configuration、route/API implementation、repository structureはimplementation factを調べるために参照してよい。

ただしrepositoryは仕様authorityではない。

> **Repositoryから実装方法を発見してよいが、仕様を発見してはならない。**

current codeが本contractと異なることを理由にcontractを追加・緩和・変更してはならない。

### 0.4 Contract ambiguity
本contractだけではrequired behavior、ownership、scope、compatibility、migration、architecture choiceを一意に決定できない場合、他資料を探索して補完せず`BLOCKED_CONTRACT_AMBIGUITY`で停止する（MUST）。

### 0.5 Freeze condition
本06の外部資料を読まなければCoding Agentが判断できないnormative事項が残っている場合、本06を`FROZEN`にしてはならない。

## 1. Gate定義 / acceptance claim

### 目的
canonical catalogを利用してtop Family tabs + Family-local Stage sidebarを成立させ、URL/deep link/history/legacy route compatibilityを確立する。

### PASS後に後続Gateが利用できる成果
Family-specific G02-G04が同一navigation shell上へStage contentを安全に配置できる。

### この単位を1つのGateとする理由
この境界は、独立してaccept/protectできる1つのsemantic claimである。実装量が大きい場合は、Execution Modeが`WORK_PACKAGE`のときにWork Packageで分割する。

## 2. 実装時に有効な前提

- Familyはanalytical capabilityのcontextである。
- Navigation StageはUI/application上の作業・閲覧contextである。
- `Navigation Stage != Execution Stage` を維持する。
- Stageの名称・数はFamilyごとに異なってよい。
- Stage navigationを必須のsequential workflowとはみなさない。
- このGateで明示的に変更しない限り、既存のanalysis execution/persistence semanticsを保護する。
- 外部analytical engineの追加はENH-E5のscope外である。

このGateに対応するAcceptance target:
- AC-G01-001: 上部tabにbackend catalog由来のExploratory/Predictive/Causalだけを表示し、current Familyを視覚的に識別できる。
- AC-G01-002: 左sidebarにはcurrent Familyが所有するStageだけを表示し、current Stageを識別できる。
- AC-G01-003: canonical URLを`/projects/{id}/analysis/{family}/{stage}`とし、direct loadとbrowser back/forwardでstateを復元できる。
- AC-G01-004: Family切替時は対象Familyが宣言するdefault Stageへnavigateし、last-stage persistenceは使用しない。
- AC-G01-005: legacy `/explore`、`/causal`、`/predictive` routeを文書化されたcanonical targetへnormalizeする。
- AC-G01-006: Management、Context、Data、Results/LineageはFamily tab外のglobal project surfaceとして維持する。
- AC-G01-007: unknown Family/Stageを黙って別contextへ解釈せず、明示的navigation errorと有効な代替先を提示する。
- AC-G01-008: Stage navigation自体はnon-sequentialであり、wizard completionを強制しない。

## 3. Execution Mode の決定

Mode: `WORK_PACKAGE`。

Operator / Planning担当は`06_G01_P00_work_package_plan.md`と計画済みPxxを用いてPackage分解・依存関係・統合順序を管理する。ただしPackage Coding Agentへ渡すnormative inputは**assigned Pxxのみ**とし、06 / P00 / 他Pxxを併読させてscopeや仕様を再合成させてはならない。Package completionはGate PASSを意味しない。

## 4. 必須の実装semantics

実装は、保護対象upstream contractの意味を変えずにGate目的を成立させなければならない（MUST）。このGateで明示的に必要としない限り、現在のanalysis spec、execution plan、result schema、algorithmを保持するadditive/refactoring変更を優先する。

## 5. 許可されるscope

- descriptor-driven Family tab / Stage sidebar
- canonical analysis route
- browser history / deep link
- legacy route normalization
- global workspaceとの責務分離
- navigation error handling

## 6. 明示的な禁止scope

- family-specific analytical semantics redesign
- family/stageのworkspace-state DB persistence
- new Overview tab
- removal of global Results/Lineage

全Gate共通の禁止事項:
- testをgreenにすることだけを目的としたassertion弱体化、test削除、skip、xfailは禁止;
- requirement/ACの無断変更は禁止;
- 後続Gateの作業をこのGateへ混入させない;
- 未承認のschema/dependency/engine拡張は禁止。

## 7. 保護対象となる既PASS Gate contract

先行ENH-E5 Gateのfinal-PASS contractすべて。**freeze前に具体的Gate ID / protected invariant / evidence identityを本06へ転記すること。未確定のままAgent executionへ渡してはならない。**

本06をfreezeする担当者が、必要なprotected Gate identity / evidenceをfreeze前に本節へ具体値として転記する。Coding AgentへCurrent State Control Sheetの再探索を要求しない。

## 8. Transition Debt

計画上は`NONE`。後続へ延期したscopeはTransition Debtではない。

一時的な例外挙動が不可避になった場合は停止し、architecture/Humanの明示的判断を求める。文書化されていないdebtを勝手に作らない。

## 9. Schema / migration / API / runtime ポリシー

- DB schema migration: 明示的なamendmentがない限り`PROHIBITED`。
- AnalysisSpecification/Execution/Result schema変更: このGateで明示しない限り`PROHIBITED`。
- Execution lifecycle: 既存semanticsを保持する。
- API変更: このGateで明示的に必要とするadditive変更だけを許可する。
- legacy analytical route: 保持または明示的にnormalizeし、無断削除しない。

## 10. 自動テスト義務

- AC-G01-001について自動テストevidenceを実装する: 上部tabにbackend catalog由来のExploratory/Predictive/Causalだけを表示し、current Familyを視覚的に識別できる。
- AC-G01-002について自動テストevidenceを実装する: 左sidebarにはcurrent Familyが所有するStageだけを表示し、current Stageを識別できる。
- AC-G01-003について自動テストevidenceを実装する: canonical URLを`/projects/{id}/analysis/{family}/{stage}`とし、direct loadとbrowser back/forwardでstateを復元できる。
- AC-G01-004について自動テストevidenceを実装する: Family切替時は対象Familyが宣言するdefault Stageへnavigateし、last-stage persistenceは使用しない。
- AC-G01-005について自動テストevidenceを実装する: legacy `/explore`、`/causal`、`/predictive` routeを文書化されたcanonical targetへnormalizeする。
- AC-G01-006について自動テストevidenceを実装する: Management、Context、Data、Results/LineageはFamily tab外のglobal project surfaceとして維持する。
- AC-G01-007について自動テストevidenceを実装する: unknown Family/Stageを黙って別contextへ解釈せず、明示的navigation errorと有効な代替先を提示する。
- AC-G01-008について自動テストevidenceを実装する: Stage navigation自体はnon-sequentialであり、wizard completionを強制しない。

変更moduleに対するfocused existing testと、diffの影響を受けるすべての保護対象upstream contractを対象としたregression testも実行する。

## 11. Candidate Assembly（候補成果物の組み立て）

`READY_FOR_TEST`へ移行する前に:
1. 必須の実装scopeがすべて完了していること;
2. Packageがある場合、すべてに有効なcheckpoint reportがあること;
3. 未解決blockerが`NONE`であること;
4. focusedおよびGate-wide self-verificationが記録されていること;
5. production/test/migration/dependency diffがレビュー済みであること;
6. implementation completion reportにFixed Trial Candidate SHAが1つ記録されていること。

## 12. Coding Agent の禁止作業

Coding Agentは以下をしてはならない:
- Gate PASSを判定する;
- 07 Acceptance Criteriaを変更する;
- Package完了をpartial PASSとして扱う;
- amendmentなしに既PASS Gateのsemanticsを変更する;
- 対象外の後続featureを実装する。

## 13. 必須成果物

- Trial01（またはcurrent Trial）のimplementation completion report
- 必要に応じたGate-local implementation ledger/detail
- `WORK_PACKAGE`時のPackage checkpoint/status report
- 正確なFixed Trial Candidate SHA
- 実行commandとtest evidence
- 明示的なblocker status

## 14. 外部参照ポリシー

source code pathおよび観測したruntime/test outputはevidenceとして参照してよい。実行に必要な規範的ルールは本contract、およびWork Package modeでは割り当てられたPxx contractに記載する。
