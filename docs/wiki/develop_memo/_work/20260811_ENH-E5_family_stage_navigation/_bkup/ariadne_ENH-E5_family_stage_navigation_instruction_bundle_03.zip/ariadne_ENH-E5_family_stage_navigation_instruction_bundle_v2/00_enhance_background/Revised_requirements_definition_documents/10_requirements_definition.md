# 10 要件定義 — ENH-E5 revised target snapshot

- 文書状態: `DRAFT_FOR_REVIEW`
- 対象: Family × Navigation Stage application/navigation model
- Implementation status: target requirement。production completionを意味しない。

## 1. 目的

本書はENH-E5適用後に満たすべきproduct / application / compatibility requirementを定義する。

本書は差分一覧だけではなく、各要件の意味、理由、禁止解釈、検証観点を含むeffective requirement snapshotである。

## 2. 背景となる問題

現行workspaceではanalytical FamilyとFamily内のworkflow/view contextがnavigation上で混在し、ユーザーが「どのanalytical perspectiveにいるか」と「その中の何をしているか」を別dimensionとして認識しづらい。

またcurrent backendにはexecution lifecycleを表すgeneric Stage abstractionが存在するため、UI上のStageを既存Execution Stageへ流用すると、navigation taxonomyの変更がCLI/library/runtime contractへ波及する危険がある。

ENH-E5はこの2つを同時に解決する。

## 3. Requirement levels

- `MUST`: ENH-E5 acceptanceに必須。
- `MUST NOT`: 実装してはならない。
- `SHOULD`: 強い推奨。逸脱には明示理由が必要。

## 4. Application / Navigation requirement

### E5-REQ-001 — Familyをglobal analytical navigation dimensionとして明示する — MUST

Exploratory / Predictive / Causalを上部Family navigationとして常時認識可能にする。

**理由:** FamilyはStage名の補助labelではなく、独立したanalytical perspectiveである。

**Acceptance meaning:** current Familyが視覚・route上で一意に判別でき、他Familyへfirst-class operationとして移動できる。

### E5-REQ-002 — StageをFamily-local work/view contextとして扱う — MUST

left sidebar等のFamily-local navigationにはselected Familyが提供するNavigation Stageだけを表示する。

**禁止解釈:** Stage順序をwizard completionやruntime dependencyとして扱わない。

### E5-REQ-003 — Navigation StageとExecution Stageを分離する — MUST

Navigation descriptor/typeはexecution `StageType`, `StageDefinition`, `StageExecution`等を再利用・継承しない。

**理由:** Navigation Stageは閲覧だけの場合もあり、1 Stageが複数executionを起こす場合もあるため1:1でない。

### E5-REQ-004 — Navigation Stageはanalysis executionの必須inputではない — MUST

CLI / Python library / backend use case / runtime executorは`Current Navigation Stage`を指定せずにanalysisを実行可能でなければならない。

`AnalysisFamily`をanalysis type discriminatorとして用いることは許容する。

**禁止:** model training等を呼ぶために`current_stage=train`のapplication stateを要求すること。

### E5-REQ-005 — runtime layerはNavigation Stageへ逆依存しない — MUST

runtime execution contractがNavigation Stage ID、UI route、sidebar stateを要求してはならない。

### E5-REQ-006 — concrete Stage catalogはCapabilityが所有する — MUST

各Capabilityが自身のStage ID、label、order、default Stageを定義する。generic product/application layerはaggregation/validationを担当する。

### E5-REQ-007 — Family/Stage catalogのcanonical semantic sourceを一つにする — MUST

Frontendに同一のlabel/order/default catalogを完全重複定義しない。

Target designではbackend descriptor APIをcanonical sourceとする。

### E5-REQ-008 — Current Family/Stageをdeep-linkableにする — MUST

canonical routeからFamily/Stageを復元でき、reload / browser back / browser forwardでdeterministicに復元する。

Target canonical route:
`/projects/{project_id}/analysis/{family_slug}/{stage_slug}`

### E5-REQ-009 — navigation stateをE5ではpersistent domainへ追加しない — MUST NOT

Current Family/StageをDB schemaやworkspace-state persistent entityへ追加しない。

**理由:** ENH-E5で必要なのはshareable/history-aware URL stateであり、cross-session last-view semanticsは要件化されていない。

### E5-REQ-010 — Family/Stage navigationをwizard化しない — MUST

navigation progressionとoperation prerequisiteを別扱いにする。

UI上でStage順が表示されても「前Stage完了が必須」とは限らない。

## 5. Exploratory requirement

### E5-REQ-011 — Exploratoryを6 Navigation Stageへ再構成する — MUST

- Profile
- Data Quality
- Distribution
- Relationships
- Comparison
- Findings

### E5-REQ-012 — Exploratoryは探索観点でStageを分ける — MUST

linear execution sequenceを前提にしない。

### E5-REQ-013 — Visualizationを独立Stageにしない — MUST NOT

chartはDistribution/Relationships/Comparison等の内部representationとして扱う。

### E5-REQ-014 — Findingsで新規persistent domainを必須化しない — MUST

ENH-E5では既存Result / Annotation / Lineageで表現可能な範囲を利用し、新規Finding/Evidence schema導入はscope外とする。

### E5-REQ-015 — Exploratory relationをcausal semanticsとして表示しない — MUST NOT

correlation、association、group difference等をcausal effectとしてlabelしない。

## 6. Predictive requirement

### E5-REQ-016 — Predictiveを6 Navigation Stageへ再構成する — MUST

- Setup
- Train
- Predict
- Metrics
- Explainability
- Model Management

### E5-REQ-017 — Predictive existing configurationを100%保持する — MUST

現行UIで利用可能な設定fieldを削除しない。名称変更・Stage移動は許容するが、意味と入力可能性を失わせない。

最低限inventory対象:

- Active Research Context
- Dataset Version
- Analysis View
- Task Type
- Prediction unit
- Target column
- Prediction time
- Horizon
- Intended use
- Deployment population
- Feature columns
- Excluded columns
- Split strategy
- Seed
- Train ratio
- Validation ratio
- Test ratio
- Explanation method
- Explanation sample size
- Local explanations flag

実装前にcurrent code/UIから再inventoryし、上記以外が存在すれば追加して100% traceする。

### E5-REQ-018 — Predictive generated spec semanticsを保持する — MUST

visible fieldだけでなく、current `predictive-analysis-spec/1` のdefault/hidden semanticsを保護する。

例:

- feature availability cutoff semantics
- split ratio / seed
- preprocessing fit partition
- imputation / scaling / encoding
- model ID/current parameters
- tuning partition
- primary metric
- explanation dataset/sampling/method

### E5-REQ-019 — Train Navigation StageをExecution Stageへ1:1 mappingしない — MUST

existing execution pipelineを維持し、UI taxonomyに合わせてruntime stageを再設計しない。

### E5-REQ-020 — Predict Stageで新規standalone scoring engineを導入しない — MUST NOT

既存prediction-bearing result/artifactがある場合に閲覧・利用surfaceを構成する。online serving / new scoring serviceはscope外。

### E5-REQ-021 — MetricsとExplainabilityを意味論上分離する — MUST

Metricsはperformance評価、Explainabilityはmodel behavior説明を扱う。

### E5-REQ-022 — Predictive explanationをcausal effectとして表示しない — MUST NOT

SHAP、feature importance等へ因果意味を付与しない。

### E5-REQ-023 — Model ManagementはE5ではread-oriented scopeとする — MUST

fitted model、model card、artifact、lineage等を対象とし、full model registry / deployment lifecycle / servingは追加しない。

### E5-REQ-024 — Stage切替で未保存Predictive form値を破棄しない — MUST

active page session中のFamily/Stage切替によって、ユーザーが入力済みの保護対象設定値を意図せず失わない。

## 7. Causal requirement

### E5-REQ-025 — Causalを7 Navigation Stageへ再構成する — MUST

- Setup
- Discovery
- Identification
- Estimation
- Effects
- Diagnostics
- Sensitivity

### E5-REQ-026 — Discoveryを必須linear stepにしない — MUST

既存fixed/imported/user-defined graph等から開始できる現行semanticsを壊さない。

### E5-REQ-027 — IdentificationとEstimationを分離する — MUST

Identificationはestimandの識別可能性・strategy・adjustment等、Estimationはfinite-sample estimation method/executionを扱う。

### E5-REQ-028 — EstimationとEffectsを分離する — MUST

Estimationは推定処理、Effectsは推定されたeffectの閲覧・比較・利用。

### E5-REQ-029 — DiagnosticsとSensitivityを分離する — MUST

Diagnosticsは推定/設計の妥当性確認、Sensitivityはassumption/specification依存性確認。

### E5-REQ-030 — 新規causal analytical engineを導入しない — MUST NOT

DoWhy / EconML等のadapter/estimator追加は後続Enhancementへ分離する。

## 8. Cross-family / global requirement

### E5-REQ-031 — Results / Lineageをglobal surfaceとして保持する — MUST

Family切替後もcross-analysis result / lineageへ到達できる。

### E5-REQ-032 — Research Context / Data semanticsを保持する — MUST

Family/Stage navigation改修によってProject、Research Context、Dataset Version、Analysis Viewのexisting semanticsを変更しない。

### E5-REQ-033 — Family間でStage taxonomyを共通化しない — MUST NOT

FamilyごとにStage数・名称が異なってよい。

### E5-REQ-034 — Overview/FlagshipをE5のFamily peerとして追加しない — MUST NOT

将来導入する場合はglobal workspace dimensionとして再設計する。

## 9. Route / compatibility requirement

### E5-REQ-035 — legacy analytical routeを互換維持する — MUST

`/explore`, `/causal`, `/predictive`相当の既存routeを明示的mappingでcanonical routeへnormalize/redirectする。

heuristicにunknown routeを別semantic contextへ推測変換してはならない。

### E5-REQ-036 — invalid Family/Stageを黙って別Stageへ解釈しない — MUST NOT

invalid routeは明示的navigation errorまたはdocumented legacy mappingで扱う。

### E5-REQ-037 — back/forward/reloadをdeterministicにする — MUST

URLがcurrent Family/Stageのcanonical stateである以上、browser historyから同一navigation contextを復元する。

## 10. Persistence / schema / engine requirement

### E5-REQ-038 — DB migrationなしで成立させる — MUST

Target designではnavigation descriptorをcode-defined read-only dataとし、persistent schemaを変更しない。

migrationが不可避と判明した場合、Coding Agentが独断で追加せず`BLOCKED_CONTRACT_AMBIGUITY`とする。

### E5-REQ-039 — existing Analysis Specification / Execution / Result schemaを変更しない — MUST

ENH-E5で明示的に承認されないschema revisionを行わない。

### E5-REQ-040 — new analytical engine/dependencyを追加しない — MUST NOT

LightGBM / DoWhy / EconML等をnavigation改修へ混入させない。

## 11. 非機能要件

### E5-NFR-001 — Determinism
Family/Stage catalog order、default、route parse/serializeはdeterministicであること。

### E5-NFR-002 — Testability
Family/Stage descriptor、route/history、compatibility、family-specific mappingをautomated test可能な構造とする。

### E5-NFR-003 — Backward compatibility
existing analytical behavior、result persistence、project contextをregressさせない。

### E5-NFR-004 — Semantic clarity
Predictive / Causal / Exploratoryの意味をUI labelとresult interpretationで混同しない。

### E5-NFR-005 — Execution isolation
Gate execution時、Coding/Test Agentが上流文書を再探索しなくてもfreeze済みcontractだけで担当責務を実行できること。

## 12. Out of scope

- LightGBM adapter
- DoWhy adapter
- EconML estimator
- online/streaming prediction serving
- full model registry / deployment lifecycle
- Causal `Analysis Management` Stage
- Overview / Flagship implementation
- new persistent Findings/Evidence domain
- new AnalysisResult hierarchy
- navigation state DB persistence
- mandatory sequential wizard
- Family間の共通Stage taxonomy

## 13. Requirement traceability summary

| Requirement cluster | Primary Gate |
|---|---|
| Family/Navigation Stage domain separation, capability ownership, descriptor API | G00 |
| URL/navigation shell/history/legacy route | G01 |
| Predictive 6 Stage + 100% compatibility | G02 |
| Causal 7 Stage + Identification/Estimation separation | G03 |
| Exploratory 6 Stage + visualization placement | G04 |
| Cross-family continuity / full regression | G05 |

詳細ACは各Gateのfreeze済み07へ収束させる。Execution Agentは本書を直接normative sourceとして使用しない。
