# 30 詳細設計 — ENH-E5 revised target snapshot

- 文書状態: `DRAFT_FOR_REVIEW`
- Baseline: `feature/ariadne_mvp_e5` planning pin
- 目的: implementation Gateへ落とし込むためのtarget module boundary、data flow、validation、test seamを定義する。

## 1. 設計原則

1. Navigation StageとExecution Stageを別type/責務として実装する。
2. Family-specific catalogはCapability ownershipとする。
3. product/application layerはgeneric aggregation/validationを担当する。
4. Frontendはdescriptor-driven navigationを構築する。
5. Frontend renderer registryはpresentation bindingに限定する。
6. URLをCurrent Family/Stageのcanonical stateとする。
7. existing execution/persistence contractを変更しない。
8. CLI/library/backend use caseにNavigation Stage依存を導入しない。
9. Predictive existing configuration / generated spec semanticsを保護する。
10. schema migration、新engine、result-domain再設計を行わない。

## 2. Current code factとして利用する既存identity

Architecture Discoveryでcurrent branchにはproduct-domain `AnalysisFamily`が存在し、`EXPLORATORY`, `CAUSAL`, `PREDICTIVE`を持つことを確認している。

またexecution側にはStage execution statusやexecution operation/result type等、runtime lifecycleに関するdomain概念が既に存在する。

このためFamily identityは再利用し、Navigation Stageだけを新たなapplication conceptとして導入する。

## 3. Target package/module structure

実際のcurrent repository treeに合わせてfreeze前にpathを確定するが、target responsibilityは次とする。

```text
product/domain
  navigation descriptor primitives

capabilities/exploratory
  exploratory navigation catalog

capabilities/predictive
  predictive navigation catalog

capabilities/causal
  causal navigation catalog

product/application
  catalog aggregation / validation / query use case

interfaces/web_api
  navigation response schema / GET endpoint

frontend
  descriptor client
  route parse/serialize
  Family tabs
  Stage sidebar
  renderer binding
```

既存package namingと異なる場合はcurrent architectureへ合わせてよいが、ownership directionは変えない。

## 4. Domain type design

Candidate immutable types:

```python
NavigationStageDescriptor(
    id: str,
    slug: str,
    label: str,
    order: int,
)

FamilyNavigationDescriptor(
    family: AnalysisFamily,
    slug: str,
    label: str,
    default_stage_id: str,
    stages: tuple[NavigationStageDescriptor, ...],
)
```

Python implementation styleはcurrent repository conventionsへ合わせる。

重要なのはfield exactnessよりsemanticsである。

## 5. Domain validation

constructor/factory/aggregationのいずれかで次をfail-fastする。

- duplicate Family
- empty stages
- duplicate stage ID
- duplicate stage slug
- invalid default
- non-deterministic/ambiguous order
- unsupported AnalysisFamily missing

label empty等のpresentation invariantもcurrent styleに合わせて検証してよい。

## 6. Execution Stageからの分離チェック

Navigation type implementationで次を禁止する。

- execution Stage classのsubclass
- execution Stage enumをnavigation stage IDとして直接使用
- runner registryへのdependency
- execution dependency DAG field
- status/attempt lifecycle field

静的code reviewだけでなくunit testでindependenceを確認できる設計にする。

## 7. CLI / library independence design

### 7.1 Invariant

Backend analysis use case / runtime execution APIのfunction signatureへNavigation Stageを追加しない。

### 7.2 Prohibited examples

```python
run_analysis(spec, navigation_stage="train")
```

のようにnavigation contextをexecution semanticsの必須argumentにしない。

### 7.3 Allowed examples

```python
run_analysis(spec)
```

`spec.analysis_family`等、既存domain discriminatorは許容する。

### 7.4 Regression seam

existing direct application service / CLI testsがある場合、Navigation Stage指定なしで従来通り実行できることをregression testで保護する。

## 8. Capability-owned catalog

各Capability moduleは自身のimmutable descriptorをexportする。

generic aggregatorへFamily-specific Stage literalを列挙しない。

悪い例:

```python
ALL_STAGES = {
  AnalysisFamily.PREDICTIVE: [...predictive literals...],
  AnalysisFamily.CAUSAL: [...],
}
```

をgeneric product moduleに集中させる。

望ましい例:

```text
predictive capability -> PREDICTIVE_NAVIGATION
causal capability -> CAUSAL_NAVIGATION
exploratory capability -> EXPLORATORY_NAVIGATION
       ↓
generic navigation service aggregates
```

## 9. Navigation query service

責務:

- supported capability descriptorの収集
- invariant validation
- deterministic ordering
- API response用read model生成

責務外:

- execution availability判断
- current Project state mutation
- Analysis Specification生成
- runner selection
- DB persistence

## 10. Web API schema

Response modelは`analysis-navigation/1`を表現する。

Execution-domain objectをそのままserializeしない。

API schemaはnavigation用途に必要な最小情報へ限定する。

## 11. Frontend descriptor client

page initialization時にnavigation catalogをloadする。

状態候補:

```text
loading
ready(catalog)
error
```

catalog responseをvalidated in-memory objectへnormalizeする。

schema version mismatch時にsilent fallbackしない。

## 12. Route parser / serializer

必要function concept:

```text
parseAnalysisRoute(location) -> {projectId, familySlug, stageSlug} | invalid
serializeAnalysisRoute(projectId, familySlug, stageSlug) -> path
resolveNavigation(catalog, familySlug, stageSlug) -> valid descriptor | invalid
```

parse/serialize round-tripをtestする。

## 13. History handling

Family/Stage clickはcurrent frontend architectureに応じてHistory API/routerを使う。

- user navigation: push
- legacy normalization: replace候補
- back/forward: popstate/router eventからrender

DOM active stateだけを変更してURLを放置しない。

## 14. Renderer registry

Frontend implementationはsemantic keyをsurfaceへbindingするsparse registryを持ってよい。

```text
(family, stage) -> render/activate function
```

registryにlabel/order/defaultを重複保持しない。

unknown keyはexplicit unsupported errorにする。

## 15. Existing UI reuse

ENH-E5は既存functionalityの再配置が中心である。

原則:

- existing form controlをreuse
- existing submit/run logicをreuse
- existing result renderingをreuse
- navigation shellだけのためにanalysis semanticsを書き直さない

refactorが必要な場合もbehavior parity testを先に用意する。

## 16. Predictive compatibility inventory implementation

G02 P01でcurrent UI / frontend JS / backend spec generationを全量inventoryする。

inventory tableに最低限:

```text
Current field/control
Current source location
Backend/spec field
Current default/derived semantic
Target Stage
Target control/source
Parity test
```

を記録する。

前版の列挙を最終inventoryとみなさず、current codeから再確認する。

## 17. Predictive Stage binding

### Setup
all configuration input。

### Train
existing split/train workflow launch/status。

### Predict
existing prediction-bearing result/artifact view。new serving executionなし。

### Metrics
existing evaluation/error-analysis result。

### Explainability
existing explanation result。

### Model Management
existing fitted model/model card/artifact/lineage read surface。

## 18. Predictive form state strategy

existing DOMをhide/showするだけで保持できるならそれを優先してよい。

component/unmount refactorを行う場合、explicit draft stateを導入し、全protected fieldのround-trip testを行う。

Stage切替後にgenerated specが変化しないことをtestする。

## 19. Causal Stage binding

current causal operation/resultを次へmappingする。

- Setup: design inputs
- Discovery: graph discovery/candidate/edit/import
- Identification: identification/adjustment/eligibility
- Estimation: estimator/run/revision
- Effects: effect result/comparison
- Diagnostics: diagnostics/eligibility result
- Sensitivity: refutation/sensitivity

新規engine methodを追加しない。

## 20. Identification / Estimation separation implementation

UI container、route、heading、action groupingを分離する。

ただしexisting backend operation chainをnavigation順へ書き換えない。

Identification resultをEstimationで参照するexisting dependencyがある場合はそのruntime semanticsを維持する。

## 21. Exploratory Stage binding

current exploratory operations/resultを次へmappingする。

- Profile: profile/overview
- Data Quality: available quality indicators
- Distribution: distribution + relevant chart
- Relationships: association + relevant chart
- Comparison: group/time/segment comparison
- Findings: saved exploratory results / annotation / lineage projection

`Visualization`という独立Stageを作らない。

## 22. Result / Lineage integration

Family-local Stageからexisting Result/Lineageへlinkし、global surfaceからFamily-specific resultへ戻れる。

ENH-E5でResult schemaを再設計しない。

## 23. Error handling

### Invalid family
explicit navigation error。

### Invalid stage
explicit navigation error / valid stage listへのlink。

### Catalog API failure
existing contentを別semantic Stageとして誤表示しない。

### Renderer missing
implementation defectとしてexplicit error。default Stageへsilent substitutionしない。

## 24. Migration / dependency

- DB migration: prohibited unless contract amendment
- new analytical dependency: prohibited
- new engine adapter: prohibited
- existing package dependency update: navigation implementationに不可欠な場合でもfreeze済み06の許可scope内でのみ実施

## 25. Test architecture

### G00
- descriptor unit tests
- capability ownership/aggregation tests
- API schema tests
- execution abstraction independence tests
- CLI/library direct execution regression where available

### G01
- route parser/serializer
- direct URL
- reload
- back/forward
- legacy mapping
- invalid route
- active Family/Stage rendering

### G02
- full Predictive field inventory parity
- generated spec snapshot/semantic parity
- Stage switching state preservation
- run/evaluate/explain regression

### G03
- Causal Stage mapping
- Identification/Estimation separation
- existing causal operation regression

### G04
- Exploratory Stage mapping
- visualization placement
- exploratory result regression

### G05
- cross-family navigation
- Project/Context/Data continuity
- Results/Lineage continuity
- full existing automated suite
- browser e2e where available

## 26. Implementation Agent boundary

本詳細設計はPlanning/Human review用であり、freeze後のCoding Agentへ直接読ませない。

各Gateのrequired semanticsは06/Pxxへ収束させる。

Agentが本書を読まなければ実装できない06/Pxxはcontract生成不良としてfreezeしない。
