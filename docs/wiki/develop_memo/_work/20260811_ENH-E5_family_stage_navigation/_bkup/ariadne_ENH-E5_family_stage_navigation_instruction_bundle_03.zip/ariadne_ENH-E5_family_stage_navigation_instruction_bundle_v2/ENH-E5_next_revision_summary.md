# ENH-E5 次版改訂サマリ

## 1. 改訂目的

前版はtemplate structureには整合していたが、次の2点で不十分だった。

1. `00_product_concept_memo.md`および`10_*.md〜30_*.md`が要約化され、ENH-E4時点のeffective documentと比べて背景・理由・具体性が不足していた。
2. 06/07の外部参照ポリシーが弱く、Execution Agentが上流文書を再探索・再解釈できる余地があった。

次版では、Planning層の情報密度を戻す一方、Execution Agentが受け取るnormative contextを単一contractへ限定する。

## 2. 主要改訂

### R1 — 日本語話者向けの自己完結性
説明・判断理由・受入意味を日本語中心に統一した。code識別子やarchitecture用語は英語を許容する。

### R2 — Product Conceptの復元
Family / Stageの思想、Familyごとの構想、Flagship将来構想、AnalysisResult共通化候補、engine分離方針まで復元した。

### R3 — 10〜30層の粒度復元
要件、論理データ、基本設計、API、詳細設計を「差分メモ」ではなくENH-E5 targetを説明するeffective snapshotとして再構成した。

### R4 — Navigation StageとExecution Stageの分離理由を具体化
Distribution / Metrics / Explainabilityの問題例と、CLI/libraryへUI taxonomyが漏れる問題を明示した。

### R5 — CLI/library independence
`Family × Navigation Stage`をanalysis executionの必須入力にしないことをarchitecture invariantおよびACへ追加した。

### R6 — 06/07 single normative contract
G00〜G05すべての06/07へexecution isolation policyを導入した。

### R7 — Work Packageもsingle contract化
Package Coding Agentは割り当てPxxのみをnormative inputとして使用する。Pxxに必要なGate-level semanticsを事前に複製・収束する。

### R8 — Agent promptの参照範囲縮小
Single Coding Agentは06のみ、Package Coding AgentはPxxのみ、Test Agentは07のみをnormative sourceとして扱うようoperator promptを改訂した。

### R9 — ambiguityは探索せずBLOCKED
Agentが曖昧な仕様を資料探索・一般知識で補完せず、`BLOCKED_CONTRACT_AMBIGUITY`で停止する。

## 3. 設計意図

この改訂はprompt tokenの機械的削減ではない。

```text
Planningでdecision entropyを下げる
       ↓
effective contractへ圧縮する
       ↓
Execution Agentの探索空間を狭める
       ↓
実装・テストに推論資源を集中する
```

期待効果は、仕様解釈のばらつき低減、code/test品質の安定化、不要なAI credit消費の抑制である。
