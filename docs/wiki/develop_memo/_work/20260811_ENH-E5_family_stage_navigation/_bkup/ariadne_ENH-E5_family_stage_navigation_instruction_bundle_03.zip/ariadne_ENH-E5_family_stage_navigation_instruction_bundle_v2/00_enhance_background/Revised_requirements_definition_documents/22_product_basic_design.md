# 22 プロダクト基本設計 — ENH-E5 revised target snapshot

- 文書状態: `DRAFT_FOR_REVIEW`
- 対象: UI / information architecture / navigation behavior / Family-specific surface

## 1. 基本設計の目的

ENH-E5はAriadneのanalytical workspaceを、globalなFamily dimensionとFamily-localなNavigation Stage dimensionへ再構成する。

本書では画面構成、route behavior、Family/Stage switching、既存surfaceの再配置、禁止されるcouplingを定義する。

## 2. Top-level information architecture

Target layout:

```text
Project header / global context

[ Exploratory ] [ Predictive ] [ Causal ]    <- Family tabs
-----------------------------------------------------------
Stage sidebar             | Main content
(selected Family only)    | selected Navigation Stage
                          |
-----------------------------------------------------------
Global project surfaces: Research Context / Data / Results-Lineage etc.
```

Family tabとStage sidebarは異なるnavigation dimensionである。

## 3. Global Family navigation

### 3.1 表示
Exploratory / Predictive / Causalを常時表示する。

### 3.2 Current Family
現在選択中Familyをactive stateで明示する。

### 3.3 Family切替
Family tab clickは対象Familyのdefault Stageへnavigationする。

ENH-E5ではFamilyごとのlast-stage memoryを要求しない。

### 3.4 Family tabに置かないもの
Project Management、Research Context、Data、Results/Lineage、Overview等をFamilyと同列のanalytical tabとして混在させない。

## 4. Family-local Stage sidebar

selected FamilyのNavigation Stageだけを表示する。

Exploratory:
- Profile
- Data Quality
- Distribution
- Relationships
- Comparison
- Findings

Predictive:
- Setup
- Train
- Predict
- Metrics
- Explainability
- Model Management

Causal:
- Setup
- Discovery
- Identification
- Estimation
- Effects
- Diagnostics
- Sensitivity

Stage数を揃えるためのdummy Stageを作らない。

## 5. Navigation Stageはworkflow progressではない

sidebarの順序は情報設計上の並びであり、必須completion sequenceではない。

例えばCausalでfixed graphが既に存在する利用者がDiscoveryを経ずIdentificationへ移動できる場合、それをnavigation構造で禁止しない。

operation prerequisiteがある場合はbackend/application use caseが別途availability/validationを返す。

## 6. Canonical route

Target:

```text
/projects/{project_id}/analysis/{family_slug}/{stage_slug}
```

Family slug:
- `exploratory`
- `predictive`
- `causal`

routeはCurrent Family/Stageのcanonical stateである。

## 7. Deep link / reload / history

### 7.1 Direct load
canonical URLを直接開いた場合、Family tab、Stage sidebar、main contentをURLから再構成する。

### 7.2 Reload
reload後も同一Family/Stageを復元する。

### 7.3 Browser back / forward
history navigationで以前のFamily/Stageへdeterministicに戻る。

### 7.4 Invalid route
unknown Family/Stageをheuristicに別Stageへ解釈しない。

明示的legacy mappingがなければnavigation errorを表示し、有効なdefaultへの導線を提供する。

## 8. Legacy route compatibility

Target mapping例:

```text
/projects/{id}/explore
  -> /projects/{id}/analysis/exploratory/profile

/projects/{id}/causal
  -> /projects/{id}/analysis/causal/discovery

/projects/{id}/predictive
  -> /projects/{id}/analysis/predictive/setup
```

実際のcurrent route inventoryをG01 implementation前に06/Pxx内へ具体化する。

legacy route mappingはexplicit one-way mappingとし、unknown pathをguessしない。

## 9. Global surfaceとの関係

Research Context / Data / Results-Lineage等はglobal project contextである。

Family navigationを追加しても、これらのexisting accessibilityを失わせない。

FamilyからResultsへ移動した後、元Family/Stageへ戻るhistory behaviorも一貫させる。

## 10. Exploratory surface

### Profile
Dataset overview、schema、summary等。

### Data Quality
missing、duplicate候補、invalid/unexpected value等。current capabilityでsupportされる範囲を優先。

### Distribution
univariate distribution + chart control。

### Relationships
association/correlation/cross-tab等。causal labelは禁止。

### Comparison
group/segment/cohort/time comparison。

### Findings
existing saved exploratory result/annotation/lineageを閲覧・接続するsurface。新規persistent Finding CRUDは追加しない。

## 11. Predictive surface

### Setup
existing predictive inputをすべて保持する。

Stage分割の都合でfieldを削除しない。

### Train
split validation、execution launch、status等を適切に配置する。Navigation Stage名とruntime stage typeを同一化しない。

### Predict
current prediction-bearing result/artifactがある場合に閲覧する。新規serving engineを追加しない。

### Metrics
existing evaluation/error analysis resultを閲覧する。

### Explainability
existing predictive explanationを閲覧する。causal effectとのvisual/label上の混同を避ける。

### Model Management
fitted model、model card、artifact、lineageのread-oriented management。deployment/registry CRUDはscope外。

## 12. Predictive form state preservation

Family/Stage切替でactive page sessionの未保存Predictive入力を失わせない。

推奨候補:

1. Existing form DOM/stateを保持しvisibilityのみ切替。
2. Unmountする場合はexplicit draft state storeへ全fieldを保持。

禁止:

- Stage移動のたびにdefault値へreset
- hidden fieldを再生成してsemantic defaultが変わる
- visible UIだけ残しgenerated spec semanticsを変える

## 13. Causal surface

### Setup
analysis design / treatment / outcome / population / unit / window / estimand / assumptions等。

### Discovery
graph discovery/candidate/user-defined/imported graph等。

### Identification
identification strategy、adjustment、eligibility等。「何が識別できるか」を扱う。

### Estimation
estimator、execution/revision等。「どう推定するか」を扱う。

### Effects
ATE/ATT等のeffect result閲覧・比較。

### Diagnostics
balance/overlap/eligibility等のdiagnostic。

### Sensitivity
refutation / sensitivity method/result。

## 14. Identification / EstimationのUX分離

UI上で「estimatorを選べる」ことを「causal effectが識別されている」こととして見せない。

Identification Stageで識別結果/警告を明示し、Estimation Stageはその前提上で推定操作を扱う。

ただしnavigation Stage順そのものをbackend prerequisiteにしない。実際の実行可否はcurrent domain/application validationに従う。

## 15. Navigation Stage / Execution StageのUI表現

UIはNavigation Stageを表示する。

Execution detail画面でruntime Stage/attempt/statusを表示する場合、Navigation Stageと同じ「Stage」という語が混乱を生む可能性があるため、必要に応じて`Execution Stage`と修飾する。

UI上の`Metrics`等からruntime stage statusを捏造しない。

## 16. Accessibility / usability

- active Family / Stageを視覚だけでなくsemantic markupでも識別可能にする。
- keyboard navigationをexisting application standardに合わせる。
- sidebar item labelとroute slugを混同しない。
- browser historyを壊す単純DOM切替だけにしない。

## 17. Responsive layout

既存frontend制約に合わせ、Family tabが狭幅でoverflowする場合のwrap/scroll/compact behaviorを明示的に設計する。

sidebarのcollapse behaviorを追加する場合もENH-E5 requirementを満たす範囲で行い、独自feature scopeを広げない。

## 18. Error / loading state

Descriptor API loading/error時にexisting analytical surfaceを誤ったFamily/Stageとして表示しない。

- loading: navigation skeleton/disabled state
- API/schema mismatch: explicit error
- unknown renderer binding: explicit unsupported-state error

unknown stageをdefaultへsilent fallbackしてsemantic bugを隠さない。

## 19. Overview / Flagship

ENH-E5では実装しない。

将来はDecision/Questionを中心にExploratory Findings / Predictive Results / Causal Effectsを統合するglobal workspace候補とする。

Family tabの4つ目として雑に追加しない。

## 20. UX acceptance summary

- Familyがglobal dimensionとして明確。
- Stageがselected Family local dimensionとして明確。
- direct URL/historyが一致。
- Predictive inputが失われない。
- causal/exploratory/predictive meaningが混同されない。
- global project surfaceが維持される。
