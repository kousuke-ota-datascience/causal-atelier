# Revised Requirements / Design Documents — ENH-E5

このdirectoryは、ENH-E5 target時点の要件・設計を自己完結的に保存するeffective snapshotである。

## 記載粒度

差分要約ではなく、各文書だけで担当領域について次を理解できる粒度とする。

- 背景 / 現状
- 問題
- target behavior
- 判断理由
- responsibility / ownership
- concrete structure / flow / contract
- compatibility
- out of scope
- edge case
- verification / traceability

ENH-E4時点の同種snapshotと同程度の論証密度・具体性をbenchmarkとする。単純な行数一致は目的ではない。

## Agent boundary

このsnapshotはPlanning / Human review / future audit用である。

Coding Agent / Test Agentの通常executionでは参照させない。必要なeffective semanticsはfreeze前に06/07/Pxxへ収束させる。
