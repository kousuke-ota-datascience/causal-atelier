# Test Reports

Test / Audit Agentが実際に実行した検証を、人間が追試できる粒度で保存する。

## Naming

- `[GATE]_[trial]_[item]_[test_name].md`
- `[GATE]_[trial]_999_gate_decision.md`

例:

```text
G3_001_001_schema_contract.md
G3_001_002_leakage_rejection.md
G3_001_999_gate_decision.md
```

## 個別Test Report必須記録

- tested implementation commit
- handoff report path
- branch
- migration head
- working directory
- preconditions
- runtime / service versions
- environment variable requirements
- 実行した完全なコマンド
- started / finished timestamp
- duration
- exit code
- passed / failed / skipped
- stdout / stderr
- traceback / assertion
- log / screenshot / artifact path
- findings
- reproduction procedure
- decision rationale

実行コマンドはコピー&ペーストで再実行可能な完全形とする。
`同上`、`前回と同じ`、`pytestを実行` などの省略表現は禁止。

## Gate Decision

`PASS | FAIL | BLOCKED`

PASSは、そのtrialに要求された必須test itemがすべて完了しPASSした場合のみ。
過去trialのPASS結果を寄せ集めて現在trialをPASSにしない。

## Test Agent禁止事項

- production code変更
- automated test code変更
- migration変更
- dependency変更
- formatterによるsource書換え
- assertion緩和
- skip / xfail追加
- failing test削除
- product design再設計
