# Revised Requirements Definition Documents

当該エンハンス時点で確定した要件・設計書のsnapshotを保存する。

- 後続更新による過去状態消失を防ぐ
- 「このエンハンス時点で何を正としていたか」を再現する
- 将来の監査・再設計時に時点差分を比較可能にする

ここはCoding Agent / Test Agentの通常作業用Source of Truthではない。
