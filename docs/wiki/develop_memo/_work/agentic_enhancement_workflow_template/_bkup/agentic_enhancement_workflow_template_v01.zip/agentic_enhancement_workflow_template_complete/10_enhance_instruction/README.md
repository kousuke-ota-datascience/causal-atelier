# Enhancement Instructions

- `06_..._実装指示書.md`: Coding Agentの唯一の作業指示
- `07_..._テスト指示書.md`: Test / Audit Agentの唯一の作業指示

背景資料・要件定義書・設計書をAgentに再読させないため、
必要な差分仕様・制約・Acceptance Criteriaを06/07へ統合する。
