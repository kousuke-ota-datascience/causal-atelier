# Enhancement Background

このディレクトリは、エンハンスの背景、課題認識、要件改定、設計改定、承認、
トレーサビリティ、およびエンハンス時点の要件・設計snapshotを保存する。

Coding Agent / Test Agentの通常作業では参照させない。
Agentに必要な差分仕様は `10_enhance_instruction/` へ統合する。
