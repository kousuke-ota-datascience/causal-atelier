# Implementation Reports

Coding Agentが実際に行った変更を、Test Agentと人間が再構成できる状態で保存する。

## Files

- `{{ENHANCE_ID}}_implementation_report_detail.md`
- `[GATE]_[trial]_implementation_completion_report.md`

## Completion Report必須情報

- Gate / trial / Status
- Branch
- baseline / starting / implementation commit
- migration head
- 実装範囲
- changed files
- automated test code変更
- PASS済みGateへの変更
- known limitations
- Git evidence
- Test Agentへ引き渡すimplementation commit

Statusは `READY_FOR_TEST` または `DESIGN_BLOCKED`。

## Detail Report

エンハンス全体の累積実装状況を更新する。

- Gate Status
- Trial History
- Current Working State
- Completed Implementation
- Outstanding Work
- Cross-Gate Changes
- Known Deviations
- Evidence Index
