# AI Agent分業型エンハンス開発テンプレート

本テンプレートは、エンハンス開発における背景、要件・設計スナップショット、
実装指示、実装報告、テスト指示、テスト証跡、Gate判定、Agent起動プロンプトを
一式で保存するための標準構成である。

詳細構成は `TEMPLATE_STRUCTURE.md` を参照する。

## 情報レイヤ

- `00_enhance_background/`: Why / 背景・設計意思決定・要件/設計snapshot
- `10_enhance_instruction/`: What/How / Coding・Test Agent向け実行契約
- `20_implementation_reports/`: What was implemented / 実装証跡
- `30_test_report/`: What was verified / 検証証跡・Gate判定
- `40_operator_prompts/`: Agent起動時の入口プロンプト

## 原則

- Coding Agentは06だけを作業指示として使用する。
- Test / Audit Agentは07と、明示指定されたimplementation completion reportだけを使用する。
- 背景資料・要件定義書・設計書は通常のAgent実行時には参照させない。
- `TEMPLATE_*.md` は穴埋め構造だけを持ち、instructionはREADMEへ分離する。
- テスト実行コマンドはコピー&ペースト可能な完全形で証跡に残す。
