# Operator Prompts

作業指示者がAgentへ渡す入口プロンプト。

詳細な作業契約は `10_enhance_instruction/` に集約し、
外側プロンプトへ重複仕様を書かない。

Test Agentには07に加え、具体的なimplementation completion report pathを指定する。
