# {{PROJECT_NAME}} {{ENHANCE_ID}} 実装指示書

- Project: {{PROJECT_NAME}}
- Enhancement: {{ENHANCE_ID}}
- Branch: {{BRANCH}}
- Baseline commit: {{BASELINE_COMMIT}}
- Active Gate: {{ACTIVE_GATE}}
- Migration head: {{MIGRATION_HEAD}}

## 1. Source of Truth
{{CODING_SOURCE_OF_TRUTH}}

## 2. Coding Agent Role
{{CODING_AGENT_ROLE}}

## 3. Prohibited Work
{{CODING_PROHIBITIONS}}

## 4. Current State
{{CURRENT_STATE}}

## 5. Gate Status
{{GATE_TABLE}}

## 6. Trial Rules
{{TRIAL_RULES}}

## 7. Gate Implementation Contracts
{{GATE_IMPLEMENTATION_CONTRACTS}}

## 8. Allowed / Forbidden Change Areas
{{CHANGE_BOUNDARIES}}

## 9. Completion Conditions
{{IMPLEMENTATION_COMPLETION_CRITERIA}}

## 10. Required Outputs
{{IMPLEMENTATION_OUTPUTS}}

## 11. Stop Conditions
{{CODING_STOP_CONDITIONS}}
